package com.example.ai

import com.example.BuildConfig
import com.example.data.NutrientTarget
import com.example.formulator.AchievedNutrients
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

// --- Moshi Data Classes for Gemini REST ---
@JsonClass(generateAdapter = true)
data class GeminiRequest(
    val contents: List<Content>,
    val generationConfig: GenerationConfig? = null,
    val systemInstruction: Content? = null
)

@JsonClass(generateAdapter = true)
data class Content(
    val parts: List<Part>
)

@JsonClass(generateAdapter = true)
data class Part(
    val text: String
)

@JsonClass(generateAdapter = true)
data class GenerationConfig(
    val temperature: Double? = 0.7,
    val topP: Double? = 0.95,
    val topK: Int? = 40
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    val candidates: List<Candidate>? = null
)

@JsonClass(generateAdapter = true)
data class Candidate(
    val content: Content? = null
)

object FeedAdvisorService {

    private const val MODEL_NAME = "gemini-3.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_NAME:generateContent"

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun getAdvice(
        birdType: String,
        ageWeeks: Int,
        stageName: String,
        batchWeightKg: Double,
        costPerKg: Double,
        recipeIngredients: Map<String, Double>, // name to kg
        achieved: AchievedNutrients,
        target: NutrientTarget,
        userQuestion: String,
        isSwahili: Boolean
    ): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            // No API Key, use professional offline-first fallback
            return@withContext getOfflineAdvice(
                birdType, ageWeeks, stageName, batchWeightKg, costPerKg, recipeIngredients, achieved, target, userQuestion, isSwahili
            )
        }

        val ingredientsStr = recipeIngredients.entries.joinToString("\n") { "  - ${it.key}: ${String.format("%.2f", it.value)} Kg" }
        
        val systemPrompt = "You are an expert poultry nutritionist advising smallholder farmers. Keep answers very practical, helpful, encouraging, and under 220 words. Provide summaries in Swahili AND English."
        val userPrompt = """
            Poultry Setup:
            Bird Type: $birdType
            Age: $ageWeeks Weeks ($stageName)
            Batch size: $batchWeightKg Kg
            Feed Cost/Kg: $costPerKg (local currency)

            Current Feed Recipe:
            $ingredientsStr

            Nutritional Analysis vs Target:
            - Crude Protein: ${String.format("%.2f", achieved.crudeProtein)}% (Target: ${target.crudeProtein}%)
            - Metabolizable Energy: ${String.format("%.1f", achieved.energy)} kcal/kg (Target: ${target.energy} kcal/kg)
            - Calcium: ${String.format("%.2f", achieved.calcium)}% (Target: ${target.calcium}%)
            - Phosphorus: ${String.format("%.2f", achieved.phosphorus)}% (Target: ${target.phosphorus}%)
            - Lysine: ${String.format("%.2f", achieved.lysine)}% (Target: ${target.lysine}%)
            - Methionine: ${String.format("%.2f", achieved.methionine)}% (Target: ${target.methionine}%)
            - Crude Fiber: ${String.format("%.2f", achieved.crudeFiber)}% (Target Max: ${target.crudeFiber}%)

            Farmer's Question: $userQuestion

            Generate advice. List 2 main strengths, 2 areas to improve or save costs, and specific Swahili/English tips.
        """.trimIndent()

        val requestPayload = GeminiRequest(
            contents = listOf(Content(parts = listOf(Part(text = userPrompt)))),
            systemInstruction = Content(parts = listOf(Part(text = systemPrompt))),
            generationConfig = GenerationConfig()
        )

        val jsonAdapter = moshi.adapter(GeminiRequest::class.java)
        val requestJson = jsonAdapter.toJson(requestPayload)

        val url = "$BASE_URL?key=$apiKey"
        val request = Request.Builder()
            .url(url)
            .post(requestJson.toRequestBody("application/json".toMediaType()))
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext getOfflineAdvice(
                        birdType, ageWeeks, stageName, batchWeightKg, costPerKg, recipeIngredients, achieved, target, "$userQuestion (Note: Online call failed with code ${response.code})", isSwahili
                    )
                }
                val bodyStr = response.body?.string() ?: throw IOException("Empty response body")
                val responseAdapter = moshi.adapter(GeminiResponse::class.java)
                val geminiResponse = responseAdapter.fromJson(bodyStr)
                
                val text = geminiResponse?.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                if (text != null) {
                    text
                } else {
                    getOfflineAdvice(birdType, ageWeeks, stageName, batchWeightKg, costPerKg, recipeIngredients, achieved, target, userQuestion, isSwahili)
                }
            }
        } catch (e: Exception) {
            getOfflineAdvice(birdType, ageWeeks, stageName, batchWeightKg, costPerKg, recipeIngredients, achieved, target, "$userQuestion (Note: Network Error - showing offline diagnostic)", isSwahili)
        }
    }

    private fun getOfflineAdvice(
        birdType: String,
        ageWeeks: Int,
        stageName: String,
        batchWeightKg: Double,
        costPerKg: Double,
        recipeIngredients: Map<String, Double>,
        achieved: AchievedNutrients,
        target: NutrientTarget,
        userQuestion: String,
        isSwahili: Boolean
    ): String {
        val sb = StringBuilder()
        
        if (isSwahili) {
            sb.append("📋 **Mshauri wa Lishe ya Kuku (Njia ya Nje ya Mtandao - Offline)**\n\n")
            sb.append("Uchambuzi wa lishe kulingana na fomula uliyochagua:\n")
        } else {
            sb.append("📋 **Poultry Nutrition Advisor (Offline Mode)**\n\n")
            sb.append("Nutrition analysis based on your batch formulation:\n")
        }

        // Check major protein shortfall
        val cpDiff = target.crudeProtein - achieved.crudeProtein
        if (isSwahili) {
            if (cpDiff > 1.0) {
                sb.append("⚠️ **Protini iko Chini:** Fomula yako ina pungufu ya ${String.format("%.1f", cpDiff)}% ya protini mbichi. Kuku wako watakuwa na ukuaji wa polepole. Ongeza unga wa soya (Soybean Meal) au unga wa samaki (Omena/Fish meal).\n")
            } else {
                sb.append("✅ **Protini Sawa kabisa:** Viwango vya protini vinafikia mahitaji ya hatua ya ukuaji wa $stageName.\n")
            }
        } else {
            if (cpDiff > 1.0) {
                sb.append("⚠️ **Protein is Low:** Your feed is short by ${String.format("%.1f", cpDiff)}% CP. Birds may have slow growth or low egg laying. Try adding Soybean Meal or Fish Meal.\n")
            } else {
                sb.append("✅ **Protein is Optimal:** Protein levels meet the core requirements for $stageName.\n")
            }
        }

        // Calcium assessment
        val caDiff = target.calcium - achieved.calcium
        if (isSwahili) {
            if (caDiff > 0.3) {
                sb.append("⚠️ **Madini ya Chokaa (Calcium) ni ya Chini:** Pungufu ya ${String.format("%.2f", caDiff)}%. Hii ni hatari hasa kwa kuku wa mayai ($birdType $stageName) kwani inaongoza kwa mayai yenye ganda laini au ugonjwa wa mifupa. Ongeza chokaa (Limestone) au maganda ya chaza.\n")
            } else {
                sb.append("✅ **Madini ya Chokaa Sawa:** Calcium imebalansiwa vyema.\n")
            }
        } else {
            if (caDiff > 0.3) {
                sb.append("⚠️ **Calcium is Low:** Short by ${String.format("%.2f", caDiff)}%. Highly critical for layers; low calcium causes thin eggshells, broken eggs, and weak bones (cage fatigue). Increase Limestone or oyster shell powder.\n")
            } else {
                sb.append("✅ **Calcium is Balanced:** Matches standard poultry development speeds.\n")
            }
        }

        // Cost Analysis
        if (isSwahili) {
            sb.append("\n💡 **Ushauri wa Kupunguza Gharama:**\n")
            if (recipeIngredients.containsKey("Fish Meal (Omena)") || recipeIngredients.containsKey("Blood Meal")) {
                sb.append("- Unga wa samaki na unga wa damu ni vyanzo vizuri vya protini lakini ni ghali sana. Unaweza kupunguza kiasi chake na kuongeza unga wa soya (Soybean meal) au alizeti (Sunflower cake) ili kuokoa pesa.\n")
            }
            sb.append("- Tumia mahindi ya pumba au broken rice kulingana na kile kilicho rahisi zaidi sokoni kwako.\n")
            sb.append("- Punguza upotevu wa malisho kwa kutumia vifaa sahihi vya kulishia.\n")
        } else {
            sb.append("\n💡 **Cost-Saving Tips:**\n")
            if (recipeIngredients.containsKey("Fish Meal (Omena)") || recipeIngredients.containsKey("Blood Meal")) {
                sb.append("- Fish meal and blood meal are nutritious but expensive. You can substitute high shares with Soybean Meal or locally available Sunflower Cake to reduce input costs.\n")
            }
            sb.append("- Compare prices of Maize, broken rice, and wheat pollard. Use whichever is cheaper in your locality as the energy base.\n")
            sb.append("- Maintain strict feeder heights to avoid feed wastage and feed selector behavior.\n")
        }

        // Feed guide based on category
        sb.append("\n📖 ")
        if (isSwahili) {
            sb.append("**Mwongozo wa kulisha ($birdType):**\n")
            when (birdType) {
                "Broiler" -> sb.append("- Nyama: Hakikisha wanapata Starter kwa siku 7 za kwanza (wiki 1), kisha Grower kwa siku 14 (wiki 2-3), na Finisher kwa siku 10 (wiki 4) kumaliza ukuaji hadi soko (siku 30 jumla).")
                "Layer" -> sb.append("- Mayai: Lisha Starter kwa wiki 1-8 kwa ukuaji wa mifupa, Grower kwa wiki 9-18 ya ukuaji dhabiti wa mwili, na anza Layer Mash yenye calcium ya juu (3.8%) mnamo wiki ya 19+ wanapoanza kutaga ili kuhakikisha mayai yenye ganda dhabiti.")
                else -> sb.append("- Chotara/Kienyeji: Lisha Kienyeji Starter kwa wiki 1-8, Kienyeji Grower kwa wiki 9-20, na Kienyeji Laying/Breeder kuanzia wiki ya 21+ kulinda utagaji thabiti na dhumuni la ufugaji bora.")
            }
        } else {
            sb.append("**Weekly Feed Guide ($birdType):**\n")
            when (birdType) {
                "Broiler" -> sb.append("- Meat: Feed Broiler Starter for the first 7 days (Wk 1), transition to Grower for 14 days (Wk 2-3), and finish with high-energy Finisher for 10 days (Wk 4) to market slaughter at 30 days total.")
                "Layer" -> sb.append("- Eggs: Feed Chick Starter for weeks 1-8 for frame expansion, Growers Mash for weeks 9-18 to prevent early fatigue, and transition to Layer Mash (3.8% Ca) from week 19+ as laying begins for superior shell quality.")
                else -> sb.append("- Dual-Purpose/Indigenous: Feed Kienyeji Starter for weeks 1-8, Kienyeji Growers Mash for weeks 9-20 for resilient frame development, and Kienyeji Laying/Breeder Mash from week 21+ to sustain steady lay rates.")
            }
        }

        return sb.toString()
    }

    suspend fun getCustomAdvice(
        userPrompt: String,
        systemPrompt: String
    ): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext "Note: Gemini API key is missing. Online studies verification and custom advice are unavailable. Please setup GEMINI_API_KEY in the Secrets panel of AI Studio and check your connection."
        }

        val requestPayload = GeminiRequest(
            contents = listOf(Content(parts = listOf(Part(text = userPrompt)))),
            systemInstruction = Content(parts = listOf(Part(text = systemPrompt))),
            generationConfig = GenerationConfig()
        )

        val jsonAdapter = moshi.adapter(GeminiRequest::class.java)
        val requestJson = jsonAdapter.toJson(requestPayload)

        val url = "$BASE_URL?key=$apiKey"
        val request = Request.Builder()
            .url(url)
            .post(requestJson.toRequestBody("application/json".toMediaType()))
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext "API Call failed with code ${response.code}. Please ensure your API Key is valid."
                }
                val bodyStr = response.body?.string() ?: throw IOException("Empty response body")
                val responseAdapter = moshi.adapter(GeminiResponse::class.java)
                val geminiResponse = responseAdapter.fromJson(bodyStr)
                
                val text = geminiResponse?.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                text ?: "No suggestions could be generated by the model."
            }
        } catch (e: Exception) {
            "Error: ${e.localizedMessage}. Please check your connection and try again."
        }
    }
}

