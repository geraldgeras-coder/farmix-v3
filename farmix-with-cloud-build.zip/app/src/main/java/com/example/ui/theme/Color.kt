package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// FARMIX brand palette: deep forest, wheat gold, and fresh leaf highlights.
val SleekPrimary = Color(0xFF1D5A2D)
val SleekSecondary = Color(0xFF77B83F)
val SleekAccent = Color(0xFFD6A62E)
val SleekBackground = Color(0xFFF8F3E6)
val SleekSurface = Color(0xFFFFFCF2)
val SleekSurfaceVariant = Color(0xFFECE1C9)
val SleekBorder = Color(0xFFD8C28A)
val SleekOnPrimary = Color(0xFFFFFFFF)
val SleekOnBackground = Color(0xFF132215)
val SleekOnSurface = Color(0xFF203224)

// Cinematic dark theme matched to the FARMIX splash reference.
val SleekDarkPrimary = Color(0xFF9AD94B)
val SleekDarkSecondary = Color(0xFF73B53B)
val SleekDarkAccent = Color(0xFFFFC747)
val SleekDarkBackground = Color(0xFF020B05)
val SleekDarkSurface = Color(0xFF08170D)
val SleekDarkSurfaceVariant = Color(0xFF102817)
val SleekDarkOnPrimary = Color(0xFF0D130F)
val SleekDarkOnBackground = Color(0xFFFFFCF2)
val SleekDarkOnSurface = Color(0xFFEDE7D3)
