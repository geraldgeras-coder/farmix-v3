package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = SleekDarkPrimary,
    secondary = SleekDarkSecondary,
    tertiary = SleekDarkAccent,
    background = SleekDarkBackground,
    surface = SleekDarkSurface,
    onPrimary = SleekDarkOnPrimary,
    onSecondary = SleekDarkOnPrimary,
    onBackground = SleekDarkOnBackground,
    onSurface = SleekDarkOnSurface,
    surfaceVariant = SleekDarkSurfaceVariant
)

private val LightColorScheme = lightColorScheme(
    primary = SleekPrimary,
    secondary = SleekSecondary,
    tertiary = SleekAccent,
    background = SleekBackground,
    surface = SleekSurface,
    onPrimary = SleekOnPrimary,
    onSecondary = SleekOnPrimary,
    onBackground = SleekOnBackground,
    onSurface = SleekOnSurface,
    surfaceVariant = SleekSurfaceVariant
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colors,
        typography = Typography,
        content = content
    )
}
