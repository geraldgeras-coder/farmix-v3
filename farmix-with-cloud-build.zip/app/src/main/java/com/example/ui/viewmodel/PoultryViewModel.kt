package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.FeedAdvisorService
import com.example.data.*
import com.example.formulator.AchievedNutrients
import com.example.formulator.PoultryFeedSolver
import com.example.formulator.SolverResult
import com.example.ui.BudgetFormulatorSolver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PoultryViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("farmix_prefs", Context.MODE_PRIVATE)

    private val db = FeedDatabase.getDatabase(application, viewModelScope)
    private val repository = FeedRepository(db.feedDao())

    // --- Stores and Store Price States ---
    val selectedStoreId = MutableStateFlow<Int?>(
        if (prefs.contains("selected_store_id")) {
            val id = prefs.getInt("selected_store_id", -1)
            if (id == -1) null else id
        } else null
    )

    val selectedIngredientNames = MutableStateFlow<Set<String>>(emptySet())

    val allStores: StateFlow<List<Store>> = repository.allStores
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Core Database Flows ---
    val ingredients: StateFlow<List<Ingredient>> = combine(
        repository.allIngredients.map { list -> list.distinctBy { it.name.lowercase().trim() } },
        selectedStoreId,
        selectedIngredientNames,
        repository.allStorePricesFlow
    ) { rawList, storeId, selNames, allPrices ->
        if (storeId == null) {
            rawList.map { it.copy(isSelected = false) }
        } else {
            val storePricesMap = allPrices.filter { it.storeId == storeId }.associate { it.ingredientName.lowercase().trim() to it.price }
            rawList.map { ing ->
                // No fallback to default database prices if no specific store price is set yet
                val price = storePricesMap[ing.name.lowercase().trim()] ?: 0.0
                // Items are unchecked by default unless explicitly chosen/selected by the user
                val isSelected = price > 0.0 && selNames.contains(ing.name)
                ing.copy(
                    pricePerKg = price,
                    isSelected = isSelected
                )
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeStorePrices: StateFlow<List<StoreIngredientPrice>> = combine(
        selectedStoreId,
        repository.allStorePricesFlow
    ) { storeId, allPrices ->
        if (storeId == null) {
            emptyList()
        } else {
            allPrices.filter { it.storeId == storeId }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val nutrientTargets: StateFlow<List<NutrientTarget>> = repository.allNutrientTargets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val inclusionLimits: StateFlow<List<InclusionLimit>> = repository.allInclusionLimits
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedFormulations: StateFlow<List<SavedFormulation>> = repository.savedFormulations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val priceHistory: StateFlow<List<PriceHistory>> = repository.priceHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val manufacturingLogs: StateFlow<List<ManufacturingLog>> = repository.manufacturingLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val inventory: StateFlow<List<FeedInventory>> = repository.inventory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Interactive UI State ---
    // --- Dynamic Quick Action Icons State ---
    val activeQuickActionTags = MutableStateFlow<List<String>>(
        (prefs.getString("active_quick_actions", "req_calc,stores,recipes,growth,reports,profit,ingredients_manager,settings") ?: "req_calc,stores,recipes,growth,reports,profit,ingredients_manager,settings")
            .split(",")
            .filter { it.isNotBlank() }
    )

    fun updateActiveQuickActionTags(newTags: List<String>) {
        val sanitized = newTags.take(10)
        activeQuickActionTags.value = sanitized
        prefs.edit().putString("active_quick_actions", sanitized.joinToString(",")).apply()
    }

    val selectedBirdType = MutableStateFlow(prefs.getString("selected_bird_type", "Broiler") ?: "Broiler")
    val selectedAgeWeeks = MutableStateFlow(-1)
    val batchWeight = MutableStateFlow(prefs.getFloat("batch_weight", 50.0f).toDouble()) // kg default
    val customBatchWeightText = MutableStateFlow(prefs.getString("custom_batch_weight_text", "50") ?: "50")

    val isSwahili = MutableStateFlow(prefs.getBoolean("is_swahili", false))
    val appAppearance = MutableStateFlow(prefs.getString("app_appearance", "dark") ?: "dark")
    val isDarkTheme = MutableStateFlow(false)

    // --- Formulation Session States & Progress ---
    val isFormulationInProgress = MutableStateFlow(prefs.getBoolean("is_formulation_in_progress", false))
    val lastFormulationStep = MutableStateFlow(prefs.getString("last_formulation_step", "req_calc") ?: "req_calc")
    val selectedStoreForWhatIHave = MutableStateFlow<Store?>(null)
    val isConfirmedWhatIHave = MutableStateFlow(false)

    fun saveFormulationProgress(inProgress: Boolean, step: String) {
        isFormulationInProgress.value = inProgress
        lastFormulationStep.value = step
        prefs.edit()
            .putBoolean("is_formulation_in_progress", inProgress)
            .putString("last_formulation_step", step)
            .apply()
    }

    // Current automatically resolved target
    val currentTarget = MutableStateFlow<NutrientTarget?>(null)

    // Formulation engine result
    val solverResult = MutableStateFlow<SolverResult?>(null)

    // AI Advisor states
    val adviceText = MutableStateFlow("")
    val isAdviceLoading = MutableStateFlow(false)
    val currentAIQuestion = MutableStateFlow("")

    // --- Calculator Inputs ---
    val birdCount = MutableStateFlow(prefs.getInt("bird_count", 100))
    val feedingDurationDays = MutableStateFlow(prefs.getInt("feeding_duration_days", 30))
    val growthFeedCostPerKg = MutableStateFlow(prefs.getFloat("growth_feed_cost_per_kg", 45.0f).toDouble())
    val availableBudget = MutableStateFlow(prefs.getFloat("available_budget", 0.0f).toDouble())
    
    // --- Profitability Inputs ---
    val eggPricePerTray = MutableStateFlow(prefs.getFloat("egg_price_per_tray", 450.0f).toDouble()) // local standard
    val chickenSellingPrice = MutableStateFlow(prefs.getFloat("chicken_selling_price", 600.0f).toDouble())
    val dayOldChickCost = MutableStateFlow(prefs.getFloat("day_old_chick_cost", 100.0f).toDouble())
    val adminOverheadCost = MutableStateFlow(prefs.getFloat("admin_overhead_cost", 50.0f).toDouble())

    // --- Budget Feed State ---
    val budgetInput = MutableStateFlow(prefs.getString("budget_input", "") ?: "")
    val bagWeightInput = MutableStateFlow(prefs.getString("bag_weight_input", "50") ?: "50")
    val hasOptimizedBudget = MutableStateFlow(prefs.getBoolean("has_optimized_budget", false))
    val budgetResult = MutableStateFlow<BudgetFormulatorSolver.SolverResult?>(null)

    fun resetFormulationSession() {
        solverResult.value = null
        customBatchWeightText.value = "50"
        batchWeight.value = 50.0
        budgetInput.value = ""
        bagWeightInput.value = "50"
        hasOptimizedBudget.value = false
        budgetResult.value = null
        birdCount.value = 100
        isCustomizingRecipe.value = false
        customizedRecipeText.value = ""
        selectedAgeWeeks.value = -1

        selectedStoreForWhatIHave.value = null
        isConfirmedWhatIHave.value = false
        isFormulationInProgress.value = false
        lastFormulationStep.value = "req_calc"

        prefs.edit()
            .putBoolean("is_formulation_in_progress", false)
            .remove("last_formulation_step")
            .apply()

        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Clear selected ingredient names in prefs for all stores to completely reset selections
                val allStoresList = repository.getAllStoresList()
                val editor = prefs.edit()
                allStoresList.forEach { store ->
                    editor.remove("selected_ingredients_store_${store.id}")
                }
                editor.apply()
                selectedIngredientNames.value = emptySet()

                val currentIngs = repository.getAllIngredientsList()
                currentIngs.forEach { ing ->
                    if (ing.isSelected) {
                        repository.updateIngredient(ing.copy(isSelected = false))
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    init {
        // Collect and persist interactive UI and input states
        viewModelScope.launch {
            selectedBirdType.collect { prefs.edit().putString("selected_bird_type", it).apply() }
        }
        viewModelScope.launch {
            selectedAgeWeeks.collect { 
                if (it > 0) {
                    prefs.edit().putInt("selected_age_weeks", it).apply()
                }
            }
        }
        viewModelScope.launch {
            batchWeight.collect { prefs.edit().putFloat("batch_weight", it.toFloat()).apply() }
        }
        viewModelScope.launch {
            customBatchWeightText.collect { prefs.edit().putString("custom_batch_weight_text", it).apply() }
        }
        viewModelScope.launch {
            birdCount.collect { prefs.edit().putInt("bird_count", it).apply() }
        }
        viewModelScope.launch {
            feedingDurationDays.collect { prefs.edit().putInt("feeding_duration_days", it).apply() }
        }
        viewModelScope.launch {
            growthFeedCostPerKg.collect { prefs.edit().putFloat("growth_feed_cost_per_kg", it.toFloat()).apply() }
        }
        viewModelScope.launch {
            availableBudget.collect { prefs.edit().putFloat("available_budget", it.toFloat()).apply() }
        }
        viewModelScope.launch {
            eggPricePerTray.collect { prefs.edit().putFloat("egg_price_per_tray", it.toFloat()).apply() }
        }
        viewModelScope.launch {
            chickenSellingPrice.collect { prefs.edit().putFloat("chicken_selling_price", it.toFloat()).apply() }
        }
        viewModelScope.launch {
            dayOldChickCost.collect { prefs.edit().putFloat("day_old_chick_cost", it.toFloat()).apply() }
        }
        viewModelScope.launch {
            adminOverheadCost.collect { prefs.edit().putFloat("admin_overhead_cost", it.toFloat()).apply() }
        }
        viewModelScope.launch {
            budgetInput.collect { prefs.edit().putString("budget_input", it).apply() }
        }
        viewModelScope.launch {
            bagWeightInput.collect { prefs.edit().putString("bag_weight_input", it).apply() }
        }
        viewModelScope.launch {
            hasOptimizedBudget.collect { prefs.edit().putBoolean("has_optimized_budget", it).apply() }
        }

        // Make sure Maize Husk is pre-populated for upgraded/existing database caches
        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Clear all previous saved stores to start clean as requested by the user
                val storesCleared = prefs.getBoolean("all_stores_cleared_v1", false)
                if (!storesCleared) {
                    repository.deleteAllStores()
                    repository.deleteAllStorePrices()
                    prefs.edit().remove("selected_store_id").putBoolean("all_stores_cleared_v1", true).apply()
                    selectedStoreId.value = null
                }

                // One-time reset of default/loaded selections to false so they start unchecked.
                val resetDone = prefs.getBoolean("initial_selections_reset_v3", false)
                if (!resetDone) {
                    val currentIngs = repository.getAllIngredientsList()
                    currentIngs.forEach { ing ->
                        if (ing.isSelected) {
                            repository.updateIngredient(ing.copy(isSelected = false))
                        }
                    }
                    prefs.edit().putBoolean("initial_selections_reset_v3", true).apply()
                }

                // One-time reset of default/loaded ingredient prices to 0.0 so they start empty/blank.
                val pricesZeroed = prefs.getBoolean("initial_prices_zeroed_v4", false)
                if (!pricesZeroed) {
                    val currentIngs = repository.getAllIngredientsList()
                    currentIngs.forEach { ing ->
                        repository.updateIngredient(ing.copy(pricePerKg = 0.0))
                    }
                    prefs.edit().putBoolean("initial_prices_zeroed_v4", true).apply()
                }

                // Ensure all default ingredients, nutrient targets, inclusion limits and inventories are seeded!
                FeedDatabase.seedDatabaseIfEmpty(db.feedDao())

                // Dynamically update broiler nutrient stage ranges for existing databases
                val targets = repository.getAllNutrientTargetsList()
                val boilerStarter = targets.find { it.birdType == "Broiler" && it.stageName.contains("Starter", ignoreCase = true) }
                if (boilerStarter != null && boilerStarter.maxAgeWeeks != 1) {
                    repository.updateNutrientTarget(boilerStarter.copy(
                        stageName = "Starter (0-1 weeks)",
                        maxAgeWeeks = 1
                    ))
                }
                val broilerGrower = targets.find { it.birdType == "Broiler" && it.stageName.contains("Grower", ignoreCase = true) }
                if (broilerGrower != null && (broilerGrower.minAgeWeeks != 2 || broilerGrower.maxAgeWeeks != 3)) {
                    repository.updateNutrientTarget(broilerGrower.copy(
                        stageName = "Grower (2-3 weeks)",
                        minAgeWeeks = 2,
                        maxAgeWeeks = 3
                    ))
                }
                val broilerFinisher = targets.find { it.birdType == "Broiler" && it.stageName.contains("Finisher", ignoreCase = true) }
                if (broilerFinisher != null && (broilerFinisher.minAgeWeeks != 4 || broilerFinisher.maxAgeWeeks != 100)) {
                    repository.updateNutrientTarget(broilerFinisher.copy(
                        stageName = "Finisher (4-8 weeks)",
                        minAgeWeeks = 4,
                        maxAgeWeeks = 100
                    ))
                }

                // Dynamically update layer nutrient stage names & ranges for existing databases
                val layerStarter = targets.find { it.birdType == "Layer" && it.stageName.contains("Starter", ignoreCase = true) }
                if (layerStarter != null && layerStarter.maxAgeWeeks != 8) {
                    repository.updateNutrientTarget(layerStarter.copy(
                        stageName = "Chick Starter (0-8 weeks)",
                        minAgeWeeks = 0,
                        maxAgeWeeks = 8
                    ))
                }
                val layerGrower = targets.find { it.birdType == "Layer" && it.stageName.contains("Grower", ignoreCase = true) }
                if (layerGrower != null && (layerGrower.minAgeWeeks != 9 || layerGrower.maxAgeWeeks != 18)) {
                    repository.updateNutrientTarget(layerGrower.copy(
                        stageName = "Grower Mash (9-18 weeks)",
                        minAgeWeeks = 9,
                        maxAgeWeeks = 18
                    ))
                }
                val layerMash = targets.find { it.birdType == "Layer" && it.stageName.contains("Layer Mash", ignoreCase = true) }
                if (layerMash != null && (layerMash.minAgeWeeks != 19 || layerMash.maxAgeWeeks != 100)) {
                    repository.updateNutrientTarget(layerMash.copy(
                        stageName = "Layer Mash (19+ weeks)",
                        minAgeWeeks = 19,
                        maxAgeWeeks = 100
                    ))
                }

                // Dynamically update hybrid nutrient stage names & ranges for existing databases
                val hybridStarter = targets.find { it.birdType == "Hybrid / Kienyeji" && it.stageName.contains("Starter", ignoreCase = true) }
                if (hybridStarter != null && (hybridStarter.minAgeWeeks != 0 || hybridStarter.maxAgeWeeks != 8)) {
                    repository.updateNutrientTarget(hybridStarter.copy(
                        stageName = "Kienyeji Starter (0-8 weeks)",
                        minAgeWeeks = 0,
                        maxAgeWeeks = 8
                    ))
                }
                val hybridGrower = targets.find { it.birdType == "Hybrid / Kienyeji" && it.stageName.contains("Grower", ignoreCase = true) }
                if (hybridGrower != null && (hybridGrower.minAgeWeeks != 9 || hybridGrower.maxAgeWeeks != 20)) {
                    repository.updateNutrientTarget(hybridGrower.copy(
                        stageName = "Kienyeji Grower (9-20 weeks)",
                        minAgeWeeks = 9,
                        maxAgeWeeks = 20
                    ))
                }
                val hybridLaying = targets.find { it.birdType == "Hybrid / Kienyeji" && (it.stageName.contains("Layer", ignoreCase = true) || it.stageName.contains("Finisher", ignoreCase = true) || it.stageName.contains("Breeder", ignoreCase = true)) }
                if (hybridLaying != null && (hybridLaying.minAgeWeeks != 21 || hybridLaying.maxAgeWeeks != 100)) {
                    repository.updateNutrientTarget(hybridLaying.copy(
                        stageName = "Kienyeji Laying/Breeder (21+ weeks)",
                        minAgeWeeks = 21,
                        maxAgeWeeks = 100
                    ))
                }

                // Initialize store selection
                val savedStoreId = if (prefs.contains("selected_store_id")) prefs.getInt("selected_store_id", -1) else -1
                if (savedStoreId != -1) {
                    selectStore(savedStoreId)
                } else {
                    val stores = repository.getAllStoresList()
                    if (stores.isNotEmpty()) {
                        selectStore(stores.first().id)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // Automatically fetch nutrient targets when bird type or age changes
        viewModelScope.launch {
            combine(selectedBirdType, selectedAgeWeeks) { type, age ->
                Pair(type, age)
            }.collect { (type, age) ->
                resolveNutrientTarget(type, age)
                feedingDurationDays.value = getStandardDays(type, age)
            }
        }

        // Persist isSwahili changes
        viewModelScope.launch {
            isSwahili.collect { newVal ->
                prefs.edit().putBoolean("is_swahili", newVal).apply()
            }
        }
    }

    fun setSwahili(value: Boolean) {
        isSwahili.value = value
    }

    fun setAppearance(mode: String) {
        appAppearance.value = mode
        prefs.edit().putString("app_appearance", mode).apply()
    }

    fun toggleTheme(currentIsDark: Boolean) {
        val nextMode = if (currentIsDark) "light" else "dark"
        setAppearance(nextMode)
    }

    private fun resolveNutrientTarget(birdType: String, age: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val target = repository.getTargetForAge(birdType, age)
            currentTarget.value = target
        }
    }

    fun runFormulation() {
        val target = currentTarget.value ?: return
        val weight = batchWeight.value

        viewModelScope.launch(Dispatchers.IO) {
            val ings = ingredients.value.filter { it.isSelected }
            val limits = repository.getAllInclusionLimits()
            
            val result = PoultryFeedSolver.solve(
                ingredients = ings,
                target = target,
                inclusionLimits = limits,
                batchWeightKg = weight
            )
            
            solverResult.value = result
            adviceText.value = "" // clear advice on rewrite
        }
    }

    // --- Actions ---

    fun saveCurrentFormulation(title: String) {
        val result = solverResult.value ?: return
        val target = currentTarget.value ?: return
        
        viewModelScope.launch(Dispatchers.IO) {
            val jsonShares = result.ingredientPercentages.entries.associate { it.key to mapOf(
                "percent" to it.value,
                "weight" to (result.ingredientWeightsKg[it.key] ?: 0.0)
            ) }
            val jsonSharesStr = shareMapToJson(jsonShares)

            val achMap = mapOf(
                "Crude Protein" to result.achievedNutrients.crudeProtein,
                "Metabolizable Energy" to result.achievedNutrients.energy,
                "Calcium" to result.achievedNutrients.calcium,
                "Phosphorus" to result.achievedNutrients.phosphorus,
                "Lysine" to result.achievedNutrients.lysine,
                "Methionine" to result.achievedNutrients.methionine,
                "Crude Fiber" to result.achievedNutrients.crudeFiber
            )
            val achMapStr = doubleMapToJson(achMap)
            val taggedTitle = if (title.contains("[Standard Log]")) title else "$title [Standard Log]"

            val formulation = SavedFormulation(
                title = taggedTitle,
                birdType = target.birdType,
                ageWeeks = selectedAgeWeeks.value,
                targetStage = target.stageName,
                batchWeightKg = batchWeight.value,
                totalCost = result.totalCost,
                costPerKg = result.costPerKg,
                ingredientSharesJson = jsonSharesStr,
                achievedNutrientsJson = achMapStr
            )

            val id = repository.insertFormulation(formulation)
            
            // Log automatically in Manufacturing logbook
            val log = ManufacturingLog(
                formulationId = id.toInt(),
                formulationTitle = taggedTitle,
                batchWeightKg = batchWeight.value,
                costPerKg = result.costPerKg,
                totalCost = result.totalCost,
                notes = "Auto-created on solve formulation."
            )
            repository.insertManufacturingLog(log)

            // Deduct raw ingredients from inventory, add complete feed
            result.ingredientWeightsKg.forEach { (name, weightUsed) ->
                val inv = repository.getInventoryByName(name)
                val currentStock = inv?.stockKg ?: 0.0
                repository.insertInventory(
                    FeedInventory(
                        name = name,
                        type = "Ingredient",
                        stockKg = maxOf(0.0, currentStock - weightUsed),
                        lastUpdated = System.currentTimeMillis()
                    )
                )
            }

            // Put feed to inventory
            val feedInvName = "Formulation: $title"
            val feedInv = repository.getInventoryByName(feedInvName)
            val currentFeedStock = feedInv?.stockKg ?: 0.0
            repository.insertInventory(
                FeedInventory(
                    name = feedInvName,
                    type = "Formulated Feed",
                    stockKg = currentFeedStock + batchWeight.value,
                    lastUpdated = System.currentTimeMillis()
                )
            )
            withContext(Dispatchers.Main) {
                resetFormulationSession()
            }
        }
    }

    fun saveCustomFormulation(
        title: String,
        costPerKg: Double,
        totalCost: Double,
        ingredientPercentages: Map<String, Double>,
        achievedNutrients: Map<String, Double>
    ) {
        val target = currentTarget.value ?: return
        val weight = batchWeight.value

        viewModelScope.launch(Dispatchers.IO) {
            val jsonShares = ingredientPercentages.entries.associate { it.key to mapOf(
                "percent" to it.value,
                "weight" to ((it.value / 100.0) * weight)
            ) }
            val jsonSharesStr = shareMapToJson(jsonShares)
            val achMapStr = doubleMapToJson(achievedNutrients)
            val taggedTitle = if (title.contains("[Budget Optimized]")) title else "$title [Budget Optimized]"

            val formulation = SavedFormulation(
                title = taggedTitle,
                birdType = target.birdType,
                ageWeeks = selectedAgeWeeks.value,
                targetStage = target.stageName,
                batchWeightKg = weight,
                totalCost = totalCost,
                costPerKg = costPerKg,
                ingredientSharesJson = jsonSharesStr,
                achievedNutrientsJson = achMapStr
            )

            val id = repository.insertFormulation(formulation)

            // Log automatically in Manufacturing logbook
            val log = ManufacturingLog(
                formulationId = id.toInt(),
                formulationTitle = taggedTitle,
                batchWeightKg = weight,
                costPerKg = costPerKg,
                totalCost = totalCost,
                notes = "Auto-created on custom budget formulation."
            )
            repository.insertManufacturingLog(log)

            // Deduct raw ingredients from inventory, add complete feed
            ingredientPercentages.forEach { (name, pct) ->
                val weightUsed = (pct / 100.0) * weight
                val inv = repository.getInventoryByName(name)
                val currentStock = inv?.stockKg ?: 0.0
                repository.insertInventory(
                    FeedInventory(
                        name = name,
                        type = "Ingredient",
                        stockKg = maxOf(0.0, currentStock - weightUsed),
                        lastUpdated = System.currentTimeMillis()
                    )
                )
            }

            // Put feed to inventory
            val feedInvName = "Formulation: $title"
            val feedInv = repository.getInventoryByName(feedInvName)
            val currentFeedStock = feedInv?.stockKg ?: 0.0
            repository.insertInventory(
                FeedInventory(
                    name = feedInvName,
                    type = "Formulated Feed",
                    stockKg = currentFeedStock + weight,
                    lastUpdated = System.currentTimeMillis()
                )
            )
            withContext(Dispatchers.Main) {
                resetFormulationSession()
            }
        }
    }

    fun deleteFormulation(id: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteFormulationById(id)
        }
    }

    fun selectStore(storeId: Int?) {
        selectedStoreId.value = storeId
        viewModelScope.launch(Dispatchers.IO) {
            if (storeId != null) {
                prefs.edit().putInt("selected_store_id", storeId).apply()
                // Load selected ingredient names for this store
                val saved = prefs.getStringSet("selected_ingredients_store_${storeId}", null)
                if (saved != null) {
                    selectedIngredientNames.value = saved
                } else {
                    // Default to unchecked/empty selection
                    selectedIngredientNames.value = emptySet()
                }
            } else {
                prefs.edit().remove("selected_store_id").apply()
                selectedIngredientNames.value = emptySet()
            }
            runFormulation()
        }
    }

    fun createAndSelectStore(name: String, onComplete: (Int) -> Unit = {}) {
        viewModelScope.launch(Dispatchers.IO) {
            val existing = repository.getStoreByName(name)
            val storeId = if (existing != null) {
                existing.id
            } else {
                repository.insertStore(Store(name = name)).toInt()
            }
            selectStore(storeId)
            withContext(Dispatchers.Main) {
                onComplete(storeId)
            }
        }
    }

    fun deleteStore(store: Store) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteStore(store)
            repository.deletePricesForStore(store.id)
            if (selectedStoreId.value == store.id) {
                selectStore(null)
            }
        }
    }

    suspend fun getAllStoresAsync(): List<Store> {
        return repository.getAllStoresList()
    }

    fun renameStore(store: Store, newName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertStore(Store(id = store.id, name = newName))
        }
    }

    fun updateStorePrice(storeId: Int, ingredientName: String, price: Double) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertStorePrice(
                StoreIngredientPrice(
                    storeId = storeId,
                    ingredientName = ingredientName,
                    price = price
                )
            )
            // Save to history for general logging
            val currentIngs = repository.getAllIngredientsList()
            val matchIng = currentIngs.find { it.name.lowercase().trim() == ingredientName.lowercase().trim() }
            if (matchIng != null) {
                repository.insertPriceHistory(
                    PriceHistory(
                        ingredientId = matchIng.id,
                        ingredientName = matchIng.name,
                        oldPrice = matchIng.pricePerKg,
                        newPrice = price
                    )
                )
            }
            // Trigger recalculation
            runFormulation()
        }
    }

    fun updateIngredientPrice(ingredient: Ingredient, newPrice: Double) {
        val storeId = selectedStoreId.value
        if (storeId != null) {
            updateStorePrice(storeId, ingredient.name, newPrice)
        }
    }

    fun toggleIngredientSelection(ingredient: Ingredient) {
        val current = selectedIngredientNames.value.toMutableSet()
        if (current.contains(ingredient.name)) {
            current.remove(ingredient.name)
        } else {
            current.add(ingredient.name)
        }
        selectedIngredientNames.value = current
        val storeId = selectedStoreId.value
        if (storeId != null) {
            prefs.edit().putStringSet("selected_ingredients_store_${storeId}", current).apply()
        }
        if (solverResult.value != null) {
            runFormulation()
        }
    }

    fun addCustomIngredient(
        name: String,
        category: String,
        cp: Double,
        me: Double,
        ca: Double,
        p: Double,
        lys: Double,
        met: Double,
        cf: Double,
        price: Double
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val ing = Ingredient(
                name = name,
                category = category,
                crudeProtein = cp,
                energy = me,
                calcium = ca,
                phosphorus = p,
                lysine = lys,
                methionine = met,
                crudeFiber = cf,
                pricePerKg = price,
                isCustom = true,
                isSelected = true
            )
            repository.insertIngredient(ing)
            // Also save the price for the current store if a store is selected
            val storeId = selectedStoreId.value
            if (storeId != null) {
                repository.insertStorePrice(
                    StoreIngredientPrice(
                        storeId = storeId,
                        ingredientName = name,
                        price = price
                    )
                )
            }
        }
    }

    fun saveIngredient(ingredient: Ingredient) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertIngredient(ingredient)
            // Also save/update the price for the current store if a store is selected
            val storeId = selectedStoreId.value
            if (storeId != null) {
                repository.insertStorePrice(
                    StoreIngredientPrice(
                        storeId = storeId,
                        ingredientName = ingredient.name,
                        price = ingredient.pricePerKg
                    )
                )
            }
            if (solverResult.value != null) {
                runFormulation()
            }
        }
    }

    fun deleteIngredient(ingredient: Ingredient) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteIngredient(ingredient)
            if (solverResult.value != null) {
                runFormulation()
            }
        }
    }

    fun updateNutrientTarget(target: NutrientTarget) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateNutrientTarget(target)
            resolveNutrientTarget(selectedBirdType.value, selectedAgeWeeks.value)
        }
    }

    fun updateInclusionLimit(ingredientName: String, minVal: Double, maxVal: Double, isFixed: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            val limit = InclusionLimit(
                ingredientName = ingredientName,
                minPercent = minVal,
                maxPercent = maxVal,
                isFixed = isFixed
            )
            repository.insertInclusionLimit(limit)
        }
    }

    fun adjustInventoryAmount(entry: FeedInventory, addedKg: Double) {
        viewModelScope.launch(Dispatchers.IO) {
            val nextStock = maxOf(0.0, entry.stockKg + addedKg)
            repository.insertInventory(entry.copy(stockKg = nextStock, lastUpdated = System.currentTimeMillis()))
        }
    }

    // --- AI Feed Advisor Actions ---
    fun askAIAdvisor(customQuestion: String = "") {
        val result = solverResult.value ?: return
        val target = currentTarget.value ?: return
        
        isAdviceLoading.value = true
        adviceText.value = "Consulting smart advisor..."

        viewModelScope.launch {
            val actualQuestion = customQuestion.ifBlank { "Explain this recipe and suggest improvements." }
            currentAIQuestion.value = actualQuestion

            val answer = FeedAdvisorService.getAdvice(
                birdType = target.birdType,
                ageWeeks = selectedAgeWeeks.value,
                stageName = target.stageName,
                batchWeightKg = batchWeight.value,
                costPerKg = result.costPerKg,
                recipeIngredients = result.ingredientWeightsKg,
                achieved = result.achievedNutrients,
                target = target,
                userQuestion = actualQuestion,
                isSwahili = isSwahili.value
            )
            
            adviceText.value = answer
            isAdviceLoading.value = false
        }
    }

    // --- Helper JSON serializers ---
    private fun shareMapToJson(map: Map<String, Map<String, Double>>): String {
        return map.entries.joinToString(separator = ";") { entry ->
            val innerVal = entry.value
            "${entry.key}:${innerVal["percent"]},${innerVal["weight"]}"
        }
    }

    fun jsonToShareMap(json: String): Map<String, Pair<Double, Double>> {
        if (json.isBlank()) return emptyMap()
        return try {
            json.split(";").associate { item ->
                val parts = item.split(":")
                val name = parts[0]
                val vals = parts[1].split(",")
                val pct = vals[0].toDoubleOrNull() ?: 0.0
                val wt = vals[1].toDoubleOrNull() ?: 0.0
                name to Pair(pct, wt)
            }
        } catch (e: Exception) {
            emptyMap()
        }
    }

    private fun doubleMapToJson(map: Map<String, Double>): String {
        return map.entries.joinToString(separator = ";") { "${it.key}:${it.value}" }
    }

    fun jsonToDoubleMap(json: String): Map<String, Double> {
        if (json.isBlank()) return emptyMap()
        return try {
            json.split(";").associate { item ->
                val parts = item.split(":")
                parts[0] to (parts[1].toDoubleOrNull() ?: 0.0)
            }
        } catch (e: Exception) {
            emptyMap()
        }
    }

    // --- standard poultry statistics constants ---
    fun getStandardDays(birdType: String, age: Int): Int {
        return when (birdType) {
            "Broiler" -> when {
                age <= 1 -> 7
                age <= 3 -> 14
                else -> 10
            }
            "Layer" -> when {
                age <= 8 -> 56
                age <= 18 -> 70
                else -> 365
            }
            else -> when { // Hybrid / Kienyeji
                age <= 8 -> 56
                age <= 20 -> 84
                else -> 365
            }
        }
    }

    fun getStandardNutritionInfo(birdType: String, age: Int): StandardStats {
        return when (birdType) {
            "Broiler" -> when {
                age <= 1 -> StandardStats(dailyFeedInTakeGrams = 35.0, expectedBodyWeightGrams = 200.0, totalFcr = 1.0)
                age <= 3 -> StandardStats(dailyFeedInTakeGrams = 90.0, expectedBodyWeightGrams = 1100.0, totalFcr = 1.4)
                else -> StandardStats(dailyFeedInTakeGrams = 160.0, expectedBodyWeightGrams = 2200.0, totalFcr = 1.7)
            }
            "Layer" -> when {
                age <= 8 -> StandardStats(dailyFeedInTakeGrams = 38.0, expectedBodyWeightGrams = 650.0, totalFcr = 2.4)
                age <= 18 -> StandardStats(dailyFeedInTakeGrams = 75.0, expectedBodyWeightGrams = 1450.0, totalFcr = 3.1)
                else -> StandardStats(dailyFeedInTakeGrams = 115.0, expectedBodyWeightGrams = 2000.0, totalFcr = 2.1) // as eggs lay FCR is based on egg weight, approx
            }
            else -> when { // Hybrid / Kienyeji
                age <= 8 -> StandardStats(dailyFeedInTakeGrams = 42.0, expectedBodyWeightGrams = 600.0, totalFcr = 2.5)
                age <= 20 -> StandardStats(dailyFeedInTakeGrams = 80.0, expectedBodyWeightGrams = 1350.0, totalFcr = 3.5)
                else -> StandardStats(dailyFeedInTakeGrams = 95.0, expectedBodyWeightGrams = 1750.0, totalFcr = 2.8)
            }
        }
    }

    // --- Research Studies & Customizer States ---
    val isVerifyingStandards = MutableStateFlow(false)
    val verifiedStandardsText = MutableStateFlow("")

    val isCustomizingRecipe = MutableStateFlow(false)
    val customizedRecipeText = MutableStateFlow("")

    fun verifyStandardsWithAI() {
        val birdType = selectedBirdType.value
        val ageWeeks = selectedAgeWeeks.value
        if (ageWeeks <= 0) {
            isVerifyingStandards.value = false
            verifiedStandardsText.value = if (isSwahili.value) "Chagua hatua ya ukuaji hapo juu ili kuona uthibitisho wa kitafiti." else "Select a growth stage above to view standard research verification."
            return
        }
        val target = currentTarget.value

        isVerifyingStandards.value = true
        verifiedStandardsText.value = "Consulting agricultural research databases & verifying standard nutrition studies..."

        viewModelScope.launch {
            val targetProteinStr = target?.let { "standard target Crude Protein of ${it.crudeProtein}%" } ?: "general requirements"
            val systemPrompt = "You are an expert poultry scientist. Keep your answers brief, highly informative, research-backed, and under 250 words. Provide explanations in both Swahili and English."
            val userPrompt = """
                Perform professional studies verification and literature research on standard poultry guidelines:
                - Bird Type: $birdType
                - Age: $ageWeeks Weeks
                - Target Nutritional Profile: $targetProteinStr
                
                Please verify and provide:
                1. Scientific consensus/recommendations on daily feed intake (g) and energy requirements (kcal).
                2. Standard optimal FCR (Feed Conversion Ratio) for this breed at this age.
                3. List of verified research or expert studies supporting these numbers.
                4. Translation/summary in Swahili explaining "Ushauri wa Kitafiti".
            """.trimIndent()

            val answer = FeedAdvisorService.getCustomAdvice(userPrompt, systemPrompt)
            verifiedStandardsText.value = answer
            isVerifyingStandards.value = false
        }
    }

    fun customizeFormulaWithBudget(targetBudget: Double) {
        val result = solverResult.value
        val target = currentTarget.value ?: return

        isCustomizingRecipe.value = true
        customizedRecipeText.value = "Generating customized alternative formula..."

        viewModelScope.launch {
            val availableOnFarm = ingredients.value.filter { it.isSelected }
            val materialsStr = availableOnFarm.joinToString("\n") {
                "  - ${it.name}: Price TSh ${it.pricePerKg}/kg, CP ${it.crudeProtein}%, ME ${it.energy} kcal"
            }

            val currentCostStr = if (result != null) "TSh ${String.format("%.2f", result.totalCost)}" else "Not formulated yet"

            val systemPrompt = "You are an expert poultry nutritionist advising smallholder farmers. Provide exact percentage ratios, and explain which ingredient shares to reduce or omit. Keep your answers practical and under 300 words. Write in both Swahili and English. You MUST output a clean structured section at the beginning using ---START_RECIPE--- and ---END_RECIPE--- tags with the precise ingredient percentages and batch weights."
            val userPrompt = """
                The farmer has formulated a feed recipe but it is too expensive. 
                They want an alternative customized recipe for a fixed budget of $targetBudget TSh.
                
                Bird Type: ${target.birdType}
                Growth stage: ${target.stageName} (Age: ${selectedAgeWeeks.value} weeks)
                Target Feed Weight: ${batchWeight.value} Kg
                Current formulation cost: $currentCostStr
                
                On-farm materials available:
                $materialsStr
                
                To allow the app to display a beautiful column/table presentation, you MUST start your reply with a section formatted EXACTLY as follows:
                ---START_RECIPE---
                Ingredient Name: X% | Y Kg
                Ingredient Name: A% | B Kg
                ---END_RECIPE---
                
                Replace 'Ingredient Name' with the EXACT ingredient name from the on-farm materials listed above in English or their original names (e.g., 'Soybean Meal', 'Maize (Mahindi)', 'Limestone', 'Bone Meal', etc.). Use the farmer's batch weight of ${batchWeight.value} Kg to calculate the absolute weights in Kg. Do not include any other text inside this block.
                
                After this structured block, write your detailed advice, breakdown, what ingredients to reduce or omit, and guidelines in both Swahili and English.
            """.trimIndent()

            val answer = FeedAdvisorService.getCustomAdvice(userPrompt, systemPrompt)
            customizedRecipeText.value = answer
            isCustomizingRecipe.value = false
        }
    }
}

data class StandardStats(
    val dailyFeedInTakeGrams: Double,
    val expectedBodyWeightGrams: Double,
    val totalFcr: Double
)
