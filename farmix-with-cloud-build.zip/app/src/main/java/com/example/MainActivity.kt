package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.ui.FeedAppHome
import com.example.ui.viewmodel.PoultryViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: PoultryViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FeedAppHome(viewModel = viewModel)
        }
    }
}
