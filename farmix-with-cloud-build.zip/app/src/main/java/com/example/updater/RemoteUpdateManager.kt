package com.example.updater

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import org.json.JSONObject

data class UpdateInfo(
    val latestVersionCode: Int,
    val latestVersionName: String,
    val downloadUrl: String,
    val releaseNotes: String,
    val isUpdateAvailable: Boolean
)

object RemoteUpdateManager {
    private val client = OkHttpClient()

    val updateUrl = MutableStateFlow("https://raw.githubusercontent.com/geraldgeras/mock-apk/main/update-manifest.json")
    val isCheckingUpdate = MutableStateFlow(false)
    val updateInfo = MutableStateFlow<UpdateInfo?>(null)
    val showUpdateDialog = MutableStateFlow(false)

    private val _downloadProgress = MutableStateFlow<Float?>(null) // null means not downloading
    val downloadProgress: StateFlow<Float?> = _downloadProgress

    private val _statusMessage = MutableStateFlow<String>("")
    val statusMessage: StateFlow<String> = _statusMessage

    /**
     * Checks a remote remote JSON URL for updates.
     * Expected format:
     * {
     *   "versionCode": 2,
     *   "versionName": "1.1.0",
     *   "apkUrl": "https://example.com/app-release.apk",
     *   "releaseNotes": "A balanced and safe poultry feed formulation engine."
     * }
     */
    suspend fun checkUpdates(context: Context, jsonUrl: String): UpdateInfo = withContext(Dispatchers.IO) {
        val currentVersionCode = getAppVersionCode(context)
        val currentVersionName = getAppVersionName(context)

        try {
            if (jsonUrl.isBlank() || !jsonUrl.startsWith("http")) {
                throw Exception("Invalid URL configured")
            }
            val request = Request.Builder().url(jsonUrl).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) throw Exception("Server returned code ${response.code}")
                val body = response.body?.string() ?: throw Exception("Empty response body")
                val json = JSONObject(body)

                val latestCode = json.optInt("versionCode", 1)
                val latestName = json.optString("versionName", "1.0")
                val apkUrl = json.optString("apkUrl", "")
                val releaseNotes = json.optString("releaseNotes", "")

                val isAvailable = latestCode > currentVersionCode

                UpdateInfo(
                    latestVersionCode = latestCode,
                    latestVersionName = latestName,
                    downloadUrl = apkUrl,
                    releaseNotes = releaseNotes,
                    isUpdateAvailable = isAvailable
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
            val errorMessage = e.localizedMessage ?: "Connection or server error"
            UpdateInfo(
                latestVersionCode = currentVersionCode,
                latestVersionName = currentVersionName,
                downloadUrl = "",
                releaseNotes = if (jsonUrl.isNotBlank() && jsonUrl.startsWith("http")) {
                    "Error checking updates: $errorMessage\n\nPlease verify your repository or update server. No updates will be applied."
                } else {
                    "No remote update source configured. Enter a valid JSON manifest URL in Settings to check for updates."
                },
                isUpdateAvailable = false
            )
        }
    }

    @Suppress("DEPRECATION")
    fun getAppVersionCode(context: Context): Int {
        return try {
            val pInfo = context.packageManager.getPackageInfo(context.packageName, 0)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pInfo.longVersionCode.toInt()
            } else {
                pInfo.versionCode
            }
        } catch (e: Exception) {
            1
        }
    }

    fun getAppVersionName(context: Context): String {
        return try {
            val pInfo = context.packageManager.getPackageInfo(context.packageName, 0)
            pInfo.versionName ?: "1.0"
        } catch (e: Exception) {
            "1.0"
        }
    }

    /**
     * Downloads an APK to cache directory and fires up system package installer.
     */
    suspend fun downloadAndInstallApk(context: Context, downloadUrl: String): Boolean = withContext(Dispatchers.IO) {
        _statusMessage.value = "Starting download..."
        _downloadProgress.value = 0f

        try {
            val request = Request.Builder().url(downloadUrl).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    _statusMessage.value = "Download failed: Server error ${response.code}"
                    _downloadProgress.value = null
                    return@withContext false
                }

                val body = response.body ?: throw Exception("Response body is empty")
                val contentLength = body.contentLength()
                val inputStream: InputStream = body.byteStream()

                val cacheDir = File(context.cacheDir, "updates")
                if (!cacheDir.exists()) cacheDir.mkdirs()
                val apkFile = File(cacheDir, "app_update.apk")
                if (apkFile.exists()) apkFile.delete()

                val outputStream = FileOutputStream(apkFile)
                val buffer = ByteArray(4096)
                var bytesRead: Int
                var totalBytesRead = 0L

                while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                    outputStream.write(buffer, 0, bytesRead)
                    totalBytesRead += bytesRead
                    if (contentLength > 0) {
                        val progress = (totalBytesRead.toFloat() / contentLength.toFloat())
                        _downloadProgress.value = progress
                        _statusMessage.value = "Downloading update: ${(progress * 100).toInt()}%"
                    } else {
                        _statusMessage.value = "Downloading update: ${(totalBytesRead / 1024)} KB"
                    }
                }

                outputStream.flush()
                outputStream.close()
                inputStream.close()

                _statusMessage.value = "Download complete! Opening installer..."
                _downloadProgress.value = 1f

                // Direct to install function
                return@withContext installApkFile(context, apkFile)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            _statusMessage.value = "Error during download: ${e.localizedMessage}"
            _downloadProgress.value = null
            false
        }
    }

    private fun installApkFile(context: Context, file: File): Boolean {
        return try {
            val authority = "${context.packageName}.fileprovider"
            val uri: Uri = FileProvider.getUriForFile(context, authority, file)

            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
            }

            // Checks package installer unknowns settings for SDK >= O
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (!context.packageManager.canRequestPackageInstalls()) {
                    val permIntent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).apply {
                        data = Uri.parse("package:${context.packageName}")
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(permIntent)
                    _statusMessage.value = "Please grant permission to install unknown apps first, then retry."
                    return false
                }
            }

            context.startActivity(intent)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            _statusMessage.value = "Installation issue: ${e.localizedMessage}"
            false
        }
    }
}
