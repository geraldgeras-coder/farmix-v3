package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@Database(
    entities = [
        Ingredient::class,
        NutrientTarget::class,
        InclusionLimit::class,
        SavedFormulation::class,
        PriceHistory::class,
        ManufacturingLog::class,
        FeedInventory::class,
        Store::class,
        StoreIngredientPrice::class
    ],
    version = 2,
    exportSchema = false
)
abstract class FeedDatabase : RoomDatabase() {
    abstract fun feedDao(): FeedDao

    companion object {
        @Volatile
        private var INSTANCE: FeedDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): FeedDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    FeedDatabase::class.java,
                    "poultry_feed_db"
                )
                    .fallbackToDestructiveMigration(true)
                    .build()
                INSTANCE = instance
                instance
            }
        }

        suspend fun seedDatabaseIfEmpty(dao: FeedDao) {
            // Seed DEFAULT INGREDIENTS
            val defaultIngredients = listOf(
                // Energy Sources
                Ingredient(
                    name = "Maize (Mahindi)",
                    category = "Energy",
                    crudeProtein = 8.5,
                    energy = 3370.0,
                    calcium = 0.02,
                    phosphorus = 0.27,
                    lysine = 0.24,
                    methionine = 0.18,
                    crudeFiber = 2.2,
                    pricePerKg = 40.0,
                    isCustom = false
                ),
                Ingredient(
                    name = "Broken Rice",
                    category = "Energy",
                    crudeProtein = 7.2,
                    energy = 3100.0,
                    calcium = 0.04,
                    phosphorus = 0.12,
                    lysine = 0.26,
                    methionine = 0.16,
                    crudeFiber = 1.0,
                    pricePerKg = 35.0,
                    isCustom = false
                ),
                Ingredient(
                    name = "Sorghum (Mtama)",
                    category = "Energy",
                    crudeProtein = 10.0,
                    energy = 3200.0,
                    calcium = 0.03,
                    phosphorus = 0.30,
                    lysine = 0.22,
                    methionine = 0.15,
                    crudeFiber = 2.5,
                    pricePerKg = 38.0,
                    isCustom = false
                ),
                Ingredient(
                    name = "Cassava Meal",
                    category = "Energy",
                    crudeProtein = 2.5,
                    energy = 3000.0,
                    calcium = 0.12,
                    phosphorus = 0.11,
                    lysine = 0.10,
                    methionine = 0.05,
                    crudeFiber = 3.5,
                    pricePerKg = 25.0,
                    isCustom = false
                ),
                Ingredient(
                    name = "Maize Husk (Makapi ya Mahindi)",
                    category = "Energy",
                    crudeProtein = 7.5,
                    energy = 2600.0,
                    calcium = 0.04,
                    phosphorus = 0.25,
                    lysine = 0.22,
                    methionine = 0.15,
                    crudeFiber = 11.0,
                    pricePerKg = 25.0,
                    isCustom = false
                ),
                Ingredient(
                    name = "Wheat Bran (Pumba za Ngano)",
                    category = "Energy",
                    crudeProtein = 15.0,
                    energy = 1800.0,
                    calcium = 0.12,
                    phosphorus = 1.00,
                    lysine = 0.60,
                    methionine = 0.20,
                    crudeFiber = 11.0,
                    pricePerKg = 30.0,
                    isCustom = false
                ),

                // Protein Sources
                Ingredient(
                    name = "Soybean Meal",
                    category = "Protein",
                    crudeProtein = 44.0,
                    energy = 2240.0,
                    calcium = 0.29,
                    phosphorus = 0.65,
                    lysine = 2.70,
                    methionine = 0.62,
                    crudeFiber = 5.0,
                    pricePerKg = 85.0,
                    isCustom = false
                ),
                Ingredient(
                    name = "Sunflower Seed Cake (Mashapo ya Alizeti)",
                    category = "Protein",
                    crudeProtein = 30.0,
                    energy = 2100.0,
                    calcium = 0.40,
                    phosphorus = 0.90,
                    lysine = 1.10,
                    methionine = 0.65,
                    crudeFiber = 14.0,
                    pricePerKg = 55.0,
                    isCustom = false
                ),
                Ingredient(
                    name = "Groundnut Cake (Mashapo ya Karanga)",
                    category = "Protein",
                    crudeProtein = 45.0,
                    energy = 2300.0,
                    calcium = 0.15,
                    phosphorus = 0.60,
                    lysine = 1.60,
                    methionine = 0.55,
                    crudeFiber = 6.0,
                    pricePerKg = 65.0,
                    isCustom = false
                ),
                Ingredient(
                    name = "Full-fat Soybean Meal (Soya Nzima)",
                    category = "Protein",
                    crudeProtein = 38.0,
                    energy = 3300.0,
                    calcium = 0.25,
                    phosphorus = 0.55,
                    lysine = 2.40,
                    methionine = 0.54,
                    crudeFiber = 5.0,
                    pricePerKg = 95.0,
                    isCustom = false
                ),
                Ingredient(
                    name = "Black Soldier Fly Larvae Meal (Mabuu ya BSF)",
                    category = "Protein",
                    crudeProtein = 45.0,
                    energy = 2900.0,
                    calcium = 1.50,
                    phosphorus = 0.90,
                    lysine = 2.80,
                    methionine = 0.85,
                    crudeFiber = 7.0,
                    pricePerKg = 110.0,
                    isCustom = false
                ),
                Ingredient(
                    name = "Cotton Seed Cake",
                    category = "Protein",
                    crudeProtein = 34.0,
                    energy = 2000.0,
                    calcium = 0.30,
                    phosphorus = 0.85,
                    lysine = 1.20,
                    methionine = 0.45,
                    crudeFiber = 11.0,
                    pricePerKg = 50.0,
                    isCustom = false
                ),
                Ingredient(
                    name = "Fish Meal (Omena)",
                    category = "Protein",
                    crudeProtein = 60.0,
                    energy = 2850.0,
                    calcium = 5.00,
                    phosphorus = 3.00,
                    lysine = 4.50,
                    methionine = 1.80,
                    crudeFiber = 1.0,
                    pricePerKg = 120.0,
                    isCustom = false
                ),
                Ingredient(
                    name = "Blood Meal",
                    category = "Protein",
                    crudeProtein = 80.0,
                    energy = 2400.0,
                    calcium = 0.30,
                    phosphorus = 0.25,
                    lysine = 7.00,
                    methionine = 1.20,
                    crudeFiber = 1.5,
                    pricePerKg = 110.0,
                    isCustom = false
                ),

                // Minerals
                Ingredient(
                    name = "Limestone",
                    category = "Mineral",
                    crudeProtein = 0.0,
                    energy = 0.0,
                    calcium = 38.00,
                    phosphorus = 0.00,
                    lysine = 0.00,
                    methionine = 0.00,
                    crudeFiber = 0.0,
                    pricePerKg = 15.0,
                    isCustom = false
                ),
                Ingredient(
                    name = "DCP (Dicalcium Phosphate)",
                    category = "Mineral",
                    crudeProtein = 0.0,
                    energy = 0.0,
                    calcium = 21.00,
                    phosphorus = 18.00,
                    lysine = 0.00,
                    methionine = 0.00,
                    crudeFiber = 0.0,
                    pricePerKg = 90.0,
                    isCustom = false
                ),
                Ingredient(
                    name = "Salt (Chumvi)",
                    category = "Mineral",
                    crudeProtein = 0.0,
                    energy = 0.0,
                    calcium = 0.0,
                    phosphorus = 0.0,
                    lysine = 0.0,
                    methionine = 0.0,
                    crudeFiber = 0.0,
                    pricePerKg = 20.0,
                    isCustom = false
                ),

                // Additives
                Ingredient(
                    name = "Premix",
                    category = "Additive",
                    crudeProtein = 0.0,
                    energy = 0.0,
                    calcium = 10.00,
                    phosphorus = 2.00,
                    lysine = 1.00,
                    methionine = 1.00,
                    crudeFiber = 0.0,
                    pricePerKg = 250.0,
                    isCustom = false
                ),
                Ingredient(
                    name = "Toxin Binder",
                    category = "Additive",
                    crudeProtein = 0.0,
                    energy = 0.0,
                    calcium = 0.0,
                    phosphorus = 0.0,
                    lysine = 0.0,
                    methionine = 0.0,
                    crudeFiber = 0.0,
                    pricePerKg = 300.0,
                    isCustom = false
                ),
                Ingredient(
                    name = "Enzymes",
                    category = "Additive",
                    crudeProtein = 0.0,
                    energy = 0.0,
                    calcium = 0.0,
                    phosphorus = 0.0,
                    lysine = 0.0,
                    methionine = 0.0,
                    crudeFiber = 0.0,
                    pricePerKg = 500.0,
                    isCustom = false
                )
            )

            val currentIngs = dao.getAllIngredientsList()
            if (currentIngs.size < 10) {
                defaultIngredients.forEach { ing ->
                    if (currentIngs.none { it.name.lowercase().trim() == ing.name.lowercase().trim() }) {
                        dao.insertIngredient(ing)
                    }
                }
            } else {
                // Ensure any missing standard ones are loaded
                defaultIngredients.forEach { ing ->
                    if (currentIngs.none { it.name.lowercase().trim() == ing.name.lowercase().trim() }) {
                        dao.insertIngredient(ing)
                    }
                }
            }

            // Seed INCLUSION LIMITS
            val defaultLimits = listOf(
                InclusionLimit("Salt (Chumvi)", 0.3, 0.5, isFixed = false),
                InclusionLimit("Premix", 0.25, 0.25, isFixed = true),
                InclusionLimit("Fish Meal (Omena)", 0.0, 10.0, isFixed = false),
                InclusionLimit("Toxin Binder", 0.1, 0.1, isFixed = true),
                InclusionLimit("Enzymes", 0.05, 0.05, isFixed = true),
                InclusionLimit("Cotton Seed Cake", 0.0, 8.0, isFixed = false),
                InclusionLimit("Blood Meal", 0.0, 5.0, isFixed = false)
            )
            val currentLimits = dao.getAllInclusionLimits()
            if (currentLimits.isEmpty()) {
                defaultLimits.forEach { dao.insertInclusionLimit(it) }
            } else {
                defaultLimits.forEach { limit ->
                    if (currentLimits.none { it.ingredientName.lowercase().trim() == limit.ingredientName.lowercase().trim() }) {
                        dao.insertInclusionLimit(limit)
                    }
                }
            }

            // Seed NUTRITIONAL TARGETS (Poultry Categories)
            val defaultTargets = listOf(
                // 1. Broilers
                NutrientTarget(
                    birdType = "Broiler",
                    stageName = "Starter (0-3 weeks)",
                    minAgeWeeks = 0,
                    maxAgeWeeks = 3,
                    crudeProtein = 22.0,
                    energy = 3000.0,
                    calcium = 1.00,
                    phosphorus = 0.45,
                    lysine = 1.20,
                    methionine = 0.50,
                    crudeFiber = 5.0
                ),
                NutrientTarget(
                    birdType = "Broiler",
                    stageName = "Grower (4-5 weeks)",
                    minAgeWeeks = 4,
                    maxAgeWeeks = 5,
                    crudeProtein = 20.0,
                    energy = 3100.0,
                    calcium = 0.90,
                    phosphorus = 0.40,
                    lysine = 1.05,
                    methionine = 0.45,
                    crudeFiber = 5.0
                ),
                NutrientTarget(
                    birdType = "Broiler",
                    stageName = "Finisher (6-8 weeks)",
                    minAgeWeeks = 6,
                    maxAgeWeeks = 8,
                    crudeProtein = 18.0,
                    energy = 3200.0,
                    calcium = 0.85,
                    phosphorus = 0.35,
                    lysine = 0.95,
                    methionine = 0.40,
                    crudeFiber = 5.0
                ),

                // 2. Layers
                NutrientTarget(
                    birdType = "Layer",
                    stageName = "Chick Starter (0-8 weeks)",
                    minAgeWeeks = 0,
                    maxAgeWeeks = 8,
                    crudeProtein = 19.0,
                    energy = 2850.0,
                    calcium = 1.00,
                    phosphorus = 0.40,
                    lysine = 0.95,
                    methionine = 0.38,
                    crudeFiber = 5.0
                ),
                NutrientTarget(
                    birdType = "Layer",
                    stageName = "Grower (9-18 weeks)",
                    minAgeWeeks = 9,
                    maxAgeWeeks = 18,
                    crudeProtein = 16.0,
                    energy = 2750.0,
                    calcium = 0.90,
                    phosphorus = 0.35,
                    lysine = 0.70,
                    methionine = 0.30,
                    crudeFiber = 5.5
                ),
                NutrientTarget(
                    birdType = "Layer",
                    stageName = "Layer Mash (19+ weeks)",
                    minAgeWeeks = 19,
                    maxAgeWeeks = 100, // represent 19+ weeks
                    crudeProtein = 17.5,
                    energy = 2750.0,
                    calcium = 3.80,
                    phosphorus = 0.42,
                    lysine = 0.85,
                    methionine = 0.36,
                    crudeFiber = 6.0
                ),

                // 3. Hybrid / Kienyeji Chickens
                NutrientTarget(
                    birdType = "Hybrid / Kienyeji",
                    stageName = "Starter (0-8 weeks)",
                    minAgeWeeks = 0,
                    maxAgeWeeks = 8,
                    crudeProtein = 18.0,
                    energy = 2800.0,
                    calcium = 0.95,
                    phosphorus = 0.40,
                    lysine = 0.85,
                    methionine = 0.35,
                    crudeFiber = 5.5
                ),
                NutrientTarget(
                    birdType = "Hybrid / Kienyeji",
                    stageName = "Grower (9-20 weeks)",
                    minAgeWeeks = 9,
                    maxAgeWeeks = 20,
                    crudeProtein = 15.0,
                    energy = 2700.0,
                    calcium = 0.85,
                    phosphorus = 0.35,
                    lysine = 0.65,
                    methionine = 0.28,
                    crudeFiber = 6.0
                ),
                NutrientTarget(
                    birdType = "Hybrid / Kienyeji",
                    stageName = "Layer/Breeder (21+ weeks)",
                    minAgeWeeks = 21,
                    maxAgeWeeks = 100, // represent 21+ weeks
                    crudeProtein = 16.0,
                    energy = 2700.0,
                    calcium = 3.50,
                    phosphorus = 0.38,
                    lysine = 0.75,
                    methionine = 0.32,
                    crudeFiber = 6.0
                )
            )
            val currentTargets = dao.getAllNutrientTargetsList()
            if (currentTargets.isEmpty()) {
                defaultTargets.forEach { dao.insertNutrientTarget(it) }
            } else {
                defaultTargets.forEach { target ->
                    if (currentTargets.none { it.birdType == target.birdType && it.stageName == target.stageName }) {
                        dao.insertNutrientTarget(target)
                    }
                }
            }

            // Seed raw standard preloaded inventories
            val seedInventories = listOf(
                FeedInventory("Maize (Mahindi)", "Ingredient", 500.0),
                FeedInventory("Maize Husk (Makapi ya Mahindi)", "Ingredient", 150.0),
                FeedInventory("Soybean Meal", "Ingredient", 200.0),
                FeedInventory("Limestone", "Ingredient", 100.0),
                FeedInventory("Salt (Chumvi)", "Ingredient", 20.0),
                FeedInventory("Premix", "Ingredient", 10.0)
            )
            val currentInventories = dao.getInventoryList()
            if (currentInventories.isEmpty()) {
                seedInventories.forEach { dao.insertInventory(it) }
            } else {
                seedInventories.forEach { inv ->
                    if (currentInventories.none { it.name.lowercase().trim() == inv.name.lowercase().trim() }) {
                        dao.insertInventory(inv)
                    }
                }
            }
        }
    } // closes companion object
}
