package com.example.data

import kotlinx.coroutines.flow.Flow

class FeedRepository(private val feedDao: FeedDao) {

    val allIngredients: Flow<List<Ingredient>> = feedDao.getAllIngredients()
    
    val allNutrientTargets: Flow<List<NutrientTarget>> = feedDao.getAllNutrientTargets()
    
    val allInclusionLimits: Flow<List<InclusionLimit>> = feedDao.getAllInclusionLimitsFlow()
    
    val savedFormulations: Flow<List<SavedFormulation>> = feedDao.getAllSavedFormulations()
    
    val priceHistory: Flow<List<PriceHistory>> = feedDao.getPriceHistory()
    
    val manufacturingLogs: Flow<List<ManufacturingLog>> = feedDao.getAllManufacturingLogs()
    
    val inventory: Flow<List<FeedInventory>> = feedDao.getInventoryFlow()

    suspend fun getSelectedIngredients(): List<Ingredient> {
        return feedDao.getSelectedIngredients()
    }

    suspend fun getAllIngredientsList(): List<Ingredient> {
        return feedDao.getAllIngredientsList()
    }

    suspend fun getAllNutrientTargetsList(): List<NutrientTarget> {
        return feedDao.getAllNutrientTargetsList()
    }

    suspend fun getAllStoresList(): List<Store> {
        return feedDao.getAllStoresList()
    }

    suspend fun insertIngredient(ingredient: Ingredient): Long {
        return feedDao.insertIngredient(ingredient)
    }

    suspend fun updateIngredient(ingredient: Ingredient) {
        feedDao.updateIngredient(ingredient)
    }

    suspend fun deleteIngredient(ingredient: Ingredient) {
        feedDao.deleteIngredient(ingredient)
    }

    suspend fun getTargetForAge(birdType: String, age: Int): NutrientTarget? {
        return feedDao.getTargetForAge(birdType, age)
    }

    suspend fun insertNutrientTarget(target: NutrientTarget) {
        feedDao.insertNutrientTarget(target)
    }

    suspend fun updateNutrientTarget(target: NutrientTarget) {
        feedDao.updateNutrientTarget(target)
    }

    suspend fun getAllInclusionLimits(): List<InclusionLimit> {
        return feedDao.getAllInclusionLimits()
    }

    suspend fun insertInclusionLimit(limit: InclusionLimit) {
        feedDao.insertInclusionLimit(limit)
    }

    suspend fun insertFormulation(formulation: SavedFormulation): Long {
        return feedDao.insertFormulation(formulation)
    }

    suspend fun deleteFormulationById(id: Int) {
        feedDao.deleteFormulationById(id)
    }

    suspend fun insertPriceHistory(history: PriceHistory) {
        feedDao.insertPriceHistory(history)
    }

    suspend fun insertManufacturingLog(log: ManufacturingLog) {
        feedDao.insertManufacturingLog(log)
    }

    suspend fun getInventoryByName(name: String): FeedInventory? {
        return feedDao.getInventoryByName(name)
    }

    suspend fun insertInventory(inventory: FeedInventory) {
        feedDao.insertInventory(inventory)
    }

    // --- Stores and Store Prices ---
    val allStores: Flow<List<Store>> = feedDao.getAllStores()
    val allStorePricesFlow: Flow<List<StoreIngredientPrice>> = feedDao.getAllStorePricesFlow()

    suspend fun getStoreByName(name: String): Store? {
        return feedDao.getStoreByName(name)
    }

    suspend fun insertStore(store: Store): Long {
        return feedDao.insertStore(store)
    }

    suspend fun deleteStore(store: Store) {
        feedDao.deleteStore(store)
    }

    fun getPricesForStore(storeId: Int): Flow<List<StoreIngredientPrice>> {
        return feedDao.getPricesForStore(storeId)
    }

    suspend fun getPricesForStoreSync(storeId: Int): List<StoreIngredientPrice> {
        return feedDao.getPricesForStoreSync(storeId)
    }

    suspend fun insertStorePrice(price: StoreIngredientPrice) {
        feedDao.insertStorePrice(price)
    }

    suspend fun deletePricesForStore(storeId: Int) {
        feedDao.deletePricesForStore(storeId)
    }

    suspend fun deleteAllStores() {
        feedDao.deleteAllStores()
    }

    suspend fun deleteAllStorePrices() {
        feedDao.deleteAllStorePrices()
    }
}
