package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface FeedDao {
    // --- Ingredients ---
    @Query("SELECT * FROM ingredients ORDER BY isCustom ASC, id ASC")
    fun getAllIngredients(): Flow<List<Ingredient>>

    @Query("SELECT * FROM ingredients ORDER BY isCustom ASC, id ASC")
    suspend fun getAllIngredientsList(): List<Ingredient>

    @Query("SELECT * FROM ingredients WHERE isSelected = 1")
    suspend fun getSelectedIngredients(): List<Ingredient>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIngredient(ingredient: Ingredient): Long

    @Update
    suspend fun updateIngredient(ingredient: Ingredient)

    @Delete
    suspend fun deleteIngredient(ingredient: Ingredient)

    // --- Nutrient Targets ---
    @Query("SELECT * FROM nutrient_targets ORDER BY id ASC")
    fun getAllNutrientTargets(): Flow<List<NutrientTarget>>

    @Query("SELECT * FROM nutrient_targets ORDER BY id ASC")
    suspend fun getAllNutrientTargetsList(): List<NutrientTarget>

    @Query("SELECT * FROM nutrient_targets WHERE birdType = :birdType AND minAgeWeeks <= :age AND maxAgeWeeks >= :age LIMIT 1")
    suspend fun getTargetForAge(birdType: String, age: Int): NutrientTarget?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNutrientTarget(target: NutrientTarget)

    @Update
    suspend fun updateNutrientTarget(target: NutrientTarget)

    // --- Inclusion Limits ---
    @Query("SELECT * FROM inclusion_limits")
    fun getAllInclusionLimitsFlow(): Flow<List<InclusionLimit>>

    @Query("SELECT * FROM inclusion_limits")
    suspend fun getAllInclusionLimits(): List<InclusionLimit>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInclusionLimit(limit: InclusionLimit)

    // --- Saved Formulations ---
    @Query("SELECT * FROM saved_formulations ORDER BY timestamp DESC")
    fun getAllSavedFormulations(): Flow<List<SavedFormulation>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFormulation(formulation: SavedFormulation): Long

    @Query("DELETE FROM saved_formulations WHERE id = :id")
    suspend fun deleteFormulationById(id: Int)

    // --- Price History ---
    @Query("SELECT * FROM price_history ORDER BY timestamp DESC")
    fun getPriceHistory(): Flow<List<PriceHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPriceHistory(history: PriceHistory)

    // --- Manufacturing Logs ---
    @Query("SELECT * FROM manufacturing_logs ORDER BY timestamp DESC")
    fun getAllManufacturingLogs(): Flow<List<ManufacturingLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertManufacturingLog(log: ManufacturingLog)

    // --- Feed Inventory ---
    @Query("SELECT * FROM feed_inventory")
    fun getInventoryFlow(): Flow<List<FeedInventory>>

    @Query("SELECT * FROM feed_inventory")
    suspend fun getInventoryList(): List<FeedInventory>

    @Query("SELECT * FROM feed_inventory WHERE name = :name LIMIT 1")
    suspend fun getInventoryByName(name: String): FeedInventory?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInventory(inventory: FeedInventory)

    // --- Stores and Store Prices ---
    @Query("SELECT * FROM stores ORDER BY name ASC")
    fun getAllStores(): Flow<List<Store>>

    @Query("SELECT * FROM stores ORDER BY name ASC")
    suspend fun getAllStoresList(): List<Store>

    @Query("SELECT * FROM stores WHERE name = :name LIMIT 1")
    suspend fun getStoreByName(name: String): Store?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStore(store: Store): Long

    @Delete
    suspend fun deleteStore(store: Store)

    @Query("SELECT * FROM store_ingredient_prices WHERE storeId = :storeId")
    fun getPricesForStore(storeId: Int): Flow<List<StoreIngredientPrice>>

    @Query("SELECT * FROM store_ingredient_prices")
    fun getAllStorePricesFlow(): Flow<List<StoreIngredientPrice>>

    @Query("SELECT * FROM store_ingredient_prices WHERE storeId = :storeId")
    suspend fun getPricesForStoreSync(storeId: Int): List<StoreIngredientPrice>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStorePrice(price: StoreIngredientPrice)

    @Query("DELETE FROM store_ingredient_prices WHERE storeId = :storeId")
    suspend fun deletePricesForStore(storeId: Int)

    @Query("DELETE FROM stores")
    suspend fun deleteAllStores()

    @Query("DELETE FROM store_ingredient_prices")
    suspend fun deleteAllStorePrices()
}
