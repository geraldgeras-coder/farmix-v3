package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "ingredients")
data class Ingredient(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val category: String, // "Energy", "Protein", "Mineral", "Additive"
    val crudeProtein: Double, // %
    val energy: Double, // kcal/kg
    val calcium: Double, // %
    val phosphorus: Double, // %
    val lysine: Double, // %
    val methionine: Double, // %
    val crudeFiber: Double, // %
    val pricePerKg: Double, // local currency
    val isCustom: Boolean = false,
    val isSelected: Boolean = false // Whether farmer has it available
)

@Entity(tableName = "nutrient_targets")
data class NutrientTarget(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val birdType: String, // "Broiler", "Layer", "Hybrid / Kienyeji"
    val stageName: String, // "Starter", "Grower", "Finisher", etc.
    val minAgeWeeks: Int,
    val maxAgeWeeks: Int,
    val crudeProtein: Double, // %
    val energy: Double, // kcal/kg
    val calcium: Double, // %
    val phosphorus: Double, // %
    val lysine: Double, // %
    val methionine: Double, // %
    val crudeFiber: Double // %
)

@Entity(tableName = "inclusion_limits")
data class InclusionLimit(
    @PrimaryKey val ingredientName: String, // Match ingredient name or category
    val minPercent: Double,
    val maxPercent: Double,
    val isFixed: Boolean = false
)

@Entity(tableName = "saved_formulations")
data class SavedFormulation(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val timestamp: Long = System.currentTimeMillis(),
    val birdType: String,
    val ageWeeks: Int,
    val targetStage: String,
    val batchWeightKg: Double,
    val totalCost: Double,
    val costPerKg: Double,
    val ingredientSharesJson: String, // JSON map of ingredient name to percentage and weight
    val achievedNutrientsJson: String // JSON map of nutrient name to achieved %
)

@Entity(tableName = "price_history")
data class PriceHistory(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val ingredientId: Int,
    val ingredientName: String,
    val oldPrice: Double,
    val newPrice: Double,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "manufacturing_logs")
data class ManufacturingLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val formulationId: Int,
    val formulationTitle: String,
    val timestamp: Long = System.currentTimeMillis(),
    val batchWeightKg: Double,
    val costPerKg: Double,
    val totalCost: Double,
    val notes: String = ""
)

@Entity(tableName = "feed_inventory")
data class FeedInventory(
    @PrimaryKey val name: String, // Ingredient or Formulation title
    val type: String, // "Ingredient" or "Formulated Feed"
    val stockKg: Double,
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(tableName = "stores")
data class Store(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String
)

@Entity(tableName = "store_ingredient_prices", primaryKeys = ["storeId", "ingredientName"])
data class StoreIngredientPrice(
    val storeId: Int,
    val ingredientName: String,
    val price: Double
)

