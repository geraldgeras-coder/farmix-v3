package com.example.pdf

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.NutrientTarget
import com.example.formulator.SolverResult
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfGenerator {

    fun generateAndShareReport(
        context: Context,
        birdType: String,
        stageName: String,
        ageWeeks: Int,
        batchWeight: Double,
        result: SolverResult,
        target: NutrientTarget,
        isSwahili: Boolean
    ) {
        val pdfDocument = PdfDocument()
        // Page size: Letter/A4 is approx 595 x 842 points
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        val paint = Paint()
        val textPaint = Paint().apply {
            color = Color.BLACK
            textSize = 12f
            isAntiAlias = true
        }
        
        val titlePaint = Paint().apply {
            color = Color.rgb(42, 111, 60) // Earth Green
            textSize = 20f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val headerPaint = Paint().apply {
            color = Color.rgb(31, 78, 38)
            textSize = 14f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val boldPaint = Paint().apply {
            textSize = 12f
            isFakeBoldText = true
            isAntiAlias = true
        }

        // Draw Header Banner
        canvas.drawRect(0f, 0f, 595f, 60f, Paint().apply { color = Color.rgb(240, 245, 241) })
        canvas.drawText("SMART POULTRY - FEED FORMULATION REPORT", 20f, 38f, titlePaint)

        // Metadata block
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        val dateText = sdf.format(Date())
        
        var y = 90f
        canvas.drawText(if (isSwahili) "Tarehe: $dateText" else "Date: $dateText", 20f, y, textPaint)
        canvas.drawText(if (isSwahili) "Aina ya Kuku: $birdType" else "Poultry Type: $birdType", 300f, y, textPaint)
        
        y += 20f
        canvas.drawText(if (isSwahili) "Umri: Wiki $ageWeeks ($stageName)" else "Age: $ageWeeks Weeks ($stageName)", 20f, y, textPaint)
        canvas.drawText(if (isSwahili) "Uzito wa Malisho: ${batchWeight} Kg" else "Batch Weight: ${batchWeight} Kg", 300f, y, textPaint)

        y += 30f
        canvas.drawLine(20f, y, 575f, y, Paint().apply { color = Color.LTGRAY; strokeWidth = 1f })

        // 1. Ingredients Table
        y += 25f
        canvas.drawText(if (isSwahili) "1. JEDWALI LA VIUNGO (FORMULATION GRAPH)" else "1. FEED INGREDIENT INCLUSIONS", 20f, y, headerPaint)
        
        y += 25f
        // Table headers
        canvas.drawRect(20f, y - 15f, 575f, y + 8f, Paint().apply { color = Color.rgb(245, 245, 245) })
        canvas.drawText(if (isSwahili) "Kiungo (Ingredient)" else "Ingredient Name", 25f, y, boldPaint)
        canvas.drawText(if (isSwahili) "Asilimia (%)" else "Share %", 230f, y, boldPaint)
        canvas.drawText(if (isSwahili) "Uzito (Kg)" else "Weight (Kg)", 350f, y, boldPaint)
        canvas.drawText(if (isSwahili) "Gharama (Est.)" else "Cost (Est.)", 470f, y, boldPaint)

        y += 10f
        result.ingredientPercentages.forEach { (name, percent) ->
            if (percent > 0.0) {
                y += 20f
                val weight = result.ingredientWeightsKg[name] ?: 0.0
                val cost = (percent / 100.0) * batchWeight * (result.costPerKg) // estimate based on share
                canvas.drawText(name, 25f, y, textPaint)
                canvas.drawText(String.format("%.2f %%", percent), 230f, y, textPaint)
                canvas.drawText(String.format("%.2f Kg", weight), 350f, y, textPaint)
                canvas.drawText(String.format("%.2f", cost), 470f, y, textPaint)
            }
        }

        y += 25f
        canvas.drawLine(20f, y, 575f, y, Paint().apply { color = Color.LTGRAY; strokeWidth = 1f })

        // Totals
        y += 20f
        canvas.drawText(if (isSwahili) "JUMLA (TOTAL WEIGHT):" else "TOTAL WEIGHT:", 25f, y, boldPaint)
        canvas.drawText("100.00 %", 230f, y, boldPaint)
        canvas.drawText(String.format("%.2f Kg", batchWeight), 350f, y, boldPaint)
        canvas.drawText(String.format("%.2f", result.totalCost), 470f, y, boldPaint)

        y += 30f
        canvas.drawLine(20f, y, 575f, y, Paint().apply { color = Color.GRAY; strokeWidth = 1.5f })

        // 2. Nutrition Analysis Table
        y += 25f
        canvas.drawText(if (isSwahili) "2. UCHAMBUZI WA LISHE (NUTRIENT ANALYSIS)" else "2. NUTRIENT COMPARISON TARGET VS ACHIEVED", 20f, y, headerPaint)

        y += 25f
        canvas.drawRect(20f, y - 15f, 575f, y + 8f, Paint().apply { color = Color.rgb(245, 245, 245) })
        canvas.drawText(if (isSwahili) "Kipimo (Nutrient)" else "Nutrient Parameter", 25f, y, boldPaint)
        canvas.drawText(if (isSwahili) "Lengo (Target)" else "Target Requirement", 230f, y, boldPaint)
        canvas.drawText(if (isSwahili) "Fomula (Achieved)" else "Achieved Level", 380f, y, boldPaint)
        canvas.drawText("Status", 500f, y, boldPaint)

        val format = "%.2f"
        val parameters = listOf(
            Triple("Protein (%)", String.format(format, target.crudeProtein), String.format(format, result.achievedNutrients.crudeProtein)),
            Triple("Energy (kcal/kg)", String.format("%.0f", target.energy), String.format("%.0f", result.achievedNutrients.energy)),
            Triple("Calcium (%)", String.format(format, target.calcium), String.format(format, result.achievedNutrients.calcium)),
            Triple("Phosphorus (%)", String.format(format, target.phosphorus), String.format(format, result.achievedNutrients.phosphorus)),
            Triple("Lysine (%)", String.format(format, target.lysine), String.format(format, result.achievedNutrients.lysine)),
            Triple("Methionine (%)", String.format(format, target.methionine), String.format(format, result.achievedNutrients.methionine)),
            Triple("Crude Fiber (%)", String.format(format, target.crudeFiber), String.format(format, result.achievedNutrients.crudeFiber))
        )

        parameters.forEach { (name, tgt, ach) ->
            y += 22f
            canvas.drawText(name, 25f, y, textPaint)
            canvas.drawText(tgt, 230f, y, textPaint)
            canvas.drawText(ach, 380f, y, textPaint)
            
            val doubleTgt = tgt.toDoubleOrNull() ?: 0.0
            val doubleAch = ach.toDoubleOrNull() ?: 0.0
            val status = if (name.contains("Fiber")) {
                if (doubleAch <= doubleTgt) "Pass" else "High"
            } else {
                if (doubleAch >= doubleTgt - 0.1) "Pass" else "Low"
            }
            canvas.drawText(status, 500f, y, boldPaint)
        }

        y += 40f
        // Bottom stamp / recommendation
        canvas.drawRect(20f, y, 575f, y + 80f, Paint().apply { color = Color.rgb(240, 248, 242) })
        canvas.drawText(if (isSwahili) "USHUSHU WA KIUTALAMU (FEED ADVISORY STAMP)" else "OFFICIAL POULTRY NUTRITION RECOMMENDATION", 35f, y + 25f, boldPaint)
        val line1 = if (isSwahili) {
            "Mchanganyiko huu unafanya kazi kikamilifu nje ya mtandao. Hakikisha viungo vinachanganywa sawasawa."
        } else {
            "This feed formula has been verified offline. Always perform homogeneous physical mixing."
        }
        val line2 = if (isSwahili) {
            "Gharama kwa Kilo Moja ya chakula kisichozidi: ${String.format("%.2f", result.costPerKg)} ya sarafu yako ya ndani."
        } else {
            "Least-Cost Optimisation achieved at: ${String.format("%.2f", result.costPerKg)} per Kilogram of raw materials."
        }
        canvas.drawText(line1, 35f, y + 45f, textPaint)
        canvas.drawText(line2, 35f, y + 62f, textPaint)

        pdfDocument.finishPage(page)

        // Save PDF to downloads or cache
        try {
            val fileName = "PoultryFeed_${birdType}_${stageName.replace(" ", "_")}_${System.currentTimeMillis()}.pdf"
            val file = File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), fileName)
            val outputStream = FileOutputStream(file)
            pdfDocument.writeTo(outputStream)
            pdfDocument.close()
            outputStream.flush()
            outputStream.close()

            // Trigger and open PDF File with Intent
            Toast.makeText(context.applicationContext, "PDF Report generated: ${file.name}", Toast.LENGTH_LONG).show()

            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share Feed Report / Shiriki Taarifa"))

        } catch (e: Exception) {
            Toast.makeText(context.applicationContext, "Error saving report: ${e.message}", Toast.LENGTH_SHORT).show()
            pdfDocument.close()
        }
    }

    fun generateAndShareBudgetReport(
        context: Context,
        birdType: String,
        stageName: String,
        ageWeeks: Int,
        batchWeight: Double,
        budgetLimit: Double,
        totalCost: Double,
        averageUnitCost: Double,
        ingredients: List<com.example.ui.BudgetRecipeRow>,
        adviceText: String,
        isSwahili: Boolean
    ) {
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        val paint = Paint()
        val textPaint = Paint().apply {
            color = Color.BLACK
            textSize = 11f
            isAntiAlias = true
        }
        
        val titlePaint = Paint().apply {
            color = Color.rgb(197, 85, 30) // Terre Cotta/Orange for budget customization
            textSize = 18f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val headerPaint = Paint().apply {
            color = Color.rgb(139, 69, 19)
            textSize = 13f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val boldPaint = Paint().apply {
            textSize = 11f
            isFakeBoldText = true
            isAntiAlias = true
        }

        // Draw Header Banner
        canvas.drawRect(0f, 0f, 595f, 60f, Paint().apply { color = Color.rgb(253, 246, 240) })
        canvas.drawText("SMART POULTRY - BUDGET OPTIMIZED REPORT", 20f, 38f, titlePaint)

        // Metadata block
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault())
        val dateText = sdf.format(java.util.Date())
        
        var y = 90f
        canvas.drawText(if (isSwahili) "Tarehe: $dateText" else "Date: $dateText", 20f, y, textPaint)
        canvas.drawText(if (isSwahili) "Aina ya Kuku: $birdType" else "Poultry Type: $birdType", 300f, y, textPaint)
        
        y += 20f
        canvas.drawText(if (isSwahili) "Umri: Wiki $ageWeeks ($stageName)" else "Age: $ageWeeks Weeks ($stageName)", 20f, y, textPaint)
        canvas.drawText(if (isSwahili) "Uzito: ${batchWeight} Kg" else "Batch Weight: ${batchWeight} Kg", 300f, y, textPaint)

        y += 20f
        canvas.drawText(if (isSwahili) "Bajeti ya Mkulima: TSh $budgetLimit" else "Farmer Pocket Budget: TSh $budgetLimit", 20f, y, boldPaint)

        y += 20f
        canvas.drawLine(20f, y, 575f, y, Paint().apply { color = Color.LTGRAY; strokeWidth = 1f })

        // 1. Ingredients Table
        y += 25f
        canvas.drawText(if (isSwahili) "1. JEDWALI LA LISHE YA BAJETI (BUDGET INGREDIENTS)" else "1. BUDGET FEED INGREDIENTS", 20f, y, headerPaint)
        
        y += 25f
        // Table headers
        canvas.drawRect(20f, y - 15f, 575f, y + 8f, Paint().apply { color = Color.rgb(253, 246, 240) })
        canvas.drawText(if (isSwahili) "Kiungo (Ingredient)" else "Ingredient Name", 25f, y, boldPaint)
        canvas.drawText(if (isSwahili) "Asilimia (%)" else "Share %", 230f, y, boldPaint)
        canvas.drawText(if (isSwahili) "Uzito (Kg)" else "Weight (Kg)", 350f, y, boldPaint)
        canvas.drawText(if (isSwahili) "Gharama (TSh)" else "Cost (TSh)", 470f, y, boldPaint)

        y += 10f
        ingredients.forEach { row ->
            y += 20f
            canvas.drawText(row.ingredientName, 25f, y, textPaint)
            canvas.drawText(String.format(java.util.Locale.US, "%.2f %%", row.percentage), 230f, y, textPaint)
            canvas.drawText(String.format(java.util.Locale.US, "%.2f Kg", row.weightKg), 350f, y, textPaint)
            canvas.drawText(String.format(java.util.Locale.US, "%.0f TSh", row.costTsh), 470f, y, textPaint)
        }

        y += 25f
        canvas.drawLine(20f, y, 575f, y, Paint().apply { color = Color.LTGRAY; strokeWidth = 1f })

        // Totals
        y += 20f
        canvas.drawText(if (isSwahili) "JUMLA KUU:" else "TOTAL SUM:", 25f, y, boldPaint)
        canvas.drawText("100.00 %", 230f, y, boldPaint)
        canvas.drawText(String.format(java.util.Locale.US, "%.2f Kg", batchWeight), 350f, y, boldPaint)
        canvas.drawText(String.format(java.util.Locale.US, "%.0f TSh", totalCost), 470f, y, boldPaint)

        y += 30f
        canvas.drawLine(20f, y, 575f, y, Paint().apply { color = Color.GRAY; strokeWidth = 1.5f })

        // Advice
        y += 25f
        canvas.drawText(if (isSwahili) "2. MAPENDEKEZO YA BAJETI (BUDGET STRATEGY)" else "2. CUSTOM BUDGET FEED RE-STRATEGY", 20f, y, headerPaint)
        
        val adviceLines = adviceText.split("\n").filter { it.isNotBlank() }
        y += 10f
        for (line in adviceLines) {
            y += 15f
            if (y > 720f) {
                break
            }
            var currentLine = line.trim()
            if (currentLine.length > 80) {
                while (currentLine.length > 80 && y < 720f) {
                    val part = currentLine.substring(0, 80)
                    canvas.drawText(part, 25f, y, textPaint)
                    currentLine = currentLine.substring(80)
                    y += 15f
                }
            }
            if (y < 720f) {
                canvas.drawText(currentLine, 25f, y, textPaint)
            }
        }

        y = 730f
        // Bottom stamp / recommendation
        canvas.drawRect(20f, y, 575f, y + 65f, Paint().apply { color = Color.rgb(254, 248, 245) })
        canvas.drawText(if (isSwahili) "USHAURI WA BAJETI (BUDGET RECOMMENDATION STAMP)" else "BUDGET NUTRITIONAL RECOMMENDATION", 35f, y + 20f, boldPaint)
        val line1 = if (isSwahili) {
            "Mchanganyiko huu umeboreshwa mfululizo ili kupunguza gharama bila njaa."
        } else {
            "Optimized to safely curtail raw material costs within your target bracket limit."
        }
        val line2 = if (isSwahili) {
            "Makadirio ya wastani kwa kilo: ${String.format(java.util.Locale.US, "%.2f", averageUnitCost)} TSh."
        } else {
            "Customised Budget compromise unit price achieved at: ${String.format(java.util.Locale.US, "%.2f", averageUnitCost)} TSh/Kg."
        }
        canvas.drawText(line1, 35f, y + 36f, textPaint)
        canvas.drawText(line2, 35f, y + 50f, textPaint)

        pdfDocument.finishPage(page)

        // Save PDF to downloads or cache
        try {
            val fileName = "BudgetFeed_${birdType}_${stageName.replace(" ", "_")}_${System.currentTimeMillis()}.pdf"
            val file = File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), fileName)
            val outputStream = FileOutputStream(file)
            pdfDocument.writeTo(outputStream)
            pdfDocument.close()
            outputStream.flush()
            outputStream.close()

            // Trigger and open PDF File with Intent
            Toast.makeText(context.applicationContext, "PDF Budget Report generated: ${file.name}", Toast.LENGTH_LONG).show()

            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val intentSender = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intentSender, "Share Feed Report / Shiriki Taarifa"))

        } catch (e: Exception) {
            Toast.makeText(context.applicationContext, "Error saving report: ${e.message}", Toast.LENGTH_SHORT).show()
            pdfDocument.close()
        }
    }
}
