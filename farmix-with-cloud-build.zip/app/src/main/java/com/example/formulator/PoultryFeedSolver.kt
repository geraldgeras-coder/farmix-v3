package com.example.formulator

import com.example.data.Ingredient
import com.example.data.NutrientTarget
import com.example.data.InclusionLimit
import java.util.Random

data class SolverResult(
    val success: Boolean,
    val ingredientWeightsKg: Map<String, Double>, // Ingredient Name -> Kg
    val ingredientPercentages: Map<String, Double>, // Ingredient Name -> %
    val achievedNutrients: AchievedNutrients,
    val totalCost: Double,
    val costPerKg: Double,
    val errorMessage: String? = null
)

data class AchievedNutrients(
    val crudeProtein: Double,
    val energy: Double,
    val calcium: Double,
    val phosphorus: Double,
    val lysine: Double,
    val methionine: Double,
    val crudeFiber: Double
)

object PoultryFeedSolver {

    private fun isMicroIngredient(name: String): Boolean {
        val lower = name.lowercase()
        return lower.contains("premix") || lower.contains("salt") || lower.contains("chumvi") ||
               lower.contains("enzyme") || lower.contains("toxin") || lower.contains("binder") ||
               lower.contains("lysine") || lower.contains("methionine")
    }

    private fun getEffectiveMinPercent(name: String, limit: InclusionLimit?): Double {
        if (isMicroIngredient(name)) {
            return limit?.minPercent ?: 0.0
        }
        val defaultMin = 4.0 // Ensures macro ingredients (like Maize Husk) contribute at least 4% to the mix
        return if (limit != null) {
            if (limit.minPercent > 0.0) limit.minPercent else defaultMin
        } else {
            defaultMin
        }
    }

    fun solve(
        ingredients: List<Ingredient>,
        target: NutrientTarget,
        inclusionLimits: List<InclusionLimit>,
        batchWeightKg: Double
    ): SolverResult {
        val selectedIngredients = ingredients.filter { it.isSelected }
        if (selectedIngredients.isEmpty()) {
            return SolverResult(
                success = false,
                ingredientWeightsKg = emptyMap(),
                ingredientPercentages = emptyMap(),
                achievedNutrients = AchievedNutrients(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                totalCost = 0.0,
                costPerKg = 0.0,
                errorMessage = "No ingredients selected! Please check some available ingredients in Settings."
            )
        }

        val n = selectedIngredients.size
        val shares = DoubleArray(n)

        // Find or build inclusion limits maps for convenience
        val limitsMap = inclusionLimits.associateBy { it.ingredientName }

        // Determine fixed and non-fixed inclusion limits
        val fixedShares = DoubleArray(n) { 0.0 }
        var totalFixed = 0.0
        val isFixed = BooleanArray(n) { false }

        for (i in 0 until n) {
            val ing = selectedIngredients[i]
            val limit = limitsMap[ing.name]
            if (limit != null && limit.isFixed) {
                isFixed[i] = true
                fixedShares[i] = limit.minPercent
                totalFixed += limit.minPercent
            }
        }

        if (totalFixed > 100.0) {
            return SolverResult(
                success = false,
                ingredientWeightsKg = emptyMap(),
                ingredientPercentages = emptyMap(),
                achievedNutrients = AchievedNutrients(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                totalCost = 0.0,
                costPerKg = 0.0,
                errorMessage = "Fixed inclusion limits total more than 100% (${totalFixed}%). Please edit inclusion limits."
            )
        }

        // Calculate effective mins for all ingredients
        val effectiveMins = DoubleArray(n)
        var totalMinRequired = 0.0
        for (i in 0 until n) {
            val ing = selectedIngredients[i]
            if (isFixed[i]) {
                effectiveMins[i] = fixedShares[i]
            } else {
                val limit = limitsMap[ing.name]
                effectiveMins[i] = getEffectiveMinPercent(ing.name, limit)
            }
            totalMinRequired += effectiveMins[i]
        }

        // Initialize shares to meet minimum requirements and split residual
        if (totalMinRequired > 100.0) {
            for (i in 0 until n) {
                shares[i] = (effectiveMins[i] / totalMinRequired) * 100.0
            }
        } else {
            for (i in 0 until n) {
                shares[i] = effectiveMins[i]
            }
            val remainingPct = 100.0 - totalMinRequired
            val nonFixedCount = isFixed.count { !it }
            if (nonFixedCount > 0) {
                val addShare = remainingPct / nonFixedCount
                for (i in 0 until n) {
                    if (!isFixed[i]) {
                        shares[i] += addShare
                    }
                }
            }
        }

        // Objective Function evaluator
        fun evaluate(testShares: DoubleArray): Double {
            var cp = 0.0
            var me = 0.0
            var ca = 0.0
            var p = 0.0
            var lys = 0.0
            var met = 0.0
            var cf = 0.0
            var cost = 0.0

            for (i in 0 until n) {
                val s = testShares[i] / 100.0
                val ing = selectedIngredients[i]
                cp += s * ing.crudeProtein
                me += s * ing.energy
                ca += s * ing.calcium
                p += s * ing.phosphorus
                lys += s * ing.lysine
                met += s * ing.methionine
                cf += s * ing.crudeFiber
                cost += s * ing.pricePerKg
            }

            // High penalties for target violations (lower targets than requirements)
            var penalty = 0.0

            if (cp < target.crudeProtein) {
                penalty += (target.crudeProtein - cp) * 350.0 // High priority
            }
            if (me < target.energy) {
                penalty += (target.energy - me) * 3.5 // scale of ~3000
            }
            if (ca < target.calcium) {
                penalty += (target.calcium - ca) * 250.0
            } else if (ca > target.calcium * 1.15 && target.birdType != "Layer") {
                // Layer needs high calcium, others shouldn't have too high
                penalty += (ca - target.calcium * 1.15) * 100.0
            }
            if (p < target.phosphorus) {
                penalty += (target.phosphorus - p) * 200.0
            }
            if (lys < target.lysine) {
                penalty += (target.lysine - lys) * 300.0
            }
            if (met < target.methionine) {
                penalty += (target.methionine - met) * 300.0
            }
            if (cf > target.crudeFiber) {
                penalty += (cf - target.crudeFiber) * 150.0 // penalty for excessive fiber
            }

            // Ingredient limit penalties
            for (i in 0 until n) {
                val ing = selectedIngredients[i]
                val pct = testShares[i]
                val limit = limitsMap[ing.name]
                val minPct = effectiveMins[i]
                val maxPct = limit?.maxPercent ?: 95.0

                if (pct < minPct) {
                    penalty += (minPct - pct) * 200.0
                }
                if (pct > maxPct) {
                    penalty += (pct - maxPct) * 200.0
                }
            }

            // Return cost + penalty
            return cost + penalty
        }

        // Optimization run: Pairwise Coordinate Descent
        var bestScore = evaluate(shares)
        val rand = Random(42) // Seed for deterministic runs
        
        var stepSize = 10.0
        val minStepSize = 0.0001
        val coolingFactor = 0.95

        val nonFixedIndices = (0 until n).filter { !isFixed[it] }

        if (nonFixedIndices.size >= 2) {
            while (stepSize > minStepSize) {
                var improved = false
                // Try several random pairwise adjustments at current grid size
                for (iter in 0 until 400) {
                    val idxA = nonFixedIndices[rand.nextInt(nonFixedIndices.size)]
                    val idxB = nonFixedIndices[rand.nextInt(nonFixedIndices.size)]
                    if (idxA == idxB) continue

                    // Test increasing A, decreasing B
                    val canAdd = stepSize
                    val canSub = stepSize
                    if (shares[idxB] - canSub >= 0.0) {
                        shares[idxA] += canAdd
                        shares[idxB] -= canSub

                        val newScore = evaluate(shares)
                        if (newScore < bestScore) {
                            bestScore = newScore
                            improved = true
                        } else {
                            // Revert
                            shares[idxA] -= canAdd
                            shares[idxB] += canSub
                        }
                    }

                    // Test decreasing A, increasing B
                    if (shares[idxA] - canSub >= 0.0) {
                        shares[idxA] -= canSub
                        shares[idxB] += canAdd

                        val newScore = evaluate(shares)
                        if (newScore < bestScore) {
                            bestScore = newScore
                            improved = true
                        } else {
                            // Revert
                            shares[idxA] += canSub
                            shares[idxB] -= canAdd
                        }
                    }
                }
                if (!improved) {
                    stepSize *= coolingFactor // reduce grid search size
                }
            }
        }

        // Calculate achieved metrics
        var finalCP = 0.0
        var finalME = 0.0
        var finalCa = 0.0
        var finalP = 0.0
        var finalLys = 0.0
        var finalMet = 0.0
        var finalCF = 0.0
        var finalCostPerKg = 0.0

        val percentages = mutableMapOf<String, Double>()
        val weights = mutableMapOf<String, Double>()

        for (i in 0 until n) {
            val ing = selectedIngredients[i]
            val pct = shares[i]
            
            percentages[ing.name] = pct
            weights[ing.name] = (pct / 100.0) * batchWeightKg
            
            finalCP += (pct / 100.0) * ing.crudeProtein
            finalME += (pct / 100.0) * ing.energy
            finalCa += (pct / 100.0) * ing.calcium
            finalP += (pct / 100.0) * ing.phosphorus
            finalLys += (pct / 100.0) * ing.lysine
            finalMet += (pct / 100.0) * ing.methionine
            finalCF += (pct / 100.0) * ing.crudeFiber
            finalCostPerKg += (pct / 100.0) * ing.pricePerKg
        }

        val totalCost = finalCostPerKg * batchWeightKg

        val achieved = AchievedNutrients(
            crudeProtein = finalCP,
            energy = finalME,
            calcium = finalCa,
            phosphorus = finalP,
            lysine = finalLys,
            methionine = finalMet,
            crudeFiber = finalCF
        )

        // Check if nutrient requirements are reasonably satisfied
        val failedRequirements = mutableListOf<String>()
        if (finalCP < target.crudeProtein - 0.5) failedRequirements.add("Protein")
        if (finalME < target.energy - 50.0) failedRequirements.add("Energy")
        if (finalCa < target.calcium - 0.1) failedRequirements.add("Calcium")
        if (finalP < target.phosphorus - 0.05) failedRequirements.add("Phosphorus")
        if (finalLys < target.lysine - 0.05) failedRequirements.add("Lysine")
        if (finalMet < target.methionine - 0.03) failedRequirements.add("Methionine")

        val isSuccess = failedRequirements.isEmpty()
        val errorMsg = if (isSuccess) null else {
            "Note: Nutritional targets are extremely tight for the selected available ingredients. Under-formulated in: ${failedRequirements.joinToString(", ")}. Consider selecting high protein/mineral ingredients like Soybean Meal or Limestone."
        }

        return SolverResult(
            success = true, // We successfully calculated a formulation
            ingredientWeightsKg = weights,
            ingredientPercentages = percentages,
            achievedNutrients = achieved,
            totalCost = totalCost,
            costPerKg = finalCostPerKg,
            errorMessage = errorMsg
        )
    }
}
