@file:OptIn(ExperimentalMaterial3Api::class)
package com.example.ui

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.blur
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.*
import com.example.formulator.*
import com.example.pdf.PdfGenerator
import android.content.Intent
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.PoultryViewModel
import com.example.updater.RemoteUpdateManager
import com.example.updater.UpdateInfo
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.Date


fun formatIngredientName(name: String, isSwahili: Boolean): String {
    val regex = """\(([^)]+)\)""".toRegex()
    val matchResult = regex.find(name)
    if (matchResult != null) {
        val swahiliPart = matchResult.groupValues[1].trim()
        val englishPart = name.replace(regex, "").trim()
        return if (isSwahili) {
            swahiliPart
        } else {
            englishPart
        }
    }
    return name
}

@Composable
fun OfflineSyncStatusIndicator(isSwahili: Boolean) {
    var showExplanationDialog by remember { mutableStateOf(false) }
    
    // Subtle pulsing scale animation to signify real-time safety
    val infiniteTransition = rememberInfiniteTransition(label = "sync_pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "sync_scale"
    )

    Box(
        modifier = Modifier
            .testTag("offline_sync_status_indicator")
            .size(36.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f))
            .clickable {
                showExplanationDialog = true
            },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.CloudDone,
            contentDescription = if (isSwahili) "Hali ya Kuhifadhi" else "Sync Status",
            tint = Color(0xFF4CAF50), // Nice, green checkmark cloud
            modifier = Modifier
                .size(20.dp)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                }
        )
    }

    if (showExplanationDialog) {
        AlertDialog(
            onDismissRequest = { showExplanationDialog = false },
            icon = {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE8F5E9))
                ) {
                    Icon(
                        imageVector = Icons.Default.CloudDone,
                        contentDescription = null,
                        tint = Color(0xFF2E7D32),
                        modifier = Modifier.size(36.dp)
                    )
                }
            },
            title = {
                Text(
                    text = if (isSwahili) "Kifaa Kimesawazishwa" else "All Data Secured Offline",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = if (isSwahili)
                            "Mabadiliko yako yote yanahifadhiwa salama kwenye hifadhi ya ndani ya kifaa chako (Room DB & SharedPreferences)."
                            else "Your changes are successfully saved and secured on this device's local database (Room DB & Shared Preferences).",
                        textAlign = TextAlign.Center,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (isSwahili)
                            "✓ Huhitaji mtandao kutumia Farmix\n✓ Salama na faragha 100%\n✓ Utendaji wa haraka usio na kikomo"
                            else "✓ No active connection required\n✓ 100% private and secure\n✓ Instant high-speed computation",
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Start,
                        fontSize = 13.sp,
                        color = Color(0xFF2E7D32),
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFF1F8E9), RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { showExplanationDialog = false }
                ) {
                    Text(
                        text = if (isSwahili) "Sawa" else "Got it",
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            shape = RoundedCornerShape(24.dp)
        )
    }
}

@Composable
fun FeedAppHome(viewModel: PoultryViewModel) {
    val appAppearance by viewModel.appAppearance.collectAsStateWithLifecycle()
    val isSwahili by viewModel.isSwahili.collectAsStateWithLifecycle()
    val systemInDark = isSystemInDarkTheme()
    val isDark = when (appAppearance) {
        "light" -> false
        "dark" -> true
        else -> systemInDark
    }

    var screenStack by remember { mutableStateOf(listOf("splash")) }
    val currentScreen = screenStack.lastOrNull() ?: "home"
    var lastBackPressTime by remember { mutableStateOf(0L) }

    if (currentScreen != "home" && currentScreen != "splash") {
        androidx.activity.compose.BackHandler {
            if (screenStack.size > 1) {
                screenStack = screenStack.dropLast(1)
            } else {
                screenStack = listOf("home")
            }
        }
    }

    MyApplicationTheme(darkTheme = if (currentScreen == "splash") true else isDark) {
        val context = LocalContext.current

        if (currentScreen == "home") {
            androidx.activity.compose.BackHandler {
                val currentTime = System.currentTimeMillis()
                if (currentTime - lastBackPressTime < 2000) {
                    (context as? android.app.Activity)?.finish()
                } else {
                    lastBackPressTime = currentTime
                    val msg = if (isSwahili) "Gusa tena ili kutoka" else "Press back again to exit"
                    Toast.makeText(context.applicationContext, msg, Toast.LENGTH_SHORT).show()
                }
            }
        }

        val globalScope = rememberCoroutineScope()
        val updateUrl by RemoteUpdateManager.updateUrl.collectAsStateWithLifecycle()
        val globalUpdateInfo by RemoteUpdateManager.updateInfo.collectAsStateWithLifecycle()
        val isCheckingGlobalUpdate by RemoteUpdateManager.isCheckingUpdate.collectAsStateWithLifecycle()
        val globalDownloadProgress by RemoteUpdateManager.downloadProgress.collectAsStateWithLifecycle()
        val globalStatusMessage by RemoteUpdateManager.statusMessage.collectAsStateWithLifecycle()
        val showGlobalUpdateDialog by RemoteUpdateManager.showUpdateDialog.collectAsStateWithLifecycle()

        LaunchedEffect(Unit) {
            try {
                val info = RemoteUpdateManager.checkUpdates(context, updateUrl)
                if (info.isUpdateAvailable) {
                    RemoteUpdateManager.updateInfo.value = info
                } else {
                    RemoteUpdateManager.updateInfo.value = null
                }
            } catch (e: Exception) {
                // Fail silently on background startup checks
            }
        }

        // Screen state wrapper to handle Back behaviors
        Scaffold(
            topBar = {
                if (currentScreen != "splash") {
                    if (currentScreen == "home") {
                        TopAppBar(
                            title = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.testTag("top_bar_farmix_title")
                                ) {
                                    Card(
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isDark) Color(0xFF1B251E) else Color(0xFFFAF6EE)
                                        ),
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(
                                            width = 1.dp,
                                            color = if (isDark) Color(0xFF2C352E) else Color(0xFFE3DAC9)
                                        ),
                                        modifier = Modifier.size(34.dp).shadow(1.5.dp, shape = RoundedCornerShape(10.dp))
                                    ) {
                                        Box(
                                            modifier = Modifier.fillMaxSize().padding(4.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            FarmixLogoDrawing(modifier = Modifier.fillMaxSize())
                                        }
                                    }
                                    Text(
                                        text = "FARMIX",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 19.sp,
                                        color = MaterialTheme.colorScheme.primary,
                                        letterSpacing = 1.1.sp
                                    )
                                    Spacer(modifier = Modifier.width(2.dp))
                                    OfflineSyncStatusIndicator(isSwahili)
                                }
                            },
                            navigationIcon = {
                                IconButton(
                                    onClick = {
                                        Toast.makeText(
                                            context.applicationContext,
                                            if (isSwahili) "Menyu imefunguliwa - Programu inaendesha nje ya mtandao" else "Menu opened - App is fully offline",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    },
                                    modifier = Modifier.testTag("top_bar_menu_btn")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Menu,
                                        contentDescription = "Menu",
                                        tint = MaterialTheme.colorScheme.onBackground
                                    )
                                }
                            },
                            actions = {
                                // Notification Bell Icon
                                IconButton(
                                    onClick = {
                                        Toast.makeText(
                                            context.applicationContext,
                                            if (isSwahili) "Hakuna arifa mpya kwa sasa." else "No new notifications.",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    },
                                    modifier = Modifier.testTag("top_bar_notifications_btn")
                                ) {
                                    Box(contentAlignment = Alignment.TopEnd) {
                                        Icon(
                                            imageVector = Icons.Default.Notifications,
                                            contentDescription = "Notifications",
                                            tint = MaterialTheme.colorScheme.onBackground
                                        )
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(Color.Red)
                                        )
                                    }
                                }

                                // User / Profile Icon
                                IconButton(
                                    onClick = {
                                        screenStack = listOf("home", "settings")
                                    },
                                    modifier = Modifier.testTag("top_bar_profile_btn")
                                ) {
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Person,
                                            contentDescription = "Profile",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.background,
                                titleContentColor = MaterialTheme.colorScheme.onBackground
                            )
                        )
                    } else {
                        CenterAlignedTopAppBar(
                            title = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = getScreenTitle(currentScreen, isSwahili),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp,
                                        maxLines = 1,
                                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f, fill = false)
                                    )
                                    OfflineSyncStatusIndicator(isSwahili)
                                }
                            },
                            navigationIcon = {
                                IconButton(onClick = {
                                    if (screenStack.size > 1) {
                                        screenStack = screenStack.dropLast(1)
                                    } else {
                                        screenStack = listOf("home")
                                    }
                                }) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                        contentDescription = "Back"
                                    )
                                }
                            },
                            actions = {
                                // Quick toggle language
                                IconButton(onClick = { viewModel.isSwahili.value = !isSwahili }) {
                                    Text(
                                        text = if (isSwahili) "EN" else "SW",
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontSize = 14.sp
                                    )
                                }
                                // Quick toggle theme
                                IconButton(onClick = { viewModel.toggleTheme(isDark) }) {
                                    Icon(
                                        imageVector = if (isDark) Icons.Default.LightMode else Icons.Default.DarkMode,
                                        contentDescription = "Theme Toggle"
                                    )
                                }
                                // Wireless Remote Update Icon Button
                                if (isCheckingGlobalUpdate) {
                                    Box(
                                        modifier = Modifier.padding(12.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(16.dp),
                                            strokeWidth = 2.dp,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                } else {
                                    IconButton(
                                        onClick = {
                                            RemoteUpdateManager.isCheckingUpdate.value = true
                                            globalScope.launch {
                                                try {
                                                    val info = RemoteUpdateManager.checkUpdates(context, updateUrl)
                                                    RemoteUpdateManager.updateInfo.value = info
                                                    if (info.isUpdateAvailable) {
                                                        RemoteUpdateManager.showUpdateDialog.value = true
                                                    } else {
                                                        val msg = if (isSwahili) "Programu yako ipo kwenye toleo jipya zaidi!" else "Your app is already up to date!"
                                                        Toast.makeText(context.applicationContext, msg, Toast.LENGTH_LONG).show()
                                                    }
                                                } catch (e: Exception) {
                                                    Toast.makeText(
                                                        context,
                                                        if (isSwahili) "Mawasiliano yameshindwa: ${e.localizedMessage}" else "Connection issue: ${e.localizedMessage}",
                                                        Toast.LENGTH_SHORT
                                                    ).show()
                                                } finally {
                                                    RemoteUpdateManager.isCheckingUpdate.value = false
                                                }
                                            }
                                        },
                                        modifier = Modifier.testTag("top_bar_update_btn")
                                    ) {
                                        Box(contentAlignment = Alignment.TopEnd) {
                                            Icon(
                                                imageVector = Icons.Default.CloudDownload,
                                                contentDescription = "Wireless Remote Update",
                                                tint = if (globalUpdateInfo?.isUpdateAvailable == true) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(20.dp)
                                            )
                                            if (globalUpdateInfo?.isUpdateAvailable == true) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(8.dp)
                                                        .clip(CircleShape)
                                                        .background(MaterialTheme.colorScheme.error)
                                                        .border(1.dp, MaterialTheme.colorScheme.background, CircleShape)
                                                )
                                            }
                                        }
                                    }
                                }
                                // Settings Small Icon aside theme icon
                                IconButton(
                                    onClick = { screenStack = screenStack + "settings" },
                                    modifier = Modifier.testTag("top_bar_settings_btn")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Settings,
                                        contentDescription = "Settings",
                                        tint = MaterialTheme.colorScheme.onBackground,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            },
                            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                                containerColor = MaterialTheme.colorScheme.background,
                                titleContentColor = MaterialTheme.colorScheme.onBackground
                            )
                        )
                    }
                }
            },
            bottomBar = {
                if (currentScreen != "splash") {
                    NavigationBar(
                        modifier = Modifier.testTag("app_bottom_navigation_bar"),
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 8.dp
                    ) {
                        val selectedTab = when (currentScreen) {
                            "home" -> 0
                            "req_calc", "what_i_have", "formulation", "budget_formula", "cost_calc", "growth", "profit", "ai_advisor", "prices", "ingredients_manager" -> 1
                            "saved" -> 2
                            "settings" -> 3
                            else -> 0
                        }

                        // Tab 1: Dashboard
                        NavigationBarItem(
                            selected = selectedTab == 0,
                            onClick = {
                                if (currentScreen != "home") {
                                    screenStack = listOf("home")
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = Icons.Default.Home,
                                    contentDescription = if (isSwahili) "Mwanzo" else "Dashboard"
                                )
                            },
                            label = {
                                Text(
                                    text = if (isSwahili) "Mwanzo" else "Dashboard",
                                    fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 11.sp
                                )
                            },
                            alwaysShowLabel = true,
                            modifier = Modifier.testTag("nav_item_dashboard")
                        )

                        // Tab 2: Formulate
                        NavigationBarItem(
                            selected = selectedTab == 1,
                            onClick = {
                                if (currentScreen != "req_calc") {
                                    viewModel.resetFormulationSession()
                                    screenStack = listOf("home", "req_calc")
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = Icons.Default.Science,
                                    contentDescription = if (isSwahili) "Lishe" else "Formulate"
                                )
                            },
                            label = {
                                Text(
                                    text = if (isSwahili) "Lishe" else "Formulate",
                                    fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 11.sp
                                )
                            },
                            alwaysShowLabel = true,
                            modifier = Modifier.testTag("nav_item_formulate")
                        )

                        // Tab 3: Reports
                        NavigationBarItem(
                            selected = selectedTab == 2,
                            onClick = {
                                if (currentScreen != "saved") {
                                    screenStack = listOf("home", "saved")
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = Icons.Default.BarChart,
                                    contentDescription = if (isSwahili) "Ripoti" else "Reports"
                                )
                            },
                            label = {
                                Text(
                                    text = if (isSwahili) "Ripoti" else "Reports",
                                    fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 11.sp
                                )
                            },
                            alwaysShowLabel = true,
                            modifier = Modifier.testTag("nav_item_reports")
                        )

                        // Tab 4: Profile
                        NavigationBarItem(
                            selected = selectedTab == 3,
                            onClick = {
                                if (currentScreen != "settings") {
                                    screenStack = listOf("home", "settings")
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = if (isSwahili) "Profaili" else "Profile"
                                )
                            },
                            label = {
                                Text(
                                    text = if (isSwahili) "Profaili" else "Profile",
                                    fontWeight = if (selectedTab == 3) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 11.sp
                                )
                            },
                            alwaysShowLabel = true,
                            modifier = Modifier.testTag("nav_item_profile")
                        )
                    }
                }
            },
            modifier = Modifier.fillMaxSize().testTag("app_main_scaffold")
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(if (currentScreen == "splash") PaddingValues(0.dp) else innerPadding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                AnimatedContent(
                    targetState = currentScreen,
                    transitionSpec = {
                        fadeIn() togetherWith fadeOut()
                    },
                    label = "ScreenTransition"
                ) { screen ->
                    when (screen) {
                        "splash" -> SplashScreen(isSwahili = isSwahili, onFinished = { screenStack = listOf("home") })
                        "home" -> HomeScreen(onNavigate = { destination ->
                            if (destination == "req_calc") {
                                viewModel.resetFormulationSession()
                            }
                            screenStack = screenStack + destination
                        }, isSwahili)
                        "what_i_have" -> WhatIHaveScreen(viewModel, onNavigate = { destination -> if (destination == "home") screenStack = listOf("home") else screenStack = screenStack + destination }, isSwahili)
                        "formulation" -> ResponsiveFormulationScreen(viewModel, onNavigate = { destination -> if (destination == "home") screenStack = listOf("home") else screenStack = screenStack + destination }, isSwahili)
                        "budget_formula" -> FixedBudgetScreen(viewModel, onNavigate = { destination -> if (destination == "home") screenStack = listOf("home") else screenStack = screenStack + destination }, isSwahili)
                        "cost_calc" -> CostCalculatorScreen(viewModel, onNavigate = { destination -> if (destination == "home") screenStack = listOf("home") else screenStack = screenStack + destination }, isSwahili)
                        "req_calc" -> FeedRequirementScreen(viewModel, onNavigate = { destination -> if (destination == "home") screenStack = listOf("home") else screenStack = screenStack + destination }, isSwahili)
                        "growth" -> GrowthEstimatorScreen(viewModel, isSwahili)
                        "ai_advisor" -> AIAdvisorScreen(viewModel, isSwahili)
                        "saved" -> SavedFormulationsScreen(
                            viewModel = viewModel,
                            onNavigate = { destination ->
                                if (destination == "home") {
                                    screenStack = listOf("home")
                                } else if (destination == "req_calc") {
                                    viewModel.resetFormulationSession()
                                    screenStack = listOf("home", "req_calc")
                                } else {
                                    screenStack = screenStack + destination
                                }
                            },
                            isSwahili = isSwahili
                        )
                        "prices" -> MaterialPriceScreen(
                            viewModel = viewModel,
                            isSwahili = isSwahili,
                            onSaveComplete = {
                                if (screenStack.contains("what_i_have")) {
                                    val index = screenStack.indexOf("what_i_have")
                                    screenStack = screenStack.take(index + 1)
                                } else {
                                    screenStack = listOf("home")
                                }
                            }
                        )
                        "inventory" -> InventoryScreen(viewModel, isSwahili)
                        "settings" -> SettingsScreen(viewModel, isSwahili)
                        "profit" -> ProfitabilityScreen(viewModel, isSwahili)
                        "ingredients_manager" -> IngredientsManagerScreen(viewModel, onNavigate = { destination -> if (destination == "home") screenStack = listOf("home") else screenStack = screenStack + destination }, isSwahili)
                    }
                }

                // Floating Overlapping Progress Meter for background OTA wireless downloads
                globalDownloadProgress?.let { progress ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        contentAlignment = Alignment.BottomCenter
                    ) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            tonalElevation = 8.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .widthIn(max = 450.dp)
                                .shadow(8.dp, RoundedCornerShape(16.dp))
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        CircularProgressIndicator(
                                            progress = { progress },
                                            modifier = Modifier.size(18.dp),
                                            strokeWidth = 2.5.dp,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            text = globalStatusMessage,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Text(
                                        text = "${(progress * 100).toInt()}%",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                LinearProgressIndicator(
                                    progress = { progress },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp)
                                        .clip(RoundedCornerShape(3.dp)),
                                    color = MaterialTheme.colorScheme.primary,
                                    trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                                )
                            }
                        }
                    }
                }

                // Global OTA Update Dialog
                if (showGlobalUpdateDialog) {
                    val info = globalUpdateInfo
                    if (info != null) {
                        Dialog(onDismissRequest = { RemoteUpdateManager.showUpdateDialog.value = false }) {
                            Surface(
                                shape = RoundedCornerShape(24.dp),
                                color = MaterialTheme.colorScheme.surface,
                                tonalElevation = 6.dp,
                                modifier = Modifier
                                    .padding(16.dp)
                                    .fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(24.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(CircleShape)
                                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.SystemUpdate,
                                                contentDescription = "System Update Available",
                                                tint = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(
                                                text = if (isSwahili) "Mwisho Mpya Umepatikana" else "New Version Available",
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 16.sp,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = "v${RemoteUpdateManager.getAppVersionName(context)} → v${info.latestVersionName}",
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.primary,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(16.dp))
                                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                                    Spacer(modifier = Modifier.height(12.dp))

                                    Text(
                                        text = if (isSwahili) "Mabadiliko katika toleo hili:" else "Release Changelog:",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = info.releaseNotes,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.padding(12.dp),
                                            lineHeight = 16.sp
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(20.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        OutlinedButton(
                                            onClick = { RemoteUpdateManager.showUpdateDialog.value = false },
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Text(if (isSwahili) "Baadaye" else "Dismiss")
                                        }

                                        Button(
                                            onClick = {
                                                RemoteUpdateManager.showUpdateDialog.value = false
                                                globalScope.launch {
                                                    val ok = RemoteUpdateManager.downloadAndInstallApk(context, info.downloadUrl)
                                                    if (ok) {
                                                        Toast.makeText(context.applicationContext, "Initiating update installation...", Toast.LENGTH_LONG).show()
                                                    } else {
                                                        Toast.makeText(context.applicationContext, "Update download failed. Check connection.", Toast.LENGTH_LONG).show()
                                                    }
                                                }
                                            },
                                            modifier = Modifier
                                                .weight(1.3f)
                                                .testTag("global_trigger_remote_download_btn"),
                                            shape = RoundedCornerShape(12.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                        ) {
                                            Icon(Icons.Default.Download, contentDescription = "Download", modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(if (isSwahili) "Sakinisha" else "Download Now")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FarmixLogoDrawing(
    modifier: Modifier = Modifier,
    circleProgress: Float = 1f,
    leafProgress: Float = 1f,
    grainProgress: Float = 1f,
    chickenProgress: Float = 1f
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val sz = if (w < h) w else h
        if (sz <= 0f) return@Canvas

        val cx = w / 2f
        val cy = h / 2f
        val scaleFactor = sz / 108f

        fun Float.toCanvasX(): Float = cx + (this - 54f) * scaleFactor
        fun Float.toCanvasY(): Float = cy + (this - 54f) * scaleFactor

        // 1. Draw circular mixing motion arc (Golden Grain accent)
        if (circleProgress > 0f) {
            val sweepRadius = 25f * scaleFactor
            val arcBrush = androidx.compose.ui.graphics.Brush.linearGradient(
                colors = listOf(Color(0xFFF9A825), Color(0xFFFFD54F)),
                start = androidx.compose.ui.geometry.Offset(20f.toCanvasX(), 30f.toCanvasY()),
                end = androidx.compose.ui.geometry.Offset(50f.toCanvasX(), 80f.toCanvasY())
            )
            drawArc(
                brush = arcBrush,
                startAngle = 135f,
                sweepAngle = -270f * circleProgress,
                useCenter = false,
                style = androidx.compose.ui.graphics.drawscope.Stroke(
                    width = 1.6f * scaleFactor,
                    cap = androidx.compose.ui.graphics.StrokeCap.Round
                ),
                topLeft = androidx.compose.ui.geometry.Offset(cx - sweepRadius, cy - sweepRadius),
                size = androidx.compose.ui.geometry.Size(sweepRadius * 2, sweepRadius * 2)
            )
        }

        // 2. Draw Stylized Golden Grain seed 1
        if (grainProgress > 0f) {
            this.scale(scale = grainProgress, pivot = androidx.compose.ui.geometry.Offset(cx, cy)) {
                val seed1Path = androidx.compose.ui.graphics.Path().apply {
                    moveTo(28f.toCanvasX(), 58f.toCanvasY())
                    cubicTo(30f.toCanvasX(), 60f.toCanvasY(), 31f.toCanvasX(), 64f.toCanvasY(), 29f.toCanvasX(), 67f.toCanvasY())
                    cubicTo(27f.toCanvasX(), 69f.toCanvasY(), 25f.toCanvasX(), 67f.toCanvasY(), 24f.toCanvasX(), 64f.toCanvasY())
                    cubicTo(23f.toCanvasX(), 61f.toCanvasY(), 25f.toCanvasX(), 58f.toCanvasY(), 28f.toCanvasX(), 58f.toCanvasY())
                    close()
                }
                val seed1Brush = androidx.compose.ui.graphics.Brush.linearGradient(
                    colors = listOf(Color(0xFFFFD54F), Color(0xFFF9A825)),
                    start = androidx.compose.ui.geometry.Offset(24f.toCanvasX(), 58f.toCanvasY()),
                    end = androidx.compose.ui.geometry.Offset(31f.toCanvasX(), 67f.toCanvasY())
                )
                drawPath(path = seed1Path, brush = seed1Brush)

                // 3. Draw Stylized Golden Grain seed 2
                val seed2Path = androidx.compose.ui.graphics.Path().apply {
                    moveTo(25f.toCanvasX(), 44f.toCanvasY())
                    cubicTo(28f.toCanvasX(), 46f.toCanvasY(), 29f.toCanvasX(), 51f.toCanvasY(), 27f.toCanvasX(), 54f.toCanvasY())
                    cubicTo(25f.toCanvasX(), 56f.toCanvasY(), 22f.toCanvasX(), 54f.toCanvasY(), 21f.toCanvasX(), 51f.toCanvasY())
                    cubicTo(20f.toCanvasX(), 48f.toCanvasY(), 22f.toCanvasX(), 44f.toCanvasY(), 25f.toCanvasX(), 44f.toCanvasY())
                    close()
                }
                val seed2Brush = androidx.compose.ui.graphics.Brush.linearGradient(
                    colors = listOf(Color(0xFFFFD54F), Color(0xFFF9A825)),
                    start = androidx.compose.ui.geometry.Offset(21f.toCanvasX(), 44f.toCanvasY()),
                    end = androidx.compose.ui.geometry.Offset(29f.toCanvasX(), 54f.toCanvasY())
                )
                drawPath(path = seed2Path, brush = seed2Brush)
            }
        }

        // 4. Draw Premium Minimalist Letter 'F' shape in off-white
        if (chickenProgress > 0f) {
            this.scale(scale = chickenProgress, pivot = androidx.compose.ui.geometry.Offset(cx, cy)) {
                val fPath = androidx.compose.ui.graphics.Path().apply {
                    moveTo(38f.toCanvasX(), 70f.toCanvasY())
                    cubicTo(38f.toCanvasX(), 72f.toCanvasY(), 39.5f.toCanvasX(), 73.5f.toCanvasY(), 41.5f.toCanvasX(), 73.5f.toCanvasY())
                    cubicTo(43.5f.toCanvasX(), 73.5f.toCanvasY(), 45f.toCanvasX(), 72f.toCanvasY(), 45f.toCanvasX(), 70f.toCanvasY())
                    lineTo(45f.toCanvasX(), 58f.toCanvasY())
                    lineTo(62f.toCanvasX(), 58f.toCanvasY())
                    cubicTo(64f.toCanvasX(), 58f.toCanvasY(), 65.5f.toCanvasX(), 56.5f.toCanvasY(), 65.5f.toCanvasX(), 54.5f.toCanvasY())
                    cubicTo(65.5f.toCanvasX(), 52.5f.toCanvasY(), 64f.toCanvasX(), 51f.toCanvasY(), 62f.toCanvasX(), 51f.toCanvasY())
                    lineTo(45f.toCanvasX(), 51f.toCanvasY())
                    lineTo(45f.toCanvasX(), 44f.toCanvasY())
                    lineTo(68f.toCanvasX(), 44f.toCanvasY())
                    cubicTo(70f.toCanvasX(), 44f.toCanvasY(), 71.5f.toCanvasX(), 42.5f.toCanvasY(), 71.5f.toCanvasX(), 40.5f.toCanvasY())
                    cubicTo(71.5f.toCanvasX(), 38.5f.toCanvasY(), 70f.toCanvasX(), 37f.toCanvasY(), 68f.toCanvasX(), 37f.toCanvasY())
                    lineTo(41.5f.toCanvasX(), 37f.toCanvasY())
                    cubicTo(39.5f.toCanvasX(), 37f.toCanvasY(), 38f.toCanvasX(), 38.5f.toCanvasY(), 38f.toCanvasX(), 40.5f.toCanvasY())
                    close()
                }
                drawPath(path = fPath, color = Color.White)
            }
        }

        // 5. Draw Organic Emerald-Green Leaf
        if (leafProgress > 0f) {
            this.scale(scale = leafProgress, pivot = androidx.compose.ui.geometry.Offset(cx, cy)) {
                val leafPath = androidx.compose.ui.graphics.Path().apply {
                    moveTo(45f.toCanvasX(), 58f.toCanvasY())
                    cubicTo(45f.toCanvasX(), 58f.toCanvasY(), 53f.toCanvasX(), 72f.toCanvasY(), 67f.toCanvasX(), 72f.toCanvasY())
                    cubicTo(73.5f.toCanvasX(), 72f.toCanvasY(), 77.5f.toCanvasX(), 64.5f.toCanvasY(), 77.5f.toCanvasX(), 57f.toCanvasY())
                    cubicTo(77.5f.toCanvasX(), 53f.toCanvasY(), 72.5f.toCanvasX(), 49.5f.toCanvasY(), 63f.toCanvasX(), 53f.toCanvasY())
                    cubicTo(53.5f.toCanvasX(), 56.5f.toCanvasY(), 45f.toCanvasX(), 58f.toCanvasY(), 45f.toCanvasX(), 58f.toCanvasY())
                    close()
                }
                val leafBrush = androidx.compose.ui.graphics.Brush.linearGradient(
                    colors = listOf(Color(0xFF2E7D32), Color(0xFF4CAF50), Color(0xFF81C784)),
                    start = androidx.compose.ui.geometry.Offset(45f.toCanvasX(), 58f.toCanvasY()),
                    end = androidx.compose.ui.geometry.Offset(77.5f.toCanvasX(), 57f.toCanvasY())
                )
                drawPath(path = leafPath, brush = leafBrush)

                // 6. Subtle leaf vein
                val veinPath = androidx.compose.ui.graphics.Path().apply {
                    moveTo(45f.toCanvasX(), 58f.toCanvasY())
                    cubicTo(53f.toCanvasX(), 61f.toCanvasY(), 65f.toCanvasX(), 61f.toCanvasY(), 77f.toCanvasX(), 57f.toCanvasY())
                }
                drawPath(
                    path = veinPath,
                    color = Color(0xFFC8E6C9),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(
                        width = 1.0f * scaleFactor,
                        cap = androidx.compose.ui.graphics.StrokeCap.Round
                    )
                )
            }
        }
    }
}

@Composable
fun FarmixLogoCard(
    modifier: Modifier = Modifier,
    circleProgress: Float = 1f,
    leafProgress: Float = 1f,
    grainProgress: Float = 1f,
    chickenProgress: Float = 1f,
    textProgress: Float = 1f,
    cardScale: Float = 1f
) {
    val isDark = MaterialTheme.colorScheme.background.red < 0.2f
    Card(
        modifier = modifier
            .graphicsLayer {
                scaleX = cardScale
                scaleY = cardScale
            }
            .shadow(
                elevation = animateDpAsState(if (textProgress > 0.1f) 10.dp else 0.dp).value,
                shape = RoundedCornerShape(28.dp)
            ),
        colors = CardDefaults.cardColors(
            containerColor = if (isDark) Color(0xFF0C1F15) else Color(0xFFF1F8F4)
        ),
        shape = RoundedCornerShape(28.dp),
        border = BorderStroke(2.dp, if (isDark) Color(0xFF1E3526) else Color(0xFFC8E6C9))
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier.size(160.dp),
                contentAlignment = Alignment.Center
            ) {
                FarmixLogoDrawing(
                    modifier = Modifier.fillMaxSize(),
                    circleProgress = circleProgress,
                    leafProgress = leafProgress,
                    grainProgress = grainProgress,
                    chickenProgress = chickenProgress
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "FARMIX",
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold,
                color = if (isDark) Color(0xFF81C784) else Color(0xFF1B5E20), // Premium agricultural green
                letterSpacing = 4.sp,
                modifier = Modifier
                    .graphicsLayer {
                        alpha = textProgress
                        translationY = (1f - textProgress) * 12f
                    }
                    .testTag("farmix_logo_title")
            )
        }
    }
}

@Composable
fun SplashScreen(isSwahili: Boolean, onFinished: () -> Unit) {
    // Elegant exit transition progress
    val exitProgress = remember { Animatable(0f) }

    // Sequenced animation progress values
    val circleProgress = remember { Animatable(0f) }
    val stemProgress = remember { Animatable(0f) }
    val goldProgress = remember { Animatable(0f) }
    val leafProgress = remember { Animatable(0f) }
    val textProgress = remember { Animatable(0f) }
    val glowProgress = remember { Animatable(0f) }
    val loadingBarProgress = remember { Animatable(0f) }

    // Particle Convergence anim phase (from 0 to 1 over 1500ms)
    val particleConverge = remember { Animatable(0f) }

    // Timeline LaunchedEffect
    LaunchedEffect(Unit) {
        // Converge particles over 1200ms
        launch {
            particleConverge.animateTo(
                targetValue = 1f,
                animationSpec = tween(1200, easing = CubicBezierEasing(0.25f, 0.1f, 0.25f, 1f))
            )
        }

        // Draw outer ring (as particles converge, around 300ms to 1100ms)
        launch {
            kotlinx.coroutines.delay(300)
            circleProgress.animateTo(
                targetValue = 1f,
                animationSpec = tween(800, easing = FastOutSlowInEasing)
            )
        }

        // Glow expands (400ms to 1200ms)
        launch {
            kotlinx.coroutines.delay(400)
            glowProgress.animateTo(
                targetValue = 1f,
                animationSpec = tween(800, easing = FastOutSlowInEasing)
            )
        }

        // Vertical stem grows (500ms to 1300ms)
        launch {
            kotlinx.coroutines.delay(500)
            stemProgress.animateTo(
                targetValue = 1f,
                animationSpec = tween(800, easing = FastOutSlowInEasing)
            )
        }

        // Gold grain columns rise (600ms to 1400ms)
        launch {
            kotlinx.coroutines.delay(600)
            goldProgress.animateTo(
                targetValue = 1f,
                animationSpec = tween(800, easing = FastOutSlowInEasing)
            )
        }

        // Organic leaves sweep outwards (700ms to 1500ms)
        launch {
            kotlinx.coroutines.delay(700)
            leafProgress.animateTo(
                targetValue = 1f,
                animationSpec = tween(800, easing = FastOutSlowInEasing)
            )
        }

        // Typography text reveals beautifully (1000ms to 1800ms)
        launch {
            kotlinx.coroutines.delay(1000)
            textProgress.animateTo(
                targetValue = 1f,
                animationSpec = tween(800, easing = FastOutSlowInEasing)
            )
        }

        // Smooth loading progress (0 to 5000ms)
        launch {
            loadingBarProgress.animateTo(
                targetValue = 1.0f,
                animationSpec = tween(5000, easing = LinearEasing)
            )
        }

        // Trigger scale down and soft blur on complete (5100ms to 5600ms)
        kotlinx.coroutines.delay(5100)
        exitProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(500, easing = FastOutSlowInEasing)
        )
        onFinished()
    }

    // Infinite transition for orbital rotation of particles & pulse alpha
    val infiniteTransition = rememberInfiniteTransition(label = "ambient_effects")

    val driftY by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(25000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "drift_y"
    )

    val spinAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "spin_angle"
    )

    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    // Setup 40 particles
    val particles = remember {
        List(40) { i ->
            val angle = (i * 137.5f) * (Math.PI / 180f).toFloat()
            val distRatio = 0.6f + (i * 0.025f)
            val speed = 0.6f + ((i * 3) % 5) * 0.2f
            val sizeVal = 2f + ((i * 7) % 5) * 1.0f
            val orbitOffset = ((i * 23) % 360f)

            object {
                val initAngle = angle
                val initialDistanceRatio = distRatio
                val speedFactor = speed
                val size = sizeVal
                val offset = orbitOffset
            }
        }
    }

    // Sequenced loading messages distributed over 5 seconds (5000ms) for high performance setup
    var loadingMessage by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        // Phase 1: 0 - 1000ms
        loadingMessage = if (isSwahili) "Inapakia Hifadhidata ya Lishe na Mifumo..." else "Loading Nutrient Database & Formulas..."
        
        // Phase 2: 1000 - 2000ms
        kotlinx.coroutines.delay(1000)
        loadingMessage = if (isSwahili) "Inapanga mafaili na kumbukumbu kwa kasi ya juu..." else "Arranging local files & cache directories..."
        
        // Phase 3: 2000 - 3000ms
        kotlinx.coroutines.delay(1000)
        loadingMessage = if (isSwahili) "Inaboresha injini ya ukokotoaji wa lishe..." else "Optimizing feed calculations engine..."
        
        // Phase 4: 3000 - 4000ms
        kotlinx.coroutines.delay(1000)
        loadingMessage = if (isSwahili) "Inatayarisha dashibodi yenye ufanisi wa juu..." else "Setting up high-performance responsive dashboard..."
        
        // Phase 5: 4000 - 5000ms
        kotlinx.coroutines.delay(1000)
        loadingMessage = if (isSwahili) "Kuhitimisha mazingira ya kasi ya kazi..." else "Finalizing responsive workspace environment..."
        
        // Ready Phase: 5000ms
        kotlinx.coroutines.delay(1000)
        loadingMessage = if (isSwahili) "Tayari..." else "Ready..."
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer {
                alpha = 1f - exitProgress.value
                scaleX = 1f - 0.06f * exitProgress.value
                scaleY = 1f - 0.06f * exitProgress.value
            }
            .blur(radius = (exitProgress.value * 16f).dp)
            .background(
                brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF02170D),
                        Color(0xFF010A06)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            val sz = if (width < height) width else height
            val cx = width / 2f
            val cy = height / 2f

            // 1. Soft green glow expanding behind the logo
            if (glowProgress.value > 0f) {
                val glowRadius = sz * 0.65f * glowProgress.value
                drawCircle(
                    brush = androidx.compose.ui.graphics.Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF2E7D32).copy(alpha = 0.25f * glowProgress.value * pulseAlpha),
                            Color(0xFF1B5E20).copy(alpha = 0.08f * glowProgress.value * pulseAlpha),
                            Color.Transparent
                        ),
                        center = androidx.compose.ui.geometry.Offset(cx, cy),
                        radius = glowRadius
                    ),
                    radius = glowRadius,
                    center = androidx.compose.ui.geometry.Offset(cx, cy)
                )
            }

            // 2. Swirling golden particles moving towards center
            val ringRadius = sz * 0.44f
            particles.forEach { p ->
                val initialRadius = p.initialDistanceRatio * sz
                val currentRadius = initialRadius + (ringRadius - initialRadius) * particleConverge.value

                val currentAngleRad = p.initAngle + 
                        (spinAngle * p.speedFactor + (1f - particleConverge.value) * p.offset) * (Math.PI / 180f).toFloat()

                val px = cx + cos(currentAngleRad) * currentRadius
                val py = cy + sin(currentAngleRad) * currentRadius

                val opacity = (0.2f + 0.6f * particleConverge.value) * (1f - 0.35f * circleProgress.value)

                drawCircle(
                    brush = androidx.compose.ui.graphics.Brush.radialGradient(
                        colors = listOf(
                            Color(0xFFFFF9C4).copy(alpha = opacity),
                            Color(0xFFFFB300).copy(alpha = 0f)
                        ),
                        center = androidx.compose.ui.geometry.Offset(px, py),
                        radius = p.size.dp.toPx() * 2.5f
                    ),
                    radius = p.size.dp.toPx() * 2.5f,
                    center = androidx.compose.ui.geometry.Offset(px, py)
                )
            }

            // 3. Normal ambient drifting background grains
            val ambientCount = 15
            for (i in 0 until ambientCount) {
                val seedX = (i * 0.23f + 0.05f) % 1f
                val seedY = (i * 0.17f + 0.15f) % 1f
                val sizeVal = (3f + ((i * 5) % 6)).dp.toPx()
                val driftSpeed = 0.25f + ((i * 2) % 3) * 0.1f
                val opacity = 0.08f + ((i * 7) % 5) * 0.03f

                val px = seedX * width
                val py = ((seedY * height - driftY * driftSpeed) % height + height) % height

                drawCircle(
                    color = Color(0xFFFFF9C4).copy(alpha = opacity * (1f - exitProgress.value)),
                    radius = sizeVal,
                    center = androidx.compose.ui.geometry.Offset(px, py)
                )
            }
        }

        // Foreground Contents
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .size(160.dp)
                    .graphicsLayer {
                        scaleX = 1f + 0.03f * pulseAlpha
                        scaleY = 1f + 0.03f * pulseAlpha
                    },
                contentAlignment = Alignment.Center
            ) {
                FarmixLogoDrawing(
                    modifier = Modifier.fillMaxSize(),
                    circleProgress = circleProgress.value,
                    leafProgress = leafProgress.value,
                    grainProgress = goldProgress.value,
                    chickenProgress = stemProgress.value
                )
            }

            Spacer(modifier = Modifier.height(35.dp))

            // Brand Typography & Tagline with smooth entrance fade and translation
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.graphicsLayer {
                    alpha = textProgress.value
                    translationY = (1f - textProgress.value) * 15f
                }
            ) {
                Text(
                    text = "FARMIX",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    letterSpacing = 6.sp,
                    modifier = Modifier.testTag("farmix_logo_title")
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = if (isSwahili) "Chakula Bora. Ukuzaji Bora." else "Smart Feed. Better Growth.",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFFA5D6A7),
                    letterSpacing = 1.5.sp
                )
            }

            Spacer(modifier = Modifier.height(50.dp))

            // Thin linear progress indicator & Message container
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.graphicsLayer {
                    alpha = textProgress.value
                }
            ) {
                // Sleek, minimal loading bar
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.55f)
                        .height(3.dp)
                        .background(Color.White.copy(alpha = 0.1f), shape = RoundedCornerShape(1.5.dp))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(loadingBarProgress.value)
                            .background(
                                brush = androidx.compose.ui.graphics.Brush.horizontalGradient(
                                    colors = listOf(Color(0xFF81C784), Color(0xFFFFB300))
                                ),
                                shape = RoundedCornerShape(1.5.dp)
                            )
                    )
                }

                // Smoothly animated loading message
                Box(
                    modifier = Modifier.height(30.dp),
                    contentAlignment = Alignment.Center
                ) {
                    androidx.compose.animation.AnimatedContent(
                        targetState = loadingMessage,
                        transitionSpec = {
                            fadeIn(animationSpec = tween(300)) togetherWith fadeOut(animationSpec = tween(250))
                        },
                        label = "LoadingMsgAnim"
                    ) { msg ->
                        Text(
                            text = msg,
                            style = TextStyle(
                                color = Color.White.copy(alpha = 0.65f),
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Normal,
                                letterSpacing = 0.5.sp
                            )
                        )
                    }
                }
            }
        }
    }
}

private fun getScreenTitle(screen: String, isSwahili: Boolean): String {
    return when (screen) {
        "home" -> if (isSwahili) "Dashibodi ya FARMIX" else "FARMIX Dashboard"
        "what_i_have" -> if (isSwahili) "Nyenzo Nilizonazo" else "What I Have"
        "formulation" -> if (isSwahili) "Tengeneza Lishe" else "Formulate"
        "budget_formula" -> if (isSwahili) "Fomula ya Bajeti" else "Budget Feed Formula"
        "cost_calc" -> if (isSwahili) "Kikokotoo cha Gharama" else "Cost Calculator"
        "req_calc" -> if (isSwahili) "Kiasi Kinachohitajika" else "Feed Requirements"
        "growth" -> if (isSwahili) "Makadirio ya Ukuaji" else "Growth Estimator"
        "ai_advisor" -> if (isSwahili) "Mshauri wa Lishe" else "AI Feed Advisor"
        "saved" -> if (isSwahili) "Historia ya Fomula" else "Saved Formulations & Logbook"
        "prices" -> if (isSwahili) "Maduka na Bei" else "Stores & Prices"
        "inventory" -> if (isSwahili) "Stoo ya Chakula" else "Feed Inventory Stock"
        "settings" -> if (isSwahili) "Mipangilio" else "Settings & Profiles"
        "profit" -> if (isSwahili) "Kikokotoo cha Faida" else "Profitability Projection"
        else -> "FARMIX"
    }
}

@Composable
fun FarmSunriseBanner(isSwahili: Boolean, modifier: Modifier = Modifier) {
    val isDark = MaterialTheme.colorScheme.background.red < 0.2f
    Card(
        shape = RoundedCornerShape(24.dp),
        modifier = modifier
            .fillMaxWidth()
            .height(180.dp)
            .testTag("hero_dashboard_card"),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                // Sky Gradient (Soft warm orange sunrise to light blue sky)
                val skyBrush = androidx.compose.ui.graphics.Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFFE0F7FA), // Light sky blue
                        Color(0xFFFFECB3), // Soft sunrise yellow
                        Color(0xFFFFCC80)  // Warm sunrise orange
                    )
                )
                drawRect(brush = skyBrush)

                // Sun emerging
                drawCircle(
                    brush = androidx.compose.ui.graphics.Brush.radialGradient(
                        colors = listOf(Color(0xFFFFF9C4), Color(0xFFFFB74D).copy(alpha = 0.8f), Color(0xFFFFB74D).copy(alpha = 0f)),
                        center = androidx.compose.ui.geometry.Offset(w * 0.75f, h * 0.5f),
                        radius = 80f
                    ),
                    radius = 80f,
                    center = androidx.compose.ui.geometry.Offset(w * 0.75f, h * 0.5f)
                )

                // Far mountains/hills
                val hill1 = androidx.compose.ui.graphics.Path().apply {
                    moveTo(0f, h)
                    quadraticTo(w * 0.3f, h * 0.55f, w * 0.6f, h * 0.85f)
                    quadraticTo(w * 0.8f, h * 0.7f, w, h)
                    close()
                }
                drawPath(
                    path = hill1,
                    color = Color(0xFFC8E6C9).copy(alpha = 0.5f)
                )

                val hill2 = androidx.compose.ui.graphics.Path().apply {
                    moveTo(w * 0.3f, h)
                    quadraticTo(w * 0.65f, h * 0.6f, w * 0.9f, h * 0.75f)
                    lineTo(w, h * 0.78f)
                    lineTo(w, h)
                    close()
                }
                drawPath(
                    path = hill2,
                    color = Color(0xFFA5D6A7).copy(alpha = 0.6f)
                )

                // Foreground green grass base
                val foregroundPath = androidx.compose.ui.graphics.Path().apply {
                    moveTo(0f, h)
                    quadraticTo(w * 0.25f, h * 0.72f, w * 0.6f, h * 0.8f)
                    quadraticTo(w * 0.85f, h * 0.75f, w, h * 0.82f)
                    lineTo(w, h)
                    close()
                }
                drawPath(
                    path = foregroundPath,
                    color = Color(0xFF81C784)
                )

                // Draw Chickens in foreground
                val c1X = w * 0.2f
                val c1Y = h * 0.78f
                drawCircle(
                    color = Color(0xFF2E7D32),
                    radius = 12f,
                    center = androidx.compose.ui.geometry.Offset(c1X, c1Y)
                )
                val c1HeadPath = androidx.compose.ui.graphics.Path().apply {
                    moveTo(c1X + 4f, c1Y - 6f)
                    quadraticTo(c1X + 15f, c1Y - 14f, c1X + 18f, c1Y - 16f)
                    lineTo(c1X + 14f, c1Y - 4f)
                    close()
                }
                drawPath(path = c1HeadPath, color = Color(0xFF1B5E20))
                drawCircle(color = Color(0xFFE53935), radius = 3f, center = androidx.compose.ui.geometry.Offset(c1X + 17f, c1Y - 18f))
                drawCircle(color = Color(0xFFF9A825), radius = 2f, center = androidx.compose.ui.geometry.Offset(c1X + 22f, c1Y - 14f))

                val c2X = w * 0.5f
                val c2Y = h * 0.85f
                drawCircle(
                    color = Color(0xFF1B5E20),
                    radius = 10f,
                    center = androidx.compose.ui.geometry.Offset(c2X, c2Y)
                )
                val c2HeadPath = androidx.compose.ui.graphics.Path().apply {
                    moveTo(c2X - 3f, c2Y - 5f)
                    quadraticTo(c2X - 12f, c2Y - 12f, c2X - 14f, c2Y - 14f)
                    lineTo(c2X - 10f, c2Y - 3f)
                    close()
                }
                drawPath(path = c2HeadPath, color = Color(0xFF2E7D32))
                drawCircle(color = Color(0xFFE53935), radius = 2.5f, center = androidx.compose.ui.geometry.Offset(c2X - 13f, c2Y - 16f))
                drawCircle(color = Color(0xFFF9A825), radius = 1.8f, center = androidx.compose.ui.geometry.Offset(c2X - 17f, c2Y - 12f))

                val c3X = w * 0.8f
                val c3Y = h * 0.87f
                drawCircle(
                    color = Color(0xFFF9A825),
                    radius = 6f,
                    center = androidx.compose.ui.geometry.Offset(c3X, c3Y)
                )
                drawCircle(
                    color = Color(0xFFFFF176),
                    radius = 4f,
                    center = androidx.compose.ui.geometry.Offset(c3X - 4f, c3Y - 4f)
                )
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        androidx.compose.ui.graphics.Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.38f),
                                Color.Black.copy(alpha = 0.15f),
                                Color.Black.copy(alpha = 0.45f)
                            )
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isSwahili) "Habari, Mkulima!" else "Hello, Smart Farmer!",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            style = TextStyle(
                                shadow = androidx.compose.ui.graphics.Shadow(
                                    color = Color.Black.copy(alpha = 0.6f),
                                    blurRadius = 6f,
                                    offset = androidx.compose.ui.geometry.Offset(2f, 2f)
                                )
                            )
                        )
                    }

                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isDark) Color(0xFF1B251E) else Color(0xFFFAF6EE)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.5.dp, if (isDark) Color(0xFF2C352E) else Color(0xFFE3DAC9)),
                        modifier = Modifier
                            .size(52.dp)
                            .shadow(2.dp, shape = RoundedCornerShape(12.dp))
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize().padding(6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            FarmixLogoDrawing(modifier = Modifier.fillMaxSize())
                        }
                    }
                }

                Text(
                    text = if (isSwahili)
                        "Unda lishe bora kwa kuku wako kwa gharama ya chini ukitumia viungo vya ndani."
                        else "Formulate highly nutritious, least-cost feeds offline using local ingredients.",
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White.copy(alpha = 0.95f),
                    style = TextStyle(
                        shadow = androidx.compose.ui.graphics.Shadow(
                            color = Color.Black.copy(alpha = 0.7f),
                            blurRadius = 4f,
                            offset = androidx.compose.ui.geometry.Offset(1f, 1f)
                        )
                    ),
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
    }
}

val ChickenFootprintIcon: ImageVector by lazy {
    ImageVector.Builder(
        name = "ChickenFootprint",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).path(
        fill = null,
        stroke = androidx.compose.ui.graphics.SolidColor(Color.White),
        strokeLineWidth = 2.5f,
        strokeLineCap = androidx.compose.ui.graphics.StrokeCap.Round,
        strokeLineJoin = androidx.compose.ui.graphics.StrokeJoin.Round
    ) {
        // Chicken footprint paths
        // Middle toe
        moveTo(12f, 15f)
        lineTo(12f, 4f)
        // Claw tips
        moveTo(12f, 4f)
        lineTo(11f, 2f)
        moveTo(12f, 4f)
        lineTo(13f, 2f)

        // Left toe
        moveTo(12f, 15f)
        lineTo(6f, 10f)
        // Claw tip for left toe
        moveTo(6f, 10f)
        lineTo(4.5f, 9.5f)

        // Right toe
        moveTo(12f, 15f)
        lineTo(18f, 10f)
        // Claw tip for right toe
        moveTo(18f, 10f)
        lineTo(19.5f, 9.5f)

        // Back toe (hallux)
        moveTo(12f, 15f)
        lineTo(12f, 20f)
        // Claw tip for back toe
        moveTo(12f, 20f)
        lineTo(12f, 21.5f)
    }.build()
}

// --- Home Screen Dashboard ---
@Composable
fun HomeScreen(onNavigate: (String) -> Unit, isSwahili: Boolean) {
    val isDark = MaterialTheme.colorScheme.background.red < 0.2f

    val quickActions = listOf(
        DashboardItem(
            id = "req_calc",
            title = if (isSwahili) "Lishe" else "Formulate",
            desc = if (isSwahili) "Mchanganyiko wa gharama nafuu" else "Least-cost feed mixer",
            icon = Icons.Default.Science,
            tag = "req_calc"
        ),
        DashboardItem(
            id = "prices",
            title = if (isSwahili) "Maduka" else "Stores",
            desc = if (isSwahili) "Maduka na bei za viungo" else "Stores & ingredient prices",
            icon = Icons.Default.Store,
            tag = "stores"
        ),
        DashboardItem(
            id = "saved",
            title = if (isSwahili) "Fomula" else "Recipes",
            desc = if (isSwahili) "Angalia fomula zote" else "Saved formulations",
            icon = Icons.AutoMirrored.Filled.MenuBook,
            tag = "recipes"
        ),
        DashboardItem(
            id = "growth",
            title = if (isSwahili) "Kuku" else "Flock",
            desc = if (isSwahili) "Ukuaji & ukubwa wa kundi" else "Growth & feeds",
            icon = ChickenFootprintIcon,
            tag = "growth"
        ),
        DashboardItem(
            id = "saved",
            title = if (isSwahili) "Ripoti" else "Reports",
            desc = if (isSwahili) "Ripoti na uchambuzi" else "Nutrient charts",
            icon = Icons.Default.BarChart,
            tag = "reports"
        ),
        DashboardItem(
            id = "profit",
            title = if (isSwahili) "Akiba" else "Savings",
            desc = if (isSwahili) "Changanua ufanisi na faida" else "Cost efficiency",
            icon = Icons.Default.AccountBalanceWallet,
            tag = "profit"
        ),
        DashboardItem(
            id = "ingredients_manager",
            title = if (isSwahili) "Viungo" else "Ingredients",
            desc = if (isSwahili) "Dhibiti maadili & bei" else "Manage feed profiles",
            icon = Icons.Default.Eco,
            tag = "ingredients_manager"
        ),
        DashboardItem(
            id = "settings",
            title = if (isSwahili) "Sanidi" else "Settings",
            desc = if (isSwahili) "Wasifu & mipangilio" else "Settings & profiles",
            icon = Icons.Default.Settings,
            tag = "settings"
        )
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Beautiful Sunrise Farm Landscape Hero Banner Card
        item {
            FarmSunriseBanner(isSwahili = isSwahili)
        }

        // Section Title
        item {
            Text(
                text = if (isSwahili) "Hatua za Haraka" else "Quick Actions",
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                color = MaterialTheme.colorScheme.onBackground
            )
        }        // Responsive Grid of cards (2 rows, 4 columns)
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val chunkedActions = quickActions.chunked(4)
                chunkedActions.forEach { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        rowItems.forEach { item ->
                            val bgAndTint = when (item.tag) {
                                "req_calc" -> {
                                    val bg = if (isDark) Color(0xFF1B3020) else Color(0xFFE8F5E9)
                                    val tint = if (isDark) Color(0xFF81C784) else Color(0xFF1E4620)
                                    bg to tint
                                }
                                "stores" -> {
                                    val bg = if (isDark) Color(0xFF2E221E) else Color(0xFFEFEBE9)
                                    val tint = if (isDark) Color(0xFFD7CCC8) else Color(0xFF6D4C41)
                                    bg to tint
                                }
                                "inventory" -> {
                                    val bg = if (isDark) Color(0xFF332A15) else Color(0xFFFCF3E3)
                                    val tint = if (isDark) Color(0xFFFFD54F) else Color(0xFFB57C1E)
                                    bg to tint
                                }
                                "recipes" -> {
                                    val bg = if (isDark) Color(0xFF202C12) else Color(0xFFE8F0EA)
                                    val tint = if (isDark) Color(0xFF9CCC65) else Color(0xFF2E6F40)
                                    bg to tint
                                }
                                "growth" -> {
                                    val bg = if (isDark) Color(0xFF332015) else Color(0xFFFBEBE6)
                                    val tint = if (isDark) Color(0xFFFFAB91) else Color(0xFFD35400)
                                    bg to tint
                                }
                                "reports" -> {
                                    val bg = if (isDark) Color(0xFF102A26) else Color(0xFFE0F2F1)
                                    val tint = if (isDark) Color(0xFF4DB6AC) else Color(0xFF00695C)
                                    bg to tint
                                }
                                "profit" -> {
                                    val bg = if (isDark) Color(0xFF162E1A) else Color(0xFFE8F5E9)
                                    val tint = if (isDark) Color(0xFF81C784) else Color(0xFF1B5E20)
                                    bg to tint
                                }
                                "settings" -> {
                                    val bg = if (isDark) Color(0xFF222B2F) else Color(0xFFECEFF1)
                                    val tint = if (isDark) Color(0xFFB0BEC5) else Color(0xFF455A64)
                                    bg to tint
                                }
                                else -> {
                                    val bg = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)
                                    val tint = MaterialTheme.colorScheme.primary
                                    bg to tint
                                }
                            }
                            
                            val iconBg = bgAndTint.first
                            val iconTint = bgAndTint.second

                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(112.dp)
                                    .clickable { onNavigate(item.id) }
                                    .testTag("menu_card_${item.tag}"),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surface
                                ),
                                shape = RoundedCornerShape(20.dp),
                                border = BorderStroke(
                                    width = 1.dp,
                                    color = if (isDark) Color(0xFF2C352E) else Color(0xFFE9DEC3).copy(alpha = 0.7f)
                                ),
                                elevation = CardDefaults.cardElevation(
                                    defaultElevation = 2.dp,
                                    pressedElevation = 0.5.dp
                                )
                            ) {
                                Column(
                                    modifier = Modifier
                                        .padding(vertical = 12.dp, horizontal = 4.dp)
                                        .fillMaxSize(),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    // Beautiful squircle container for icons
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(iconBg),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = item.icon,
                                            contentDescription = item.title,
                                            tint = iconTint,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    Text(
                                        text = item.title,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.5.sp,
                                        color = MaterialTheme.colorScheme.onBackground,
                                        textAlign = TextAlign.Center,
                                        maxLines = 1,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

data class DashboardItem(
    val id: String,
    val title: String,
    val desc: String,
    val icon: ImageVector,
    val tag: String
)

@Composable
fun WhatIHaveSectionCard(
    title: String,
    icon: ImageVector,
    color: Color,
    items: List<Ingredient>,
    viewModel: PoultryViewModel,
    isDark: Boolean
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isDark) Color(0xFF131A15) else Color(0xFFFAF6EE)
        ),
        border = BorderStroke(1.dp, (if (isDark) Color(0xFF2C352E) else Color(0xFFE3DAC9)).copy(alpha = 0.8f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Section Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = color,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = if (isDark) Color(0xFFE8F5E9) else Color(0xFF1B2E1E)
                )
            }
            
            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = (if (isDark) Color(0xFF2C352E) else Color(0xFFE3DAC9)).copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(10.dp))

            // Sub items column
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items.forEach { ing ->
                    IngredientCheckItem(ing, viewModel)
                }
            }
        }
    }
}

// --- 0. What I Have Screen ---
@Composable
fun WhatIHaveScreen(
    viewModel: PoultryViewModel,
    onNavigate: (String) -> Unit,
    isSwahili: Boolean
) {
    val ingredients by viewModel.ingredients.collectAsStateWithLifecycle()
    val allStores by viewModel.allStores.collectAsStateWithLifecycle()
    val activeStoreId by viewModel.selectedStoreId.collectAsStateWithLifecycle()
    val activeStore = allStores.find { it.id == activeStoreId }
    val activeStorePrices by viewModel.activeStorePrices.collectAsStateWithLifecycle()

    var expandedCategory by remember { mutableStateOf<String?>(null) }
    var storeDropdownExpanded by remember { mutableStateOf(false) }

    // Dropdown selection state & confirmation state
    var selectedStoreForWhatIHave by remember { mutableStateOf<Store?>(null) }
    var isConfirmed by remember { mutableStateOf(false) }

    var isLoadingStoreMaterials by remember { mutableStateOf(false) }
    var loadingMessage by remember { mutableStateOf("") }

    LaunchedEffect(isConfirmed, selectedStoreForWhatIHave) {
        if (isConfirmed && selectedStoreForWhatIHave != null) {
            isLoadingStoreMaterials = true
            val messages = if (isSwahili) {
                listOf(
                    "Tunapakia bei za viungo kutoka duka la '${selectedStoreForWhatIHave?.name}'...",
                    "Tunapanga viungo na vyanzo vya lishe kulingana na kategoria...",
                    "Kukokotoa bei na viungo kuongeza ufanisi katika lishe...",
                    "Mifumo ya hesabu ya viungo imekamilika!"
                )
            } else {
                listOf(
                    "Loading ingredient prices from '${selectedStoreForWhatIHave?.name}'...",
                    "Categorizing energy, protein, and mineral sources...",
                    "Optimizing formulation matrices for higher efficiency...",
                    "Material prices synchronized!"
                )
            }
            for (msg in messages) {
                loadingMessage = msg
                kotlinx.coroutines.delay(1000)
            }
            isLoadingStoreMaterials = false
        }
    }

    // Synchronize selection and confirmation states when allStores load or change
    LaunchedEffect(allStores) {
        if (allStores.isEmpty()) {
            selectedStoreForWhatIHave = null
            isConfirmed = false
            viewModel.selectStore(null)
        } else if (allStores.size == 1) {
            val singleStore = allStores.first()
            selectedStoreForWhatIHave = singleStore
            isConfirmed = true
            viewModel.selectStore(singleStore.id)
        } else {
            // "the drop down menu has to be blank when page opens"
            selectedStoreForWhatIHave = null
            isConfirmed = false
            viewModel.selectStore(null)
        }
    }

    // Filter ingredients to only include those that have registered prices for this store
    val storeIngredients = if (isConfirmed && selectedStoreForWhatIHave != null) {
        val savedNames = activeStorePrices.map { it.ingredientName.lowercase().trim() }
        ingredients.filter { ing ->
            savedNames.contains(ing.name.lowercase().trim()) && ing.pricePerKg > 0.0
        }
    } else {
        emptyList()
    }
    val hasPrices = storeIngredients.isNotEmpty()

    // Group them exactly as requested
    val energyList = storeIngredients.filter { ing ->
        val nameLower = ing.name.lowercase()
        ing.category.lowercase() == "energy" || 
        nameLower.contains("maize") || nameLower.contains("rice") || 
        nameLower.contains("sorghum") || nameLower.contains("mtama") || nameLower.contains("cassava")
    }
    
    val proteinList = storeIngredients.filter { ing ->
        val nameLower = ing.name.lowercase()
        ing.category.lowercase() == "protein" || 
        nameLower.contains("soybean") || nameLower.contains("sunflower") || 
        nameLower.contains("cotton") || nameLower.contains("fish") || 
        nameLower.contains("omena") || nameLower.contains("blood")
    }

    val mineralList = storeIngredients.filter { ing ->
        val nameLower = ing.name.lowercase()
        ing.category.lowercase() == "mineral" || 
        nameLower.contains("limestone") || nameLower.contains("dcp") || 
        nameLower.contains("salt") || nameLower.contains("chumvi")
    }

    val otherList = storeIngredients.filter { ing ->
        ing !in energyList && ing !in proteinList && ing !in mineralList
    }

    val isEnergySelected = energyList.any { it.isSelected }
    val isProteinSelected = proteinList.any { it.isSelected }
    val isMineralSelected = mineralList.any { it.isSelected }
    val isSelectionValid = isEnergySelected && isProteinSelected && isMineralSelected
    var showValidationErrorDialog by remember { mutableStateOf(false) }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWide = maxWidth > 650.dp
        val isDark = MaterialTheme.colorScheme.background.red < 0.2f

        if (allStores.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Store,
                            contentDescription = "Store",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = if (isSwahili) "Hakuna Duka Lililosajiliwa" else "No Registered Stores",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (isSwahili)
                                "Tafadhali nenda kwenye sehemu ya Bei ili kuunda duka na kusajili bei za viungo kwanza."
                                else "Please go to the Prices section to create a store and register ingredient prices first.",
                            textAlign = TextAlign.Center,
                            fontSize = 14.sp,
                            color = Color.Gray
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        Button(
                            onClick = { onNavigate("prices") },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(if (isSwahili) "Nenda kwenye Bei" else "Go to Prices")
                        }
                    }
                }
            }
        } else {
            // Stores are available
            if (isWide) {
                // Responsive 2-column layout (CSS Grid-like columns)
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Column 1
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Store Selection Card embedded at the top
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.1f))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = if (isSwahili) "Kiwanda/Duka la Bei Inayotumika" else "Selected Price Store",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Box {
                                    OutlinedButton(
                                        onClick = { storeDropdownExpanded = true },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            containerColor = if (isConfirmed && selectedStoreForWhatIHave != null) {
                                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)
                                            } else {
                                                Color.Transparent
                                            }
                                        ),
                                        border = BorderStroke(
                                            width = 1.5.dp,
                                            color = if (isConfirmed && selectedStoreForWhatIHave != null) {
                                                MaterialTheme.colorScheme.primary
                                            } else {
                                                MaterialTheme.colorScheme.outline
                                            }
                                        ),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Text(
                                                    text = selectedStoreForWhatIHave?.name ?: "", // blank when page opens
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isConfirmed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                                    fontSize = 14.sp
                                                )
                                                if (isConfirmed && selectedStoreForWhatIHave != null) {
                                                    Icon(
                                                        imageVector = Icons.Default.CheckCircle,
                                                        contentDescription = "Confirmed Store",
                                                        tint = MaterialTheme.colorScheme.primary,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }
                                            }
                                            Icon(
                                                imageVector = Icons.Default.ArrowDropDown,
                                                contentDescription = "Dropdown",
                                                tint = if (isConfirmed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    DropdownMenu(
                                        expanded = storeDropdownExpanded,
                                        onDismissRequest = { storeDropdownExpanded = false },
                                        modifier = Modifier.fillMaxWidth(0.9f)
                                    ) {
                                        allStores.forEach { store ->
                                            DropdownMenuItem(
                                                text = {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = store.name,
                                                            fontWeight = if (selectedStoreForWhatIHave?.id == store.id) FontWeight.Bold else FontWeight.Normal
                                                        )
                                                        if (selectedStoreForWhatIHave?.id == store.id) {
                                                            Icon(
                                                                imageVector = Icons.Default.Check,
                                                                contentDescription = "Selected",
                                                                tint = MaterialTheme.colorScheme.primary,
                                                                modifier = Modifier.size(18.dp)
                                                            )
                                                        }
                                                    }
                                                },
                                                onClick = {
                                                    selectedStoreForWhatIHave = store
                                                    if (allStores.size == 1) {
                                                        isConfirmed = true
                                                        viewModel.selectStore(store.id)
                                                    } else {
                                                        isConfirmed = false
                                                        viewModel.selectStore(null)
                                                    }
                                                    storeDropdownExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        if (allStores.size > 1 && !isConfirmed) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Text(
                                        text = if (isSwahili) 
                                            "Tafadhali thibitisha duka ulilochagua ili kupakia bei za vifaa." 
                                            else "Please confirm your selected store to load material prices.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        textAlign = TextAlign.Center,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    
                                    Button(
                                        onClick = {
                                            if (selectedStoreForWhatIHave != null) {
                                                isConfirmed = true
                                                viewModel.selectStore(selectedStoreForWhatIHave!!.id)
                                            }
                                        },
                                        enabled = selectedStoreForWhatIHave != null,
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(imageVector = Icons.Default.Check, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(text = if (isSwahili) "Sawa" else "Okay")
                                    }
                                }
                            }
                        }

                        AnimatedVisibility(
                            visible = isConfirmed && selectedStoreForWhatIHave != null && !isLoadingStoreMaterials,
                            enter = fadeIn(animationSpec = tween(1200)) + expandVertically(animationSpec = tween(1000)),
                            exit = fadeOut(animationSpec = tween(300)) + shrinkVertically(animationSpec = tween(300))
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                                if (!hasPrices) {
                                Card(
                                    shape = RoundedCornerShape(24.dp),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier.padding(24.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.AttachMoney,
                                            contentDescription = "Prices",
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(48.dp)
                                        )
                                        Spacer(modifier = Modifier.height(16.dp))
                                        Text(
                                            text = if (isSwahili) "Bei za Viungo Hazijawekwa" else "No Material Prices Entered",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 18.sp,
                                            color = MaterialTheme.colorScheme.error
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = if (isSwahili)
                                                "Duka hili linaloitwa '${selectedStoreForWhatIHave?.name}' halina bei yoyote ya viungo iliyohifadhiwa. Tafadhali nenda kwenye Bei kuweka bei zake kwanza."
                                                else "The store '${selectedStoreForWhatIHave?.name}' does not have any saved material prices yet. Please enter prices first to proceed.",
                                            textAlign = TextAlign.Center,
                                            fontSize = 14.sp,
                                            color = Color.Gray
                                        )
                                        Spacer(modifier = Modifier.height(24.dp))
                                        Button(
                                            onClick = { onNavigate("prices") },
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Text(if (isSwahili) "Weka Bei za Duka hili" else "Enter Store Prices Now")
                                        }
                                    }
                                }
                            } else {
                                // Header card
                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isDark) Color(0xFF1B251E) else Color(0xFFFAF6EE)
                                    ),
                                    shape = RoundedCornerShape(24.dp),
                                    border = BorderStroke(1.5.dp, if (isDark) Color(0xFF2C352E) else Color(0xFFE3DAC9)),
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Text(
                                            text = if (isSwahili) "Nyenzo Nilizonazo" else "What I Have (Raw Materials)",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 16.sp,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = if (isSwahili) 
                                                "Chagua viungo vilivyopo stoo yako na weka bei zake kwa kilo." 
                                                else "Select available ingredients in your storage.",
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                // Category 1: Energy
                                if (energyList.isNotEmpty()) {
                                    WhatIHaveSectionCard(
                                        title = if (isSwahili) "Vyanzo vya Nishati" else "Energy Sources",
                                        icon = Icons.Default.Bolt,
                                        color = Color(0xFFFFB300),
                                        items = energyList,
                                        viewModel = viewModel,
                                        isDark = isDark
                                    )
                                }

                                // Category 3: Minerals
                                if (mineralList.isNotEmpty()) {
                                    WhatIHaveSectionCard(
                                        title = if (isSwahili) "Madini (Minerals)" else "Minerals & Salts",
                                        icon = Icons.Default.Layers,
                                        color = Color(0xFF81D4FA),
                                        items = mineralList,
                                        viewModel = viewModel,
                                        isDark = isDark
                                    )
                                }
                            }
                        }
                    }
                    }

                    // Column 2
                    AnimatedVisibility(
                        visible = isConfirmed && selectedStoreForWhatIHave != null && hasPrices && !isLoadingStoreMaterials,
                        enter = fadeIn(animationSpec = tween(1200)) + expandVertically(animationSpec = tween(1000)),
                        exit = fadeOut(animationSpec = tween(300)) + shrinkVertically(animationSpec = tween(300)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // Category 2: Protein
                            if (proteinList.isNotEmpty()) {
                                WhatIHaveSectionCard(
                                    title = if (isSwahili) "Vyanzo vya Protini" else "Protein Sources",
                                    icon = Icons.Default.Eco,
                                    color = Color(0xFFEF9A9A),
                                    items = proteinList,
                                    viewModel = viewModel,
                                    isDark = isDark
                                )
                            }

                            // Category 4: Others
                            if (otherList.isNotEmpty()) {
                                WhatIHaveSectionCard(
                                    title = if (isSwahili) "Virutubisho vya Nyongeza" else "Inclusion Additives & Premixes",
                                    icon = Icons.Default.AddCircle,
                                    color = Color(0xFFA5D6A7),
                                    items = otherList,
                                    viewModel = viewModel,
                                    isDark = isDark
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Action button
                            val context = LocalContext.current
                            Button(
                                onClick = {
                                    if (isSelectionValid) {
                                        viewModel.runFormulation()
                                        onNavigate("formulation")
                                        Toast.makeText(
                                            context.applicationContext,
                                            if (isSwahili) "Viungo vilivyochaguliwa vimehifadhiwa! Tunaanza kuunda fomula..." else "Selected ingredients saved! Opening formulated recipe...",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    } else {
                                        showValidationErrorDialog = true
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .testTag("save_and_calculate_what_i_have_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary
                                ),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Save,
                                    contentDescription = if (isSwahili) "Hifadhi na Kokotoa" else "Save and Calculate",
                                    tint = Color.White
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isSwahili) "Hifadhi & Kokotoa Fomula" else "Save & Calculate Formula",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            } else {
                // Narrow Screen (Standard single view scroll list with accordions)
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Store Selection Card embedded at the top of LazyColumn
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.1f))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = if (isSwahili) "Duka la Bei Inayotumika" else "Selected Price Store",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Box {
                                    OutlinedButton(
                                        onClick = { storeDropdownExpanded = true },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            containerColor = if (isConfirmed && selectedStoreForWhatIHave != null) {
                                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)
                                            } else {
                                                Color.Transparent
                                            }
                                        ),
                                        border = BorderStroke(
                                            width = 1.5.dp,
                                            color = if (isConfirmed && selectedStoreForWhatIHave != null) {
                                                MaterialTheme.colorScheme.primary
                                            } else {
                                                MaterialTheme.colorScheme.outline
                                            }
                                        ),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Text(
                                                    text = selectedStoreForWhatIHave?.name ?: "", // blank when page opens
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isConfirmed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                                    fontSize = 14.sp
                                                )
                                                if (isConfirmed && selectedStoreForWhatIHave != null) {
                                                    Icon(
                                                        imageVector = Icons.Default.CheckCircle,
                                                        contentDescription = "Confirmed Store",
                                                        tint = MaterialTheme.colorScheme.primary,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }
                                            }
                                            Icon(
                                                imageVector = Icons.Default.ArrowDropDown,
                                                contentDescription = "Dropdown",
                                                tint = if (isConfirmed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    DropdownMenu(
                                        expanded = storeDropdownExpanded,
                                        onDismissRequest = { storeDropdownExpanded = false },
                                        modifier = Modifier.fillMaxWidth(0.9f)
                                    ) {
                                        allStores.forEach { store ->
                                            DropdownMenuItem(
                                                text = {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = store.name,
                                                            fontWeight = if (selectedStoreForWhatIHave?.id == store.id) FontWeight.Bold else FontWeight.Normal
                                                        )
                                                        if (selectedStoreForWhatIHave?.id == store.id) {
                                                            Icon(
                                                                imageVector = Icons.Default.Check,
                                                                contentDescription = "Selected",
                                                                tint = MaterialTheme.colorScheme.primary,
                                                                modifier = Modifier.size(18.dp)
                                                            )
                                                        }
                                                    }
                                                },
                                                onClick = {
                                                    selectedStoreForWhatIHave = store
                                                    if (allStores.size == 1) {
                                                        isConfirmed = true
                                                        viewModel.selectStore(store.id)
                                                    } else {
                                                        isConfirmed = false
                                                        viewModel.selectStore(null)
                                                    }
                                                    storeDropdownExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (allStores.size > 1 && !isConfirmed) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Text(
                                        text = if (isSwahili) 
                                            "Tafadhali thibitisha duka ulilochagua ili kupakia bei za vifaa." 
                                            else "Please confirm your selected store to load material prices.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        textAlign = TextAlign.Center,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    
                                    Button(
                                        onClick = {
                                            if (selectedStoreForWhatIHave != null) {
                                                isConfirmed = true
                                                viewModel.selectStore(selectedStoreForWhatIHave!!.id)
                                            }
                                        },
                                        enabled = selectedStoreForWhatIHave != null,
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(imageVector = Icons.Default.Check, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(text = if (isSwahili) "Sawa" else "Okay")
                                    }
                                }
                            }
                        }
                    }

                    val isMobileVisible = isConfirmed && selectedStoreForWhatIHave != null && !isLoadingStoreMaterials
                    if (isMobileVisible) {
                        item {
                            AnimatedVisibility(
                                visible = isMobileVisible,
                                enter = fadeIn(animationSpec = tween(800)),
                                exit = fadeOut(animationSpec = tween(300))
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                                    if (!hasPrices) {
                                        Card(
                                            shape = RoundedCornerShape(24.dp),
                                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(
                                                modifier = Modifier.padding(24.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.AttachMoney,
                                                    contentDescription = "Prices",
                                                    tint = MaterialTheme.colorScheme.error,
                                                    modifier = Modifier.size(48.dp)
                                                )
                                                Spacer(modifier = Modifier.height(16.dp))
                                                Text(
                                                    text = if (isSwahili) "Bei za Viungo Hazijawekwa" else "No Material Prices Entered",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 18.sp,
                                                    color = MaterialTheme.colorScheme.error
                                                )
                                                Spacer(modifier = Modifier.height(8.dp))
                                                Text(
                                                    text = if (isSwahili)
                                                        "Duka hili linaloitwa '${selectedStoreForWhatIHave?.name}' halina bei yoyote ya viungo iliyohifadhiwa. Tafadhali nenda kwenye Bei kuweka bei zake kwanza."
                                                        else "The store '${selectedStoreForWhatIHave?.name}' does not have any saved material prices yet. Please enter prices first to proceed.",
                                                    textAlign = TextAlign.Center,
                                                    fontSize = 14.sp,
                                                    color = Color.Gray
                                                )
                                                Spacer(modifier = Modifier.height(24.dp))
                                                Button(
                                                    onClick = { onNavigate("prices") },
                                                    shape = RoundedCornerShape(12.dp)
                                                ) {
                                                    Text(if (isSwahili) "Weka Bei za Duka hili" else "Enter Store Prices Now")
                                                }
                                            }
                                        }
                                    } else {
                                        Card(
                                            colors = CardDefaults.cardColors(
                                                containerColor = if (isDark) Color(0xFF1B251E) else Color(0xFFFAF6EE)
                                            ),
                                            shape = RoundedCornerShape(24.dp),
                                            border = BorderStroke(1.dp, if (isDark) Color(0xFF2C352E) else Color(0xFFE3DAC9)),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(modifier = Modifier.padding(16.dp)) {
                                                Text(
                                                    text = if (isSwahili) "Nyenzo Nilizonazo" else "What I Have (Raw Materials)",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 18.sp,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                                Spacer(modifier = Modifier.height(6.dp))
                                                Text(
                                                    text = if (isSwahili) 
                                                        "Gusa kikundi kufungua viungo vyake kisha chagua vilivyopo stoo na weka bei zake." 
                                                        else "Tap on a group to view ingredients, then select available ones.",
                                                    fontSize = 13.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }

                                        // 1. Energy Sources Card
                                        if (energyList.isNotEmpty()) {
                                            IngredientCategoryAccordionHeader(
                                                title = if (isSwahili) "Vyanzo vya Nishati" else "Energy Sources",
                                                icon = Icons.Default.Bolt,
                                                color = Color(0xFFFFB300),
                                                isExpanded = expandedCategory == "energy",
                                                onClick = {
                                                    expandedCategory = if (expandedCategory == "energy") null else "energy"
                                                }
                                            )
                                            if (expandedCategory == "energy") {
                                                Column(
                                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                                    modifier = Modifier.padding(vertical = 4.dp)
                                                ) {
                                                    energyList.forEach { ing ->
                                                        IngredientCheckItem(ing, viewModel)
                                                    }
                                                }
                                            }
                                        }

                                        // 2. Protein Sources Card
                                        if (proteinList.isNotEmpty()) {
                                            IngredientCategoryAccordionHeader(
                                                title = if (isSwahili) "Vyanzo vya Protini" else "Protein Sources",
                                                icon = Icons.Default.Eco,
                                                color = Color(0xFFEF9A9A),
                                                isExpanded = expandedCategory == "protein",
                                                onClick = {
                                                    expandedCategory = if (expandedCategory == "protein") null else "protein"
                                                }
                                            )
                                            if (expandedCategory == "protein") {
                                                Column(
                                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                                    modifier = Modifier.padding(vertical = 4.dp)
                                                ) {
                                                    proteinList.forEach { ing ->
                                                        IngredientCheckItem(ing, viewModel)
                                                    }
                                                }
                                            }
                                        }

                                        // 3. Minerals Card
                                        if (mineralList.isNotEmpty()) {
                                            IngredientCategoryAccordionHeader(
                                                title = if (isSwahili) "Madini" else "Minerals",
                                                icon = Icons.Default.Layers,
                                                color = Color(0xFF81D4FA),
                                                isExpanded = expandedCategory == "mineral",
                                                onClick = {
                                                    expandedCategory = if (expandedCategory == "mineral") null else "mineral"
                                                }
                                            )
                                            if (expandedCategory == "mineral") {
                                                Column(
                                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                                    modifier = Modifier.padding(vertical = 4.dp)
                                                ) {
                                                    mineralList.forEach { ing ->
                                                        IngredientCheckItem(ing, viewModel)
                                                    }
                                                }
                                            }
                                        }

                                        // 4. Other Additives
                                        if (otherList.isNotEmpty()) {
                                            IngredientCategoryAccordionHeader(
                                                title = if (isSwahili) "Virutubisho vya Nyongeza" else "Inclusion Additives & Premixes",
                                                icon = Icons.Default.AddCircle,
                                                color = Color(0xFFA5D6A7),
                                                isExpanded = expandedCategory == "other",
                                                onClick = {
                                                    expandedCategory = if (expandedCategory == "other") null else "other"
                                                }
                                            )
                                            if (expandedCategory == "other") {
                                                Column(
                                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                                    modifier = Modifier.padding(vertical = 4.dp)
                                                ) {
                                                    otherList.forEach { ing ->
                                                        IngredientCheckItem(ing, viewModel)
                                                    }
                                                }
                                            }
                                        }

                                        val context = LocalContext.current
                                        Button(
                                            onClick = {
                                                if (isSelectionValid) {
                                                    viewModel.runFormulation()
                                                    onNavigate("formulation")
                                                    Toast.makeText(
                                                        context.applicationContext,
                                                        if (isSwahili) "Viungo vilivyochaguliwa vimehifadhiwa! Tunaanza kuunda fomula..." else "Selected ingredients saved! Opening formulated recipe...",
                                                        Toast.LENGTH_SHORT
                                                    ).show()
                                                } else {
                                                    showValidationErrorDialog = true
                                                }
                                            },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(52.dp)
                                                .padding(vertical = 4.dp)
                                                .testTag("save_and_calculate_what_i_have_button"),
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = MaterialTheme.colorScheme.primary
                                            ),
                                            shape = RoundedCornerShape(16.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Save,
                                                contentDescription = if (isSwahili) "Hifadhi na Kokotoa" else "Save and Calculate",
                                                tint = Color.White
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = if (isSwahili) "Hifadhi & Kokotoa Fomula" else "Save & Calculate Formula",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp,
                                                color = Color.White
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showValidationErrorDialog) {
        val missing = mutableListOf<String>()
        if (!isEnergySelected) {
            missing.add(if (isSwahili) "Chanzo cha Nishati" else "Energy Source")
        }
        if (!isProteinSelected) {
            missing.add(if (isSwahili) "Chanzo cha Protini" else "Protein Source")
        }
        if (!isMineralSelected) {
            missing.add(if (isSwahili) "Madini" else "Mineral")
        }

        AlertDialog(
            onDismissRequest = { showValidationErrorDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Warning",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isSwahili) "Mchanganyiko Muhimu Unahitajika" else "Essential Selection Required",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            text = {
                Column {
                    Text(
                        text = if (isSwahili)
                            "Ili kuunda mchanganyiko mzuri wenye uwiano kamili, ni lazima uchague angalau kiungo kimoja kutoka makundi haya yafuatayo:\n\n• ${missing.joinToString("\n• ")}"
                            else "To formulate a well-balanced recipe, you must select at least one raw ingredient from each of the following missing essential categories:\n\n• ${missing.joinToString("\n• ")}",
                        fontSize = 14.sp,
                        lineHeight = 20.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showValidationErrorDialog = false }) {
                    Text(if (isSwahili) "Sawa, Nitachagua" else "OK, I will Select")
                }
            },
            shape = RoundedCornerShape(20.dp)
        )

        if (isLoadingStoreMaterials) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background.copy(alpha = 0.95f))
                    .clickable(enabled = false) {}, // prevent clicks on elements behind
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .padding(16.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        // High quality animated-looking loading icon/progress
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.size(100.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(80.dp),
                                color = MaterialTheme.colorScheme.primary,
                                strokeWidth = 6.dp,
                                trackColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                            )
                            Icon(
                                imageVector = Icons.Default.Science,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                        
                        Spacer(modifier = Modifier.height(24.dp))
                        
                        Text(
                            text = if (isSwahili) "Tafadhali Subiri..." else "Please Wait...",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        
                        Spacer(modifier = Modifier.height(12.dp))
                        
                        Text(
                            text = loadingMessage,
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.height(48.dp) // Fixed height to avoid UI jumping with text length changes
                        )
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        LinearProgressIndicator(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp)),
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun IngredientCategoryAccordionHeader(
    title: String,
    icon: ImageVector,
    color: Color,
    isExpanded: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("accordion_header_${title.replace(" ", "_").lowercase()}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isExpanded) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.12f)
                             else MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(
            width = if (isExpanded) 1.5.dp else 1.dp,
            color = if (isExpanded) MaterialTheme.colorScheme.primary 
                    else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = color,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Icon(
                imageVector = if (isExpanded) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                contentDescription = if (isExpanded) "Collapse" else "Expand",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
fun IngredientGroupHeader(title: String, icon: ImageVector, color: Color) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 4.dp, horizontal = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(color.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = title, tint = color, modifier = Modifier.size(18.dp))
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onBackground
        )
    }
}

@Composable
fun IngredientCheckItem(
    ing: Ingredient, 
    viewModel: PoultryViewModel
) {
    val isSwahili = viewModel.isSwahili.value
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable {
                viewModel.toggleIngredientSelection(ing)
            },
        colors = CardDefaults.cardColors(
            containerColor = if (ing.isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f) 
                             else MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(
            width = if (ing.isSelected) 1.5.dp else 1.dp,
            color = if (ing.isSelected) MaterialTheme.colorScheme.primary 
                    else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = formatIngredientName(ing.name, isSwahili),
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
            )
            
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (ing.pricePerKg > 0.0) {
                    Text(
                        text = "${String.format("%,.0f", ing.pricePerKg)} TSh",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                
                AnimatedVisibility(
                    visible = ing.isSelected,
                    enter = scaleIn(
                        initialScale = 0.4f,
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioMediumBouncy,
                            stiffness = Spring.StiffnessLow
                        )
                    ) + fadeIn(),
                    exit = scaleOut(targetScale = 0.4f) + fadeOut()
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .padding(4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .background(
                                    color = Color(0xFF2E7D32), // Premium dark green success tick
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Selected",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- 3b. Responsive Formulation Screen (Widescreen Tablet Grid) ---
@Composable
fun ResponsiveFormulationScreen(
    viewModel: PoultryViewModel,
    onNavigate: (String) -> Unit,
    isSwahili: Boolean
) {
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWide = maxWidth > 650.dp
        
        if (isWide) {
            val birdType by viewModel.selectedBirdType.collectAsStateWithLifecycle()
            val ageWeeks by viewModel.selectedAgeWeeks.collectAsStateWithLifecycle()
            val batchWeightVal by viewModel.batchWeight.collectAsStateWithLifecycle()
            val customBatchWeightText by viewModel.customBatchWeightText.collectAsStateWithLifecycle()
            val flockSize by viewModel.birdCount.collectAsStateWithLifecycle()

            val currentTargetVal by viewModel.currentTarget.collectAsStateWithLifecycle()
            val rawIngredientsList by viewModel.ingredients.collectAsStateWithLifecycle()
            val formulationResult by viewModel.solverResult.collectAsStateWithLifecycle()
            
            val context = LocalContext.current
            var saveDialogOpened by remember { mutableStateOf(false) }
            var saveTitle by remember { mutableStateOf("") }

            LaunchedEffect(rawIngredientsList) {
                viewModel.runFormulation()
            }

            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Column 1: Interactive Core Input Console (Batch weight & Pocket Budget & AI chatbot)
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Batch Weight scale selector Card
                    Card(
                        shape = RoundedCornerShape(24.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = if (isSwahili) "Uzito wa Malisho unayotaka (Kg)" else "Target Batch Weight (Kg)",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf(50.0, 70.0, 100.0).forEach { wt ->
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(
                                                if (batchWeightVal == wt) MaterialTheme.colorScheme.secondary
                                                else MaterialTheme.colorScheme.surfaceVariant
                                            )
                                            .clickable { 
                                                viewModel.batchWeight.value = wt
                                                viewModel.customBatchWeightText.value = wt.toInt().toString()
                                                viewModel.runFormulation()
                                            }
                                            .padding(vertical = 10.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "${wt.toInt()} Kg",
                                            color = if (batchWeightVal == wt) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedTextField(
                                    value = customBatchWeightText,
                                    onValueChange = {
                                        viewModel.customBatchWeightText.value = it
                                        val parsed = it.toDoubleOrNull()
                                        if (parsed != null && parsed > 0.0) {
                                            viewModel.batchWeight.value = parsed
                                            viewModel.runFormulation()
                                        }
                                    },
                                    label = { Text(if (isSwahili) "Uzito wa Hiari (Kg)" else "Custom Weight (Kg)") },
                                    modifier = Modifier.weight(1f).testTag("custom_weight_input_wide"),
                                    shape = RoundedCornerShape(12.dp),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                                )

                                OutlinedTextField(
                                    value = if (flockSize == 0) "" else flockSize.toString(),
                                    onValueChange = {
                                        viewModel.birdCount.value = it.toIntOrNull() ?: 0
                                    },
                                    label = { Text(if (isSwahili) "Idadi ya Kuku" else "Flock Number") },
                                    modifier = Modifier.weight(1f).testTag("flock_birds_input_wide"),
                                    shape = RoundedCornerShape(12.dp),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                                )
                            }
                        }
                    }

                    // Discuss with AI Advisor Option Card
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f)
                        ),
                        shape = RoundedCornerShape(24.dp),
                        border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Psychology,
                                        contentDescription = "AI Advisor",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = if (isSwahili) "Mshauri wa AI" else "Consult AI Feed Advisor",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (isSwahili)
                                    "Changanua fomula hii ukitumia AI: Uliza maswali ya ziada au jinsi ya kulisha kundi lako kwa ufanisi mkubwa."
                                    else "Analyze this precise recipe with AI: Ask questions, get advice on substitute raw materials, or request custom feeding instructions.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 15.sp
                            )
                            Spacer(modifier = Modifier.height(14.dp))

                            Button(
                                onClick = { onNavigate("ai_advisor") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(44.dp)
                                    .testTag("discuss_with_ai_advisor_btn_wide"),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = "Chat", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isSwahili) "Zungumza na Mshauri wa AI sasa" else "Discuss Formula with AI Chat",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }

                    // Pocket Budget Formula card (Part 4)
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.15f)
                        ),
                        shape = RoundedCornerShape(24.dp),
                        border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(MaterialTheme.colorScheme.tertiary.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.MonetizationOn,
                                        contentDescription = "Custom Budget Formula",
                                        tint = MaterialTheme.colorScheme.tertiary,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = if (isSwahili) "Fomula ya Bajeti Maalum" else "Custom Formula with Available Budget",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.tertiary
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (isSwahili)
                                    "Buni fomula inayolenga kiasi chako maalum cha bajeti. Rekebisha vipimo ili viendane na uwezo wako."
                                    else "Find a customized feed recipe adapted perfectly to fit your actual available pocket budget. Scale and alter proportions dynamically.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 15.sp
                            )
                            Spacer(modifier = Modifier.height(14.dp))

                            Button(
                                onClick = { onNavigate("budget_formula") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(44.dp)
                                    .testTag("custom_budget_formula_btn_wide"),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.MonetizationOn, contentDescription = "Budget", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isSwahili) "Tengeneza Fomula kwa Bajeti Yako" else "Calculate with Available Budget",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }

                // Column 2: Formulation Mixture Results & Advanced Data Visualizations
                Column(
                    modifier = Modifier
                        .weight(1.3f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    formulationResult?.let { result ->
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (result.errorMessage != null) 
                                    MaterialTheme.colorScheme.surfaceVariant
                                    else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                            ),
                            shape = RoundedCornerShape(24.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = if (isSwahili) "Mchanganyiko wa Chakula Chako" else "Your Formulated Feed Mixture",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                
                                result.errorMessage?.let { msg ->
                                    Surface(
                                        color = MaterialTheme.colorScheme.errorContainer,
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                                    ) {
                                        Text(
                                            text = msg,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onErrorContainer,
                                            modifier = Modifier.padding(10.dp)
                                        )
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(if (isSwahili) "Gharama kwa Kilo" else "Cost/Kg Feed", fontSize = 12.sp)
                                        Text(
                                            text = "${String.format("%.2f", result.costPerKg)}",
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 18.sp,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    Column {
                                        Text(if (isSwahili) "Gharama ya Mfuko" else "Total Batch Cost", fontSize = 12.sp)
                                        Text(
                                            text = "${String.format("%.2f", result.totalCost)}",
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 18.sp,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = if (isSwahili) "Mchanganyiko wa Viungo (Mchanganyiko wa Kilo ${batchWeightVal.toInt()}):" 
                                           else "Recipe formulation mix weights (for ${batchWeightVal.toInt()} Kg batch):", 
                                    fontWeight = FontWeight.Bold, 
                                    fontSize = 14.sp
                                )
                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (isSwahili) "Nyenzo" else "Raw Material",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.weight(1.2f)
                                    )
                                    Text(
                                        text = if (isSwahili) "% Inahitajika" else "% Needed",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.weight(0.9f),
                                        textAlign = TextAlign.Center
                                    )
                                    Text(
                                        text = if (isSwahili) "Uzito (Kg)" else "Weight (Kg)",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.primary,
                                        textAlign = TextAlign.End,
                                        modifier = Modifier.weight(0.9f)
                                    )
                                    Text(
                                        text = if (isSwahili) "Gharama" else "Cost (TSh)",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.primary,
                                        textAlign = TextAlign.End,
                                        modifier = Modifier.weight(1.0f)
                                    )
                                }
                                
                                HorizontalDivider(color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                                Spacer(modifier = Modifier.height(4.dp))

                                result.ingredientPercentages.forEach { (name, percent) ->
                                    if (percent > 0.0) {
                                        val weightKg = result.ingredientWeightsKg[name] ?: 0.0
                                        val matchingIng = rawIngredientsList.find { it.name.trim().lowercase() == name.trim().lowercase() }
                                        val pricePerKg = matchingIng?.pricePerKg ?: 0.0
                                        val itemCost = weightKg * pricePerKg

                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 8.dp, vertical = 5.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = name,
                                                fontWeight = FontWeight.Medium,
                                                fontSize = 12.sp,
                                                modifier = Modifier.weight(1.2f)
                                            )
                                            Text(
                                                text = String.format(Locale.US, "%.2f %%", percent),
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.weight(0.9f),
                                                textAlign = TextAlign.Center
                                            )
                                            Text(
                                                text = String.format(Locale.US, "%.2f Kg", weightKg),
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.primary,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.weight(0.9f),
                                                textAlign = TextAlign.End
                                            )
                                            Text(
                                                text = if (itemCost > 0.0) String.format(Locale.US, "%,.0f TSh", itemCost) else "0 TSh",
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.primary,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.weight(1.0f),
                                                textAlign = TextAlign.End
                                            )
                                        }
                                        HorizontalDivider(color = Color.LightGray.copy(alpha = 0.15f))
                                    }
                                }

                                var totalPercent = 0.0
                                var totalWeight = 0.0
                                var cumulativeCost = 0.0
                                result.ingredientPercentages.forEach { (name, percent) ->
                                    if (percent > 0.0) {
                                        totalPercent += percent
                                        val weightKg = result.ingredientWeightsKg[name] ?: 0.0
                                        totalWeight += weightKg
                                        val matchingIng = rawIngredientsList.find { it.name.trim().lowercase() == name.trim().lowercase() }
                                        val pricePerKg = matchingIng?.pricePerKg ?: 0.0
                                        cumulativeCost += weightKg * pricePerKg
                                    }
                                }

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f))
                                        .padding(horizontal = 8.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (isSwahili) "JUMLA" else "TOTAL",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.weight(1.2f)
                                    )
                                    Text(
                                        text = String.format(Locale.US, "%.1f %%", totalPercent),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.weight(0.9f),
                                        textAlign = TextAlign.Center
                                    )
                                    Text(
                                        text = String.format(Locale.US, "%.1f Kg", totalWeight),
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.ExtraBold,
                                        modifier = Modifier.weight(0.9f),
                                        textAlign = TextAlign.End
                                    )
                                    Text(
                                        text = if (cumulativeCost > 0.0) String.format(Locale.US, "%,.0f TSh", cumulativeCost) else "0 TSh",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.ExtraBold,
                                        modifier = Modifier.weight(1.0f),
                                        textAlign = TextAlign.End
                                    )
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                val stats = viewModel.getStandardNutritionInfo(birdType, ageWeeks)
                                FlockFeedingDurationCard(
                                    birdType = currentTargetVal?.birdType ?: birdType,
                                    stageName = currentTargetVal?.stageName ?: "Diet Stage",
                                    ageWeeks = ageWeeks,
                                    flockSize = flockSize,
                                    batchWeight = batchWeightVal,
                                    dailyIntakeGrams = stats.dailyFeedInTakeGrams,
                                    isSwahili = isSwahili
                                )

                                Spacer(modifier = Modifier.height(20.dp))
                                Text(
                                    text = if (isSwahili) "3. Kiwango cha Kulenga Virutubisho" else "3. Standard Nutrient Target Benchmarks:",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Spacer(modifier = Modifier.height(8.dp))

                                currentTargetVal?.let { tgt ->
                                    NutrientTargetTable(tgt, result, isSwahili)
                                    Spacer(modifier = Modifier.height(8.dp))
                                    NutrientCompensationRecommendations(tgt, result, rawIngredientsList, isSwahili)
                                }

                                Spacer(modifier = Modifier.height(20.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Button(
                                        onClick = { 
                                            saveTitle = "My ${currentTargetVal?.birdType} ${currentTargetVal?.stageName} Feed"
                                            saveDialogOpened = true 
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Default.Save, contentDescription = "Save", modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(if (isSwahili) "Hifadhi" else "Save", fontSize = 12.sp)
                                    }

                                    Button(
                                        onClick = {
                                            currentTargetVal?.let { tgt ->
                                                PdfGenerator.generateAndShareReport(
                                                    context = context,
                                                    birdType = birdType,
                                                    stageName = tgt.stageName,
                                                    ageWeeks = ageWeeks,
                                                    batchWeight = batchWeightVal,
                                                    result = result,
                                                    target = tgt,
                                                    isSwahili = isSwahili
                                                )
                                            }
                                        },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Default.Download, contentDescription = "PDF", modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("PDF Report", fontSize = 12.sp)
                                    }

                                    IconButton(
                                        onClick = {
                                            val shareIngredients = result.ingredientPercentages.map { Pair(it.key, it.value) }
                                            shareFormulaImage(
                                                context = context,
                                                title = "My ${currentTargetVal?.birdType} ${currentTargetVal?.stageName} Feed",
                                                birdType = currentTargetVal?.birdType ?: "Poultry",
                                                stageName = currentTargetVal?.stageName ?: "Feed",
                                                batchWeight = batchWeightVal,
                                                totalCost = result.totalCost,
                                                ingredients = shareIngredients,
                                                unitPrice = result.costPerKg,
                                                isSwahili = isSwahili
                                            )
                                        },
                                        modifier = Modifier
                                            .background(MaterialTheme.colorScheme.tertiary.copy(alpha = 0.12f), RoundedCornerShape(8.dp))
                                            .size(40.dp)
                                            .testTag("share_image_direct_btn_wide")
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = "Share Image", tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(20.dp))
                                    }
                                }
                            }
                        }
                    } ?: run {
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(top = 40.dp),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Bolt,
                                    contentDescription = "Ready",
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = if (isSwahili) "Fomula iko Tayari" else "Ready to Formulate",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = if (isSwahili) "Chagua nyenzo zako na urekebishe uzito ili kuanza kukokotoa." else "Select your storage ingredients or adjust the console on the left to recalculate your recipe.",
                                    fontSize = 12.sp,
                                    textAlign = TextAlign.Center,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            // Save dialog trigger for tablet view
            if (saveDialogOpened) {
                val focusRequester = remember { FocusRequester() }
                val keyboardController = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current
                LaunchedEffect(Unit) {
                    kotlinx.coroutines.delay(150)
                    focusRequester.requestFocus()
                }
                Dialog(onDismissRequest = { saveDialogOpened = false }) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = if (isSwahili) "Hifadhi Fomula hii" else "Save Recipe",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            OutlinedTextField(
                                value = saveTitle,
                                onValueChange = { saveTitle = it },
                                label = { Text("Recipe Title") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .focusRequester(focusRequester)
                                    .testTag("save_title_input_wide")
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(onClick = { saveDialogOpened = false }) {
                                    Text(if (isSwahili) "Ghairi" else "Cancel")
                                }
                                Button(
                                    onClick = {
                                        if (saveTitle.isNotBlank()) {
                                            viewModel.saveCurrentFormulation(saveTitle)
                                            saveDialogOpened = false
                                            Toast.makeText(context.applicationContext, if (isSwahili) "Fomula Imehifadhiwa!" else "Recipe Saved Successfully!", Toast.LENGTH_SHORT).show()
                                            onNavigate("saved")
                                        }
                                    },
                                    enabled = saveTitle.isNotBlank(),
                                    modifier = Modifier.testTag("save_recipe_confirm_btn_wide")
                                ) {
                                    Text(if (isSwahili) "Hifadhi" else "Save")
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Narrow Screen layout console
            FormulationScreen(
                viewModel = viewModel,
                onNavigate = onNavigate,
                isSwahili = isSwahili
            )
        }
    }
}

// --- 3. Formulation Screen ---
@Composable
fun FormulationScreen(
    viewModel: PoultryViewModel,
    onNavigate: (String) -> Unit,
    isSwahili: Boolean
) {
    val birdType by viewModel.selectedBirdType.collectAsStateWithLifecycle()
    val ageWeeks by viewModel.selectedAgeWeeks.collectAsStateWithLifecycle()
    val batchWeightVal by viewModel.batchWeight.collectAsStateWithLifecycle()
    val customBatchWeightText by viewModel.customBatchWeightText.collectAsStateWithLifecycle()
    val flockSize by viewModel.birdCount.collectAsStateWithLifecycle()

    val currentTargetVal by viewModel.currentTarget.collectAsStateWithLifecycle()
    val rawIngredientsList by viewModel.ingredients.collectAsStateWithLifecycle()
    val formulationResult by viewModel.solverResult.collectAsStateWithLifecycle()
    val isCustomizing by viewModel.isCustomizingRecipe.collectAsStateWithLifecycle()
    val customizedRecipe by viewModel.customizedRecipeText.collectAsStateWithLifecycle()
    
    val context = LocalContext.current
    var saveDialogOpened by remember { mutableStateOf(false) }
    var saveTitle by remember { mutableStateOf("") }

    // Auto-run formulation on screen enter or whenever ingredients list change
    LaunchedEffect(rawIngredientsList) {
        viewModel.runFormulation()
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {

        // Batch Weight scale Selector
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isSwahili) "Uzito wa Malisho unayotaka (Kg)" else "Target Batch Weight (Kg)",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(50.0, 70.0, 100.0).forEach { wt ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        if (batchWeightVal == wt) MaterialTheme.colorScheme.secondary
                                        else MaterialTheme.colorScheme.surfaceVariant
                                    )
                                    .clickable { 
                                        viewModel.batchWeight.value = wt
                                        viewModel.customBatchWeightText.value = wt.toInt().toString()
                                        viewModel.runFormulation() // auto recalculate
                                    }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${wt.toInt()} Kg",
                                    color = if (batchWeightVal == wt) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Custom Weight entry
                        OutlinedTextField(
                            value = customBatchWeightText,
                            onValueChange = {
                                viewModel.customBatchWeightText.value = it
                                val parsed = it.toDoubleOrNull()
                                if (parsed != null && parsed > 0.0) {
                                    viewModel.batchWeight.value = parsed
                                    viewModel.runFormulation() // auto recalculate
                                }
                            },
                            label = { Text(if (isSwahili) "Uzito wa Hiari (Kg)" else "Custom Weight (Kg)") },
                            modifier = Modifier.weight(1f).testTag("custom_weight_input"),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )

                        // Flock Size entry
                        OutlinedTextField(
                            value = if (flockSize == 0) "" else flockSize.toString(),
                            onValueChange = {
                                viewModel.birdCount.value = it.toIntOrNull() ?: 0
                            },
                            label = { Text(if (isSwahili) "Idadi ya Kuku" else "Flock Number") },
                            modifier = Modifier.weight(1f).testTag("flock_birds_input"),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                    }
                }
            }
        }

        // Results Card (Dynamic)
        formulationResult?.let { result ->
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (result.errorMessage != null) 
                            MaterialTheme.colorScheme.surfaceVariant
                            else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                    ),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (isSwahili) "Mchanganyiko wa Chakula Chako" else "Your Formulated Feed Mixture",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        // Error/Advisory messages
                        result.errorMessage?.let { msg ->
                            Surface(
                                color = MaterialTheme.colorScheme.errorContainer,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                            ) {
                                Text(
                                    text = msg,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                        }

                        // Price summary metrics
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(if (isSwahili) "Gharama kwa Kilo" else "Cost/Kg Feed", fontSize = 12.sp)
                                Text(
                                    text = "${String.format("%.2f", result.costPerKg)}",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 18.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Column {
                                Text(if (isSwahili) "Gharama ya Mfuko" else "Total Batch Cost", fontSize = 12.sp)
                                Text(
                                    text = "${String.format("%.2f", result.totalCost)}",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 18.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = if (isSwahili) "Mchanganyiko wa Viungo (Mchanganyiko wa Kilo ${batchWeightVal.toInt()}):" 
                                   else "Recipe formulation mix weights (for ${batchWeightVal.toInt()} Kg batch):", 
                            fontWeight = FontWeight.Bold, 
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        // Beautiful Table Header
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isSwahili) "Nyenzo (Material)" else "Raw Material",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.weight(1.2f)
                            )
                            Text(
                                text = if (isSwahili) "% Inayohitajika" else "% Needed",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.weight(0.9f),
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = if (isSwahili) "Uzito (Kg)" else "Weight (Kg)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.primary,
                                textAlign = TextAlign.End,
                                modifier = Modifier.weight(0.9f)
                            )
                            Text(
                                text = if (isSwahili) "Gharama" else "Cost (TSh)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.primary,
                                textAlign = TextAlign.End,
                                modifier = Modifier.weight(1.0f)
                            )
                        }
                        
                        HorizontalDivider(color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                        Spacer(modifier = Modifier.height(4.dp))

                        // Ingredients mix ledger rows
                        result.ingredientPercentages.forEach { (name, percent) ->
                            if (percent > 0.0) {
                                val weightKg = result.ingredientWeightsKg[name] ?: 0.0
                                val matchingIng = rawIngredientsList.find { it.name.trim().lowercase() == name.trim().lowercase() }
                                val pricePerKg = matchingIng?.pricePerKg ?: 0.0
                                val itemCost = weightKg * pricePerKg

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 5.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = name,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 12.sp,
                                        modifier = Modifier.weight(1.2f)
                                    )
                                    Text(
                                        text = String.format(Locale.US, "%.2f %%", percent),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.weight(0.9f),
                                        textAlign = TextAlign.Center
                                    )
                                    Text(
                                        text = String.format(Locale.US, "%.2f Kg", weightKg),
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.weight(0.9f),
                                        textAlign = TextAlign.End
                                    )
                                    Text(
                                        text = if (itemCost > 0.0) String.format(Locale.US, "%,.0f TSh", itemCost) else "0 TSh",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.weight(1.0f),
                                        textAlign = TextAlign.End
                                    )
                                }
                                HorizontalDivider(color = Color.LightGray.copy(alpha = 0.15f))
                            }
                        }

                        // Sum the percentages & weights & cost for Total Row
                        var totalPercent = 0.0
                        var totalWeight = 0.0
                        var cumulativeCost = 0.0
                        result.ingredientPercentages.forEach { (name, percent) ->
                            if (percent > 0.0) {
                                totalPercent += percent
                                val weightKg = result.ingredientWeightsKg[name] ?: 0.0
                                totalWeight += weightKg
                                val matchingIng = rawIngredientsList.find { it.name.trim().lowercase() == name.trim().lowercase() }
                                val pricePerKg = matchingIng?.pricePerKg ?: 0.0
                                cumulativeCost += weightKg * pricePerKg
                            }
                        }

                        // Add the Total Row below the ingredient column
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f))
                                .padding(horizontal = 8.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isSwahili) "JUMLA (Total)" else "TOTAL",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.weight(1.2f)
                            )
                            Text(
                                text = String.format(Locale.US, "%.1f %%", totalPercent),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.weight(0.9f),
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = String.format(Locale.US, "%.1f Kg", totalWeight),
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.weight(0.9f),
                                textAlign = TextAlign.End
                            )
                            Text(
                                text = if (cumulativeCost > 0.0) String.format(Locale.US, "%,.0f TSh", cumulativeCost) else "0 TSh",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.weight(1.0f),
                                textAlign = TextAlign.End
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Flock feed duration and intake summary guide
                        val stats = viewModel.getStandardNutritionInfo(birdType, ageWeeks)
                        FlockFeedingDurationCard(
                            birdType = currentTargetVal?.birdType ?: birdType,
                            stageName = currentTargetVal?.stageName ?: "Diet Stage",
                            ageWeeks = ageWeeks,
                            flockSize = flockSize,
                            batchWeight = batchWeightVal,
                            dailyIntakeGrams = stats.dailyFeedInTakeGrams,
                            isSwahili = isSwahili
                        )

                        // Standard Target Benchmarks representation
                        Spacer(modifier = Modifier.height(20.dp))
                        Text(
                            text = if (isSwahili) "3. Kiwango cha Kulenga Virutubisho (Nutrient Targets)" else "3. Standard Nutrient Target Benchmarks:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        currentTargetVal?.let { tgt ->
                            NutrientTargetTable(tgt, result, isSwahili)
                            Spacer(modifier = Modifier.height(8.dp))
                            NutrientCompensationRecommendations(tgt, result, rawIngredientsList, isSwahili)
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // Action Buttons for Results
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = { 
                                    saveTitle = "My ${currentTargetVal?.birdType} ${currentTargetVal?.stageName} Feed"
                                    saveDialogOpened = true 
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Save, contentDescription = "Save", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (isSwahili) "Hifadhi" else "Save", fontSize = 12.sp)
                            }

                            Button(
                                onClick = {
                                    currentTargetVal?.let { tgt ->
                                        PdfGenerator.generateAndShareReport(
                                            context = context,
                                            birdType = birdType,
                                            stageName = tgt.stageName,
                                            ageWeeks = ageWeeks,
                                            batchWeight = batchWeightVal,
                                            result = result,
                                            target = tgt,
                                            isSwahili = isSwahili
                                        )
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Download, contentDescription = "PDF", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("PDF Report", fontSize = 12.sp)
                            }

                            IconButton(
                                onClick = {
                                    val shareIngredients = result.ingredientPercentages.map { Pair(it.key, it.value) }
                                    shareFormulaImage(
                                        context = context,
                                        title = "My ${currentTargetVal?.birdType} ${currentTargetVal?.stageName} Feed",
                                        birdType = currentTargetVal?.birdType ?: "Poultry",
                                        stageName = currentTargetVal?.stageName ?: "Feed",
                                        batchWeight = batchWeightVal,
                                        totalCost = result.totalCost,
                                        ingredients = shareIngredients,
                                        unitPrice = result.costPerKg,
                                        isSwahili = isSwahili
                                    )
                                },
                                modifier = Modifier
                                    .background(MaterialTheme.colorScheme.tertiary.copy(alpha = 0.12f), RoundedCornerShape(8.dp))
                                    .size(40.dp)
                                    .testTag("share_image_direct_btn")
                            ) {
                                Icon(Icons.Default.Share, contentDescription = "Share Image", tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }
            }

            // Discuss with AI Advisor Option
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f)
                    ),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Psychology,
                                    contentDescription = "AI Advisor",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = if (isSwahili) "Mshauri wa AI (Discuss with AI)" else "Consult AI Feed Advisor",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (isSwahili)
                                "Changanua fomula hii ukitumia AI: Uliza maswali ya ziada, pata ushauri wa kubadilisha viungo, au jinsi ya kulisha kundi lako kwa ufanisi mkubwa."
                                else "Analyze this precise recipe with AI: Ask questions, get advice on substitute raw materials, or request custom feeding instructions.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 15.sp
                        )
                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = { onNavigate("ai_advisor") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("discuss_with_ai_advisor_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = "Chat", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isSwahili) "Zungumza na Mshauri wa AI sasa" else "Discuss Formula with AI Chat",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }            // Budget part 4 removed             }
            }

            // Custom Formula with Available Budget Card
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.15f)
                    ),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(MaterialTheme.colorScheme.tertiary.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MonetizationOn,
                                    contentDescription = "Custom Budget Formula",
                                    tint = MaterialTheme.colorScheme.tertiary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = if (isSwahili) "Fomula ya Bajeti Maalum" else "Custom Formula with Available Budget",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.tertiary
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (isSwahili)
                                "Buni fomula inayolenga kiasi chako maalum cha bajeti. Rekebisha vipimo na asilimia za viungo ili viendane na uwezo wako vya kifedha bila kupoteza ubora mkuu."
                                else "Find a customized feed recipe adapted perfectly to fit your actual available pocket budget. Scale and alter proportions dynamically.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 15.sp
                        )
                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = { onNavigate("budget_formula") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("custom_budget_formula_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.MonetizationOn, contentDescription = "Budget", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isSwahili) "Tengeneza Fomula kwa Bajeti Yako" else "Calculate with Available Budget",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }
    }

    // Save formulation trigger dialog
    if (saveDialogOpened) {
        val focusRequester = remember { FocusRequester() }
        val keyboardController = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current
        LaunchedEffect(Unit) {
            kotlinx.coroutines.delay(150)
            focusRequester.requestFocus()
        }
        Dialog(onDismissRequest = { saveDialogOpened = false }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isSwahili) "Hifadhi Fomula hii" else "Save Recipe",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = saveTitle,
                        onValueChange = { saveTitle = it },
                        label = { Text("Recipe Title") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .focusRequester(focusRequester)
                            .testTag("save_title_input")
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { saveDialogOpened = false }) {
                            Text(if (isSwahili) "Ghairi" else "Cancel")
                        }
                        Button(
                            onClick = {
                                if (saveTitle.isNotBlank()) {
                                    viewModel.saveCurrentFormulation(saveTitle)
                                    saveDialogOpened = false
                                    Toast.makeText(context.applicationContext, if (isSwahili) "Fomula Imehifadhiwa kikamilifu!" else "Recipe Saved Successfully!", Toast.LENGTH_SHORT).show()
                                    onNavigate("saved")
                                }
                            },
                            enabled = saveTitle.isNotBlank(),
                            modifier = Modifier.testTag("save_recipe_confirm_btn")
                        ) {
                            Text(if (isSwahili) "Hifadhi" else "Save")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FlockFeedingDurationCard(
    birdType: String,
    stageName: String,
    ageWeeks: Int,
    flockSize: Int,
    batchWeight: Double,
    dailyIntakeGrams: Double,
    isSwahili: Boolean
) {
    val dailyIntakeKgPerBird = dailyIntakeGrams / 1000.0
    val totalDailyFlockIntakeKg = flockSize * dailyIntakeKgPerBird
    val daysLasts = if (totalDailyFlockIntakeKg > 0.0) batchWeight / totalDailyFlockIntakeKg else 0.0

    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.25f)
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.3f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp)
            .testTag("flock_feeding_duration_card")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Analysis",
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = if (isSwahili) "Muda & Ulaji wa Chakula cha Kundi" else "Flock Feed Duration & Intake Guide",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            
            // Stats Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Left Column: Selected Breed / Stage and Flock Size
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isSwahili) "Aina ya Kuku na Umri:" else "Selected Breed / Stage:",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray,
                        fontSize = 10.sp
                    )
                    Text(
                        text = "$birdType • $stageName ($ageWeeks wks)",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (isSwahili) "Idadi ya Kuku (Kundi):" else "Flock Size (Birds):",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray,
                        fontSize = 10.sp
                    )
                    Text(
                        text = "$flockSize ${if (isSwahili) "Kuku" else "birds"}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                // Right Column: Daily Intake per bird and Total daily flock intake
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isSwahili) "Kiwango cha Kula kwa Kuku:" else "Daily Intake Per Bird:",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray,
                        fontSize = 10.sp
                    )
                    Text(
                        text = "${String.format(java.util.Locale.US, "%,.1f", dailyIntakeGrams)} g / siku",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (isSwahili) "Mlo wa Kundi Zima kwa Siku:" else "Total Flock Food / Day:",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray,
                        fontSize = 10.sp
                    )
                    Text(
                        text = "${String.format(java.util.Locale.US, "%,.2f", totalDailyFlockIntakeKg)} Kg",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f))
            Spacer(modifier = Modifier.height(10.dp))

            // Highlight Box: How long it lasts
            Surface(
                color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.08f),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DateRange,
                        contentDescription = "Days calculation",
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(24.dp)
                    )
                    Column {
                        Text(
                            text = if (isSwahili) "Makadirio ya Kudumu kwa Siku:" else "Estimated Feeding Duration:",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.secondary,
                            fontWeight = FontWeight.Bold
                        )
                        val daysFormatted = String.format(java.util.Locale.US, "%.1f", daysLasts)
                        Text(
                            text = if (isSwahili) {
                                "Kiasi hiki cha chakula (${String.format(java.util.Locale.US, "%.1f", batchWeight)} Kg) kitatosha kundi lako la kuku $flockSize kwa takriban siku $daysFormatted."
                            } else {
                                "This feed quantity (${String.format(java.util.Locale.US, "%.1f", batchWeight)} Kg) will last for approximately $daysFormatted days for your flock of $flockSize birds."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun NutrientTargetTable(
    target: NutrientTarget,
    result: com.example.formulator.SolverResult,
    isSwahili: Boolean
) {
    val isDark = MaterialTheme.colorScheme.background.red < 0.2f
    val cardBg = if (isDark) Color(0xFF1B251E) else Color(0xFFFAF6EE)
    val cardBorder = if (isDark) Color(0xFF2C352E) else Color(0xFFE3DAC9)
    val trackBg = if (isDark) Color(0xFF131A15) else Color(0xFFF1EAE1)

    val items = listOf(
        NutrientCheckRowData("Crude Protein", target.crudeProtein, result.achievedNutrients.crudeProtein, "%", false),
        NutrientCheckRowData("Metab. Energy", target.energy, result.achievedNutrients.energy, " kcal", false),
        NutrientCheckRowData("Calcium", target.calcium, result.achievedNutrients.calcium, "%", false),
        NutrientCheckRowData("Phosphorus", target.phosphorus, result.achievedNutrients.phosphorus, "%", false),
        NutrientCheckRowData("Lysine", target.lysine, result.achievedNutrients.lysine, "%", false),
        NutrientCheckRowData("Methionine", target.methionine, result.achievedNutrients.methionine, "%", false),
        NutrientCheckRowData("Crude Fiber", target.crudeFiber, result.achievedNutrients.crudeFiber, "%", true)
    )

    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
        val isGrid = maxWidth > 500.dp
        
        if (isGrid) {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                val chunks = items.chunked(2)
                chunks.forEach { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        rowItems.forEach { item ->
                            Box(modifier = Modifier.weight(1f)) {
                                NutrientVisualCard(item, isSwahili, isDark, cardBg, cardBorder, trackBg)
                            }
                        }
                        if (rowItems.size < 2) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        } else {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items.forEach { item ->
                    NutrientVisualCard(item, isSwahili, isDark, cardBg, cardBorder, trackBg)
                }
            }
        }
    }
}

@Composable
fun NutrientVisualCard(
    item: NutrientCheckRowData,
    isSwahili: Boolean,
    isDark: Boolean,
    cardBg: Color,
    cardBorder: Color,
    trackBg: Color
) {
    val nutrientNameLocalized = when (item.name) {
        "Crude Protein" -> if (isSwahili) "Protini Ghafi (CP)" else "Crude Protein"
        "Metab. Energy" -> if (isSwahili) "Nishati (ME)" else "Metab. Energy"
        "Calcium" -> if (isSwahili) "Madini ya Chokaa" else "Calcium"
        "Phosphorus" -> if (isSwahili) "Fosforasi (P)" else "Phosphorus"
        "Lysine" -> if (isSwahili) "Lysine (Amina)" else "Lysine"
        "Methionine" -> if (isSwahili) "Methionine (Amina)" else "Methionine"
        "Crude Fiber" -> if (isSwahili) "Nyuzi Ghafi (Fiber)" else "Crude Fiber"
        else -> item.name
    }

    val isDeficient = if (item.isMaxBound) {
        item.achieved > item.target + 0.1
    } else {
        item.achieved < item.target - 0.05
    }

    val statusColor = if (isDeficient) Color(0xFFC62828) else Color(0xFF2E7D32)
    val statusBg = if (isDeficient) Color(0xFFFFEBEE) else Color(0xFFE8F5E9)

    Card(
        colors = CardDefaults.cardColors(containerColor = cardBg),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, cardBorder.copy(alpha = 0.8f)),
        modifier = Modifier
            .fillMaxWidth()
            .shadow(1.dp, shape = RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = nutrientNameLocalized,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) Color(0xFFE8F5E9) else Color(0xFF1B2E1E)
                )
                
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isDark) statusColor.copy(alpha = 0.25f) else statusBg)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (isDeficient) {
                            if (isSwahili) "Sio Sawa ❌" else "Deficient ❌"
                        } else {
                            if (isSwahili) "Imetimia ✓" else "Target Met ✓"
                        },
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isDark) (if (isDeficient) Color(0xFFFFCDD2) else Color(0xFFC8E6C9)) else statusColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    text = "${if (isSwahili) "Lengo: " else "Target: "}${String.format(Locale.US, "%.2f", item.target)}${item.unit}",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "${if (isSwahili) "Kiwango: " else "Achieved: "}${String.format(Locale.US, "%.2f", item.achieved)}${item.unit}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = statusColor
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            val maxScale = maxOf(item.target, item.achieved, 1.0) * 1.15
            val targetPercent = (item.target / maxScale).toFloat().coerceIn(0f, 1f)
            val achievedPercent = (item.achieved / maxScale).toFloat().coerceIn(0f, 1f)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(CircleShape)
                    .background(trackBg)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(targetPercent)
                        .background(if (isDark) Color(0xFF2C352E).copy(alpha = 0.5f) else Color(0xFFE3DAC9).copy(alpha = 0.5f))
                )
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(achievedPercent)
                        .background(statusColor)
                )
            }
        }
    }
}

data class NutrientCheckRowData(
    val name: String,
    val target: Double,
    val achieved: Double,
    val unit: String,
    val isMaxBound: Boolean
)

@Composable
fun NutrientCompensationRecommendations(
    target: NutrientTarget,
    result: com.example.formulator.SolverResult,
    rawIngredientsList: List<Ingredient>,
    isSwahili: Boolean
) {
    val deficientNutrients = mutableSetOf<String>()
    if (result.achievedNutrients.crudeProtein < target.crudeProtein - 0.05) deficientNutrients.add("Protein")
    if (result.achievedNutrients.energy < target.energy - 10.0) deficientNutrients.add("Energy")
    if (result.achievedNutrients.calcium < target.calcium - 0.05) deficientNutrients.add("Calcium")
    if (result.achievedNutrients.phosphorus < target.phosphorus - 0.05) deficientNutrients.add("Phosphorus")
    if (result.achievedNutrients.lysine < target.lysine - 0.03) deficientNutrients.add("Lysine")
    if (result.achievedNutrients.methionine < target.methionine - 0.03) deficientNutrients.add("Methionine")

    if (deficientNutrients.isEmpty()) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
            border = BorderStroke(1.dp, Color(0xFFC8E6C9)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Safe",
                    tint = Color(0xFF2E7D32),
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isSwahili)
                        "Hongera! Mchanganyiko wako unafikia viwango vyote vya virutubisho vilivyopendekezwa."
                        else "Excellent! Your feed recipe meets all standard nutritional benchmarks.",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1B5E20)
                )
            }
        }
        return
    }

    val unselectedSuggestions = mutableListOf<String>()
    val selectedSuggestions = mutableListOf<String>()

    deficientNutrients.forEach { deficiency ->
        val candidates = when (deficiency) {
            "Protein" -> rawIngredientsList.sortedByDescending { it.crudeProtein }.take(4)
            "Energy" -> rawIngredientsList.sortedByDescending { it.energy }.take(4)
            "Calcium" -> rawIngredientsList.sortedByDescending { it.calcium }.take(3)
            "Phosphorus" -> rawIngredientsList.sortedByDescending { it.phosphorus }.take(3)
            else -> emptyList()
        }

        candidates.forEach { ing ->
            val dispName = if (isSwahili) {
                when (ing.name) {
                    "Maize (Mahindi)" -> "Mahindi"
                    "Oya/Rice Polly" -> "Pumba za Mpunga"
                    "Maize Bran (Pumba)" -> "Pumba za Mahindi"
                    "Maize Germ meal" -> "Kiini cha Mahindi"
                    "Limestone" -> "Chokaa ya Mifugo"
                    "Bone Meal" -> "Unga wa Mifupa"
                    "DCP" -> "Madini ya Fosforasi"
                    "Soybean Meal" -> "Soya"
                    "Sunflower Cake", "Sunflower Seed Cake (Mashapo ya Alizeti)" -> "Mashapo ya Alizeti"
                    "Cotton Seed Cake" -> "Mashapo ya Pamba"
                    "Fish Meal (Omena)" -> "Dagaa (Samaki)"
                    "Premix" -> "Virutubisho Maalum"
                    else -> formatIngredientName(ing.name, isSwahili)
                }
            } else {
                when (ing.name) {
                    "Maize (Mahindi)" -> "Maize"
                    "Oya/Rice Polly" -> "Rice Polly"
                    "Maize Bran (Pumba)" -> "Maize Bran"
                    "Maize Germ meal" -> "Maize Germ"
                    "Limestone" -> "Limestone"
                    "Bone Meal" -> "Bone Meal"
                    "DCP" -> "DCP"
                    "Soybean Meal" -> "Soybean Meal"
                    "Sunflower Cake", "Sunflower Seed Cake (Mashapo ya Alizeti)" -> "Sunflower Seed Cake"
                    "Cotton Seed Cake" -> "Cotton Seed Cake"
                    "Fish Meal (Omena)" -> "Fish Meal"
                    "Premix" -> "Premix"
                    else -> formatIngredientName(ing.name, isSwahili)
                }
            }

            if (ing.isSelected) {
                if (!selectedSuggestions.contains(dispName)) {
                    val detail = when (deficiency) {
                        "Protein" -> "$dispName (+${String.format(Locale.US, "%.1f", ing.crudeProtein)}% CP)"
                        "Energy" -> "$dispName (+${String.format(Locale.US, "%.0f", ing.energy)} kcal)"
                        "Calcium" -> "$dispName (+${String.format(Locale.US, "%.1f", ing.calcium)}% Ca)"
                        "Phosphorus" -> "$dispName (+${String.format(Locale.US, "%.1f", ing.phosphorus)}% P)"
                        else -> dispName
                    }
                    selectedSuggestions.add(detail)
                }
            } else {
                if (!unselectedSuggestions.contains(dispName)) {
                    val detail = when (deficiency) {
                        "Protein" -> "$dispName (+${String.format(Locale.US, "%.1f", ing.crudeProtein)}% CP)"
                        "Energy" -> "$dispName (+${String.format(Locale.US, "%.0f", ing.energy)} kcal)"
                        "Calcium" -> "$dispName (+${String.format(Locale.US, "%.1f", ing.calcium)}% Ca)"
                        "Phosphorus" -> "$dispName (+${String.format(Locale.US, "%.1f", ing.phosphorus)}% P)"
                        else -> dispName
                    }
                    unselectedSuggestions.add(detail)
                }
            }
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .testTag("nutrient_compensation_recs_card"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.08f)),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.25f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Analysis Suggestions",
                    tint = Color(0xFFD32F2F),
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isSwahili) "Ushauri wa Kufidia Mchanganyiko" else "Deficiency Analysis & Compensation Suggestions",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = Color(0xFFB71C1C)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = if (isSwahili)
                    "Mchanganyiko wako una upungufu wa kibaolojia ikilinganishwa na viwango vinavyotakiwa. Ili kukabiliana na upungufu huu, fanya yafuatayo:"
                else "Your feed formula contains deficiencies relative to standard target values. To compensate, consider adjusting your ingredients:",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 15.sp
            )

            if (unselectedSuggestions.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = if (isSwahili) "Ongeza vifaa vipya (Kwenye skrini ya 'Ngoja Nikisafishe'):" else "Select these new ingredients in 'What I Have' section:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                unselectedSuggestions.take(4).forEach { item ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(vertical = 2.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(4.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.error)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = item,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            if (selectedSuggestions.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = if (isSwahili) "Ongeza asilimia (Inclusion share) ya vifaa hivi vilivyochaguliwa:" else "Increase usage share / minimum limit for these selected ingredients:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                selectedSuggestions.take(4).forEach { item ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(vertical = 2.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(4.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.secondary)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = item,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun NutrientBarChartItem(
    name: String,
    target: Double,
    achieved: Double,
    unit: String,
    isMaxLimit: Boolean
) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(name, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            Text(
                text = "${String.format("%.2f", achieved)}$unit / ${String.format("%.2f", target)}$unit",
                fontSize = 11.sp,
                color = Color.Gray
            )
        }
        Spacer(modifier = Modifier.height(2.dp))

        // Multi bar indicator
        val maxScale = maxOf(target, achieved) * 1.2
        val achievedProgress = if (maxScale > 0) (achieved / maxScale).toFloat() else 0f
        val targetProgress = if (maxScale > 0) (target / maxScale).toFloat() else 0f

        val isPassing = if (isMaxLimit) achieved <= target else achieved >= target - 0.05
        val barColor = if (isPassing) MaterialTheme.colorScheme.primary else Color(0xFFE53935)

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(12.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            // Target benchmark slice
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(targetProgress)
                    .background(Color.Gray.copy(alpha = 0.25f))
            )
            // Achieved core progress
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(achievedProgress)
                    .background(barColor)
            )
        }
    }
}

@Composable
fun IngredientPriceInputRow(
    ing: Ingredient,
    isSwahili: Boolean,
    onPriceChange: (Double) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1.3f)) {
            Text(
                text = formatIngredientName(ing.name, isSwahili), 
                fontWeight = FontWeight.Bold, 
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "${ing.category} • CP: ${ing.crudeProtein}%",
                fontSize = 10.sp,
                color = Color.Gray
            )
        }
        
        var textValue by remember(ing.id, ing.pricePerKg) {
            mutableStateOf(if (ing.pricePerKg == 0.0) "" else String.format(Locale.US, "%.0f", ing.pricePerKg))
        }

        OutlinedTextField(
            value = textValue,
            onValueChange = { newValue ->
                textValue = newValue
                val validPrice = newValue.toDoubleOrNull()
                if (validPrice != null && validPrice >= 0.0) {
                    onPriceChange(validPrice)
                } else if (newValue.isEmpty()) {
                    onPriceChange(0.0)
                }
            },
            placeholder = { Text("0") },
            label = { 
                Text(
                    text = if (isSwahili) "Bei (TSh/Kilo)" else "Price (TSh/Kg)", 
                    fontSize = 11.sp
                ) 
            },
            modifier = Modifier
                .width(145.dp)
                .testTag("price_input_tsh_${ing.id}"),
            singleLine = true,
            trailingIcon = {
                Text(
                    text = "TSh",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(end = 8.dp)
                )
            },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            shape = RoundedCornerShape(12.dp),
            textStyle = TextStyle(fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        )
    }
}

// --- 2. Feed Cost Calculator Screen ---
@Composable
fun CostCalculatorScreen(
    viewModel: PoultryViewModel,
    onNavigate: (String) -> Unit,
    isSwahili: Boolean
) {
    val flockSize by viewModel.birdCount.collectAsStateWithLifecycle()
    val rawIngredients by viewModel.ingredients.collectAsStateWithLifecycle()
    val solverRes by viewModel.solverResult.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Breed Type Selector Card
        item {
            val birdType by viewModel.selectedBirdType.collectAsStateWithLifecycle()
            Card(
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isSwahili) "Aina ya Kuku (Breed Type Selection)" else "Select Breed Type",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isSwahili) "Chagua aina ya kuku ili kuona nishati yao" else "Sets nutritional targets for calculations like feed cost projections.",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Broiler", "Layer", "Hybrid / Kienyeji").forEach { type ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        if (birdType == type) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.surfaceVariant
                                    )
                                    .clickable { 
                                        viewModel.selectedBirdType.value = type
                                    }
                                    .padding(vertical = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (isSwahili) {
                                        when (type) {
                                            "Broiler" -> "Broiler"
                                            "Layer" -> "Layer"
                                            else -> "Hybrid"
                                        }
                                    } else {
                                        when (type) {
                                            "Hybrid / Kienyeji" -> "Hybrid"
                                            else -> type
                                        }
                                    },
                                    color = if (birdType == type) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Price editor card
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isSwahili) "Mabadiliko ya Bei kwa Kilo (TSh)" else "Ingredient Price per Kg (TSh)",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isSwahili) "Jaza kiasi cha fedha cha kila kiungo hapa chini kwa msimbo wa TSh ili kufanya mabadiliko." 
                               else "Fill in the blank boxes below with each raw material's unit price in TSh per Kg.",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    val selectedMaterials = rawIngredients.filter { it.isSelected }
                    if (selectedMaterials.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f))
                                .clickable { onNavigate("what_i_have") }
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (isSwahili) "Hakuna viungo vilivyochaguliwa kwenye Alizonazo (What I Have). Bonyeza hapa kuchagua viungo."
                                       else "No ingredients currently selected in 'What I Have'. Click here to select available items first.",
                                color = MaterialTheme.colorScheme.error,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        selectedMaterials.forEach { ing ->
                            IngredientPriceInputRow(
                                ing = ing,
                                isSwahili = isSwahili,
                                onPriceChange = { newPrice ->
                                    viewModel.updateIngredientPrice(ing, newPrice)
                                }
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    
                    val context = LocalContext.current
                    Button(
                        onClick = {
                            viewModel.runFormulation()
                            Toast.makeText(
                                context.applicationContext,
                                if (isSwahili) "Bei zimehifadhiwa! Kikokotoo kimeanza..." else "Prices saved! Calculation started...",
                                Toast.LENGTH_SHORT
                            ).show()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("save_and_calculate_prices_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Save,
                            contentDescription = if (isSwahili) "Hifadhi na Kokotoa" else "Save and Calculate",
                            tint = Color.White
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isSwahili) "Hifadhi & Kokotoa Gharama" else "Save & Calculate Cost",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color.White
                        )
                    }
                }
            }
        }

        // Active formulation price metrics card
        solverRes?.let { result ->
            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.12f)),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (isSwahili) "Mchanganuo wa Gharama za Lishe" else "Recipe Cost Projections",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        val costPer50kg = result.costPerKg * 50
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(if (isSwahili) "Bei kwa Kilo (1 Kg)" else "Cost per 1 Kg", fontSize = 11.sp, color = Color.Gray)
                                Text("${String.format("%,.0f", result.costPerKg)} TSh", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
                            }
                            Column {
                                Text(if (isSwahili) "Bei kwa Mfuko (50 Kg)" else "Cost per 50 Kg bag", fontSize = 11.sp, color = Color.Gray)
                                Text("${String.format("%,.0f", costPer50kg)} TSh", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        canvasPriceMetrics(result, isSwahili)
                    }
                }
            }

            item {
                BudgetRecalculationCard(viewModel = viewModel, result = result, isSwahili = isSwahili)
            }
        } ?: item {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = if (isSwahili) "Tafadhali kwanza unda Fomula ya Lishe ili kuona uchambuzi kamili wa gharama." 
                    else "Please solve a recipe formulation first under the 'Feed Formulation' tab to see specific Cost break-downs.",
                    modifier = Modifier.padding(16.dp),
                    textAlign = TextAlign.Center,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
fun canvasPriceMetrics(result: SolverResult, isSwahili: Boolean) {
    Column {
        Text(if (isSwahili) "Mchango wa Viungo kwa Bei (%):" else "Ingredient shares portion of feed cost (%):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(8.dp))

        val percentages = result.ingredientPercentages
        for ((name, percent) in percentages) {
            if (percent > 0.0) {
                val individualSharesVal = (percent / 100) * (result.costPerKg) // weight cost proportion
                val costPortionFactor = if (result.costPerKg > 0) individualSharesVal / result.costPerKg else 0.0
                
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
                    Text(formatIngredientName(name, isSwahili), fontSize = 11.sp, modifier = Modifier.weight(1.5f))
                    Box(
                        modifier = Modifier
                            .weight(2f)
                            .height(8.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(costPortionFactor.toFloat())
                                .background(MaterialTheme.colorScheme.secondary)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(String.format("%.1f %%", costPortionFactor * 100), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// --- 3. Feed Requirement Calculator ---
@Composable
fun FeedRequirementScreen(
    viewModel: PoultryViewModel,
    onNavigate: (String) -> Unit,
    isSwahili: Boolean
) {
    val size by viewModel.birdCount.collectAsStateWithLifecycle()
    val duration by viewModel.feedingDurationDays.collectAsStateWithLifecycle()
    val birdType by viewModel.selectedBirdType.collectAsStateWithLifecycle()
    val ageWeeks by viewModel.selectedAgeWeeks.collectAsStateWithLifecycle()
    val solverRes by viewModel.solverResult.collectAsStateWithLifecycle()
    val isVerifying by viewModel.isVerifyingStandards.collectAsStateWithLifecycle()
    val verifiedStandardsText by viewModel.verifiedStandardsText.collectAsStateWithLifecycle()

    LaunchedEffect(birdType, ageWeeks) {
        viewModel.verifyStandardsWithAI()
    }

    val stages = when (birdType) {
        "Broiler" -> listOf(
            Triple("Broiler Starter", if (isSwahili) "Starter (Wiki 1)" else "Broiler Starter (Wk 1)", 1),
            Triple("Broiler Grower", if (isSwahili) "Grower (Wiki 2-3)" else "Broiler Grower (Wk 2-3)", 2),
            Triple("Broiler Finisher", if (isSwahili) "Finisher (Wiki 4+)" else "Broiler Finisher (Wk 4+)", 4)
        )
        "Layer" -> listOf(
            Triple("Chick Starter", if (isSwahili) "Starter ya Vifaranga (Wiki 1-8)" else "Chick Starter (Wk 1-8)", 4),
            Triple("Grower Mash", if (isSwahili) "Grower Mash (Wiki 9-18)" else "Growers Mash (Wk 9-18)", 12),
            Triple("Layer Mash", if (isSwahili) "Layer Mash (Wiki 19+)" else "Layers Mash (Wk 19+)", 22)
        )
        else -> listOf( // Hybrid / Kienyeji
            Triple("Hybrid Starter", if (isSwahili) "Kienyeji Starter (Wiki 1-8)" else "Kienyeji Starter (Wk 1-8)", 4),
            Triple("Hybrid Grower", if (isSwahili) "Kienyeji Grower (Wiki 9-20)" else "Kienyeji Growers Mash (Wk 9-20)", 12),
            Triple("Hybrid Laying", if (isSwahili) "Kienyeji Laying/Breeder (Wiki 21+)" else "Kienyeji Laying/Breeder (Wk 21+)", 24)
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Step 1: Select Breed Type
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isSwahili) "1. Chagua Aina ya Kuku" else "1. Select Breed Type",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Broiler", "Layer", "Hybrid / Kienyeji").forEach { type ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        if (birdType == type) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.surfaceVariant
                                    )
                                    .clickable { 
                                        viewModel.selectedBirdType.value = type
                                        // Auto adjust age when switching breed
                                        val defaultAge = when (type) {
                                            "Broiler" -> 2
                                            "Layer" -> 22
                                            else -> 12
                                        }
                                        viewModel.selectedAgeWeeks.value = defaultAge
                                    }
                                    .padding(vertical = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (isSwahili) {
                                        when (type) {
                                            "Broiler" -> "Broiler"
                                            "Layer" -> "Layer"
                                            else -> "Hybrid"
                                        }
                                    } else {
                                        when (type) {
                                            "Hybrid / Kienyeji" -> "Hybrid"
                                            else -> type
                                        }
                                    },
                                    color = if (birdType == type) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Step 2: Select Stage depending on Breed Selection
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isSwahili) "2. Chagua Hatua ya Malisho" else "2. Select Growth Stage",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    stages.forEach { (stageId, textLabel, targetWeek) ->
                        val isSelected = when (birdType) {
                            "Broiler" -> when (targetWeek) {
                                1 -> ageWeeks <= 1
                                2 -> ageWeeks in 2..3
                                else -> ageWeeks >= 4
                            }
                            "Layer" -> when (targetWeek) {
                                4 -> ageWeeks <= 8
                                12 -> ageWeeks in 9..18
                                else -> ageWeeks >= 19
                            }
                            else -> when (targetWeek) {
                                4 -> ageWeeks <= 8
                                12 -> ageWeeks in 9..20
                                else -> ageWeeks >= 21
                            }
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                                    else Color.Transparent
                                )
                                .border(
                                    BorderStroke(
                                        if (isSelected) 1.5.dp else 1.dp,
                                        if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
                                    ),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable {
                                    viewModel.selectedAgeWeeks.value = targetWeek
                                }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = { viewModel.selectedAgeWeeks.value = targetWeek },
                                colors = RadioButtonDefaults.colors(selectedColor = MaterialTheme.colorScheme.primary)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = textLabel,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = if (isSwahili) "Marekebisho kwa Wiki ya $targetWeek" else "Maps target nutritional content at week $targetWeek",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                        }
                    }
                }
            }
        }

        // Continue Button
        item {
            val context = LocalContext.current
            Button(
                onClick = {
                    viewModel.runFormulation()
                    onNavigate("what_i_have")
                    Toast.makeText(
                        context.applicationContext,
                        if (isSwahili) "Tunaelekea Alizonazo (What I Have)..."
                        else "Navigating to What I Have...",
                        Toast.LENGTH_SHORT
                    ).show()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("save_and_continue_demand_btn"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = if (isSwahili) "Endelea" else "Continue",
                    tint = Color.White
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isSwahili) "Endelea (Next)" else "Continue",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun BudgetRecalculationCard(
    viewModel: PoultryViewModel,
    result: com.example.formulator.SolverResult,
    isSwahili: Boolean
) {
    val budgetFlow by viewModel.availableBudget.collectAsStateWithLifecycle()
    val context = LocalContext.current
    
    var budgetText by remember(budgetFlow) {
        mutableStateOf(if (budgetFlow == 0.0) "" else String.format(java.util.Locale.US, "%.0f", budgetFlow))
    }

    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("budget_recal_card")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.MonetizationOn,
                    contentDescription = "Budget",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isSwahili) "Kikokotoo cha Bajeti ya Chakula" else "Affordability Budget Recalculator",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = if (isSwahili) 
                    "Ingiza bajeti yako kuona kiasi cha chakula unachoweza kutengeneza na fomula itajirekebisha."
                    else "Enter your available budget in TSh to auto-recalculate total feed volume within your financial limit.",
                fontSize = 11.sp,
                color = Color.Gray
            )
            
            Spacer(modifier = Modifier.height(16.dp))

            // Budget Input Field
            OutlinedTextField(
                value = budgetText,
                onValueChange = { newValue ->
                    budgetText = newValue
                    val parsed = newValue.toDoubleOrNull()
                    if (parsed != null && parsed >= 0.0) {
                        viewModel.availableBudget.value = parsed
                    } else if (newValue.isEmpty()) {
                        viewModel.availableBudget.value = 0.0
                    }
                },
                label = { Text(if (isSwahili) "Bajeti Yako (TSh)" else "Your Available Budget (TSh)") },
                placeholder = { Text("0") },
                trailingIcon = {
                    Text(
                        text = "TSh",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(end = 8.dp)
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("budget_tsh_input"),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                shape = RoundedCornerShape(12.dp),
                textStyle = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            )

            // Dynamic calculation info
            if (budgetFlow > 0.0 && result.costPerKg > 0.0) {
                val affordableKg = budgetFlow / result.costPerKg
                Spacer(modifier = Modifier.height(12.dp))
                
                Surface(
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.05f),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = if (isSwahili) "Makadirio ya Uwezo wako:" else "Affordable Output Estimates:",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isSwahili) 
                                "Kwa bajeti ya TSh ${String.format("%,.0f", budgetFlow)}, unaweza kutengeneza kilo ${String.format("%,.2f", affordableKg)} za chakula hiki."
                                else "With TSh ${String.format("%,.0f", budgetFlow)}, you can make ${String.format("%,.2f", affordableKg)} Kg of this recipe.",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(14.dp))
                
                Button(
                    onClick = {
                        val finalWeight = budgetFlow / result.costPerKg
                        if (finalWeight > 0.1) {
                            viewModel.batchWeight.value = finalWeight
                            viewModel.customBatchWeightText.value = String.format(java.util.Locale.US, "%.1f", finalWeight)
                            Toast.makeText(
                                context.applicationContext,
                                if (isSwahili) 
                                    "Fomula imerekebishwa kuwa Kilo ${String.format("%,.1f", finalWeight)} kufikia bajeti!" 
                                    else "Formula batch configured to ${String.format("%,.1f", finalWeight)} Kg to fit budget!",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("apply_budget_calculation_btn"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Save,
                        contentDescription = "Apply",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isSwahili) "Kokotoa & Kadiria Kilo za Fomula" else "Apply Budget to Feed Volume",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}

@Composable
fun RequirementCalculatedItem(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f))
        Text(value, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
    }
}

// --- 4. Growth Estimator Screen ---
@Composable
fun GrowthEstimatorScreen(viewModel: PoultryViewModel, isSwahili: Boolean) {
    val birdType by viewModel.selectedBirdType.collectAsStateWithLifecycle()
    val ageWeeks by viewModel.selectedAgeWeeks.collectAsStateWithLifecycle()
    val feedCostKilo by viewModel.growthFeedCostPerKg.collectAsStateWithLifecycle()

    var costInputText by remember(feedCostKilo) { mutableStateOf(feedCostKilo.toString()) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Feed cost input card
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isSwahili) "Gharama ya Chakula (Feed Cost Input)" else "Input Feed Price",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isSwahili) "Weka bei ya Kilo 1 ya chakula ili kukadiria gharama za ukuaji."
                               else "Input standard cost per 1 Kg of complete feed to project economic metrics.",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = costInputText,
                        onValueChange = {
                            costInputText = it
                            it.toDoubleOrNull()?.let { value ->
                                viewModel.growthFeedCostPerKg.value = value
                            }
                        },
                        label = { Text(if (isSwahili) "Bei ya Chakula kwa Kilo 1 (TSh)" else "Feed Cost per 1 Kg (TSh)") },
                        modifier = Modifier.fillMaxWidth().testTag("growth_cost_per_kg_input"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true,
                        trailingIcon = {
                            Text(
                                text = "TSh",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(end = 8.dp)
                            )
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                }
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isSwahili) "Makadirio ya Ukuaji na Gharama" else "Project Growth & Cost Analysis",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isSwahili) "Tathmini uzani thabiti na gharama kutoka wiki ya sasa." else "Expected targets and input costs based on selection.",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    val stats = viewModel.getStandardNutritionInfo(birdType, ageWeeks)
                    val cumFeedEatenPkg = (stats.totalFcr * stats.expectedBodyWeightGrams) / 1000.0
                    val cumCostPerBird = cumFeedEatenPkg * feedCostKilo

                    // Large projection highlights
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).padding(2.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(if (isSwahili) "Uzito" else "Target Weight", fontSize = 10.sp, textAlign = TextAlign.Center, color = Color.Gray)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("${stats.expectedBodyWeightGrams}g", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                            }
                        }

                        Surface(
                            color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.08f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).padding(2.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(if (isSwahili) "FCR ya Jumla" else "FCR Target", fontSize = 10.sp, textAlign = TextAlign.Center, color = Color.Gray)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("${stats.totalFcr}", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = MaterialTheme.colorScheme.secondary)
                            }
                        }

                        Surface(
                            color = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.08f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).padding(2.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(if (isSwahili) "Gharama/Kuku" else "Cost/Bird", fontSize = 10.sp, textAlign = TextAlign.Center, color = Color.Gray)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(String.format("%.1f", cumCostPerBird), fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = MaterialTheme.colorScheme.tertiary)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                    Text(if (isSwahili) "Grafu ya Matarajio ya Ukuaji:" else "Weekly Growth Curve Projections:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Draw simple textual curve points
                    val ranges = if (birdType == "Broiler") listOf(1, 2, 4, 6, 8) else listOf(2, 4, 8, 12, 18, 24)
                    ranges.forEach { wk ->
                        val wkStats = viewModel.getStandardNutritionInfo(birdType, wk)
                        val wkCumFeed = (wkStats.totalFcr * wkStats.expectedBodyWeightGrams) / 1000.0
                        val wkCumCost = wkCumFeed * feedCostKilo
                        
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(if (isSwahili) "Wk $wk" else "Week $wk", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(44.dp))
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(horizontal = 8.dp)
                                    .height(4.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                val maxW = if (birdType == "Broiler") 3000.0 else 2200.0
                                val relativeProgress = wkStats.expectedBodyWeightGrams / maxW
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(relativeProgress.toFloat())
                                        .background(MaterialTheme.colorScheme.primary)
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("${wkStats.expectedBodyWeightGrams}g", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text(
                                    text = if (isSwahili) "${String.format("%.1f", wkCumCost)} Tsh" else "${String.format("%.1f", wkCumCost)} Price", 
                                    fontSize = 9.sp, 
                                    color = Color.Gray
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- 5. AI Advisor Chat ---
@Composable
fun AIAdvisorScreen(viewModel: PoultryViewModel, isSwahili: Boolean) {
    val advice by viewModel.adviceText.collectAsStateWithLifecycle()
    val isLoading by viewModel.isAdviceLoading.collectAsStateWithLifecycle()
    
    val currentQuestion by viewModel.currentAIQuestion.collectAsStateWithLifecycle()
    val solverRes by viewModel.solverResult.collectAsStateWithLifecycle()
    val currentTargetVal by viewModel.currentTarget.collectAsStateWithLifecycle()

    var userQuestionText by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Dynamics Buy Quantity Calculator Card
        item {
            val ingredients by viewModel.ingredients.collectAsStateWithLifecycle()
            val flockSize by viewModel.birdCount.collectAsStateWithLifecycle()
            val feedDuration by viewModel.feedingDurationDays.collectAsStateWithLifecycle()
            val birdType by viewModel.selectedBirdType.collectAsStateWithLifecycle()
            val ageWeeks by viewModel.selectedAgeWeeks.collectAsStateWithLifecycle()

            val stats = viewModel.getStandardNutritionInfo(birdType, ageWeeks)
            val dailyFeedKg = stats.dailyFeedInTakeGrams / 1000.0
            val totalFeedCumulativeKg = flockSize * feedDuration * dailyFeedKg

            Card(
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.12f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isSwahili) "Kikokotoo cha Manunuzi (Demand Buy Estimator)" else "Bulk Purchasing Calculator (What I Have)",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isSwahili) "Kadiria viwango vya malighafi unavyopaswa kununua stoo kulingana na kundi la kuku na formula."
                               else "Calculates exact quantities of selected ingredients to purchase for your flock timeline.",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Flock summary metrics row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(if (isSwahili) "Muda & Kuku" else "Flock Size & Duration", fontSize = 11.sp, color = Color.Gray)
                            Text("$flockSize Birds • $feedDuration Days", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(if (isSwahili) "Mahitaji ya Jumla" else "Total Feed Required", fontSize = 11.sp, color = Color.Gray)
                            Text(String.format("%.1f Kg", totalFeedCumulativeKg), fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)))
                    Spacer(modifier = Modifier.height(12.dp))

                    val selectedIngredients = ingredients.filter { it.isSelected }

                    if (selectedIngredients.isEmpty()) {
                        Text(
                            text = if (isSwahili) "⚠️ Hakuna viungo vilivyochaguliwa kwenye stoo. Tafadhali nenda kwenye 'What I Have' kwanza."
                                   else "⚠️ No active ingredients are selected. Please go to 'What I Have' to choose your farm materials.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold
                        )
                    } else if (solverRes == null || solverRes?.errorMessage != null) {
                        Column {
                            Text(
                                text = if (isSwahili) "Fomula bora ya mchanganyiko haijapatikana bado ya kusambaza viwango." 
                                       else "Formula mix hasn't been successfully computed yet.",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = { viewModel.runFormulation() },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                            ) {
                                Text(if (isSwahili) "Kokotoa & Kadiria Ununuzi" else "Optimize Formula & Project Buy List")
                            }
                        }
                    } else {
                        val recipeRates = solverRes?.ingredientPercentages ?: emptyMap()
                        
                        Text(
                            text = if (isSwahili) "Viwango vya Kununua kwa Kila Kiungo:" else "Amount of Raw Materials to Buy:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        recipeRates.forEach { (name, percent) ->
                            val neededKg = totalFeedCumulativeKg * (percent / 100.0)
                            val bags = neededKg / 50.0
                            
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.primary)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(formatIngredientName(name, isSwahili), fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(String.format("%.1f Kg", neededKg), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                    Text(
                                        text = if (isSwahili) String.format("%.1f mifuko (50kg)", bags) else String.format("%.1f bags (50kg)", bags),
                                        fontSize = 10.sp,
                                        color = Color.Gray
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        
                        Button(
                            onClick = {
                                val listText = recipeRates.entries.joinToString { "${it.key}: ${String.format("%.1f", totalFeedCumulativeKg * (it.value / 100.0))} Kg" }
                                val questionText = if (isSwahili) {
                                    "Nina kundi la kuku $flockSize kwa siku $feedDuration wakiwa katika hatua ya kuku ${currentTargetVal?.stageName ?: "Harakati"}. Fomula mchanganyiko wangu wa nishati inaleta ununuzi wa: $listText. Tathmini kiwango hiki na unipe ushauri mwerevu kielektroniki."
                                } else {
                                    "I have a flock of $flockSize birds for $feedDuration days in stage '${currentTargetVal?.stageName ?: "Growth"}'. My formulation requires buying: $listText. Evaluate this purchase and give expert mixing or substitution recommendations."
                                }
                                viewModel.askAIAdvisor(questionText)
                            },
                            modifier = Modifier.fillMaxWidth().testTag("ai_evaluate_buy_list_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Psychology, contentDescription = "AI")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (isSwahili) "Tathmini na Daktari wa AI" else "Evaluate Buy List with AI")
                        }
                    }
                }
            }
        }

        item {
            Card(
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isSwahili) "Mshauri mwerevu wa Lishe" else "Smart Feeding Diagnostics & AI",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isSwahili) "Uliza swali lolote la kulisha ukitumia muundo wa AI mtandaoni na nje ya mtandao." 
                        else "Submit questions regarding substitution and nutrition metrics; works offline too.",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    // Preset Quick Action buttons
                    Text(if (isSwahili) "Maswali Yanayoulizwa Sana:" else "Quick Suggestions:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(8.dp))

                    val presets = if (isSwahili) listOf(
                        "Eleza mchanganyiko huu na nishati tuliyopata.",
                        "Gharama ya samaki (Omena) imepanda, nifanye nini?",
                        "Ni jinsi gani ninaweza kuongeza protini bila gharama kubwa?"
                    ) else listOf(
                        "Explain current formula balanced nutrient levels.",
                        "Fish meal is highly expensive, suggest local protein alternatives.",
                        "What is standard calcium requirement profile for layers?"
                    )

                    presets.forEach { text ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .clickable {
                                    userQuestionText = text
                                    viewModel.askAIAdvisor(text)
                                }
                                .padding(10.dp)
                        ) {
                            Text(text, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Question Input
                    OutlinedTextField(
                        value = userQuestionText,
                        onValueChange = { userQuestionText = it },
                        label = { Text(if (isSwahili) "Swali Lako..." else "Ask a custom question...") },
                        modifier = Modifier.fillMaxWidth().testTag("ai_custom_question_field"),
                        trailingIcon = {
                            if (isLoading) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp))
                            } else {
                                IconButton(
                                    onClick = {
                                        if (userQuestionText.isNotBlank()) {
                                            viewModel.askAIAdvisor(userQuestionText)
                                        }
                                    },
                                    modifier = Modifier.testTag("ai_send_arrow_btn")
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send")
                                }
                            }
                        },
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            }
        }

        // Response bubble
        if (advice.isNotBlank() || isLoading) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Psychology, contentDescription = "AI Advice", tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isSwahili) "Daktari Kuku Anashauri:" else "Veterinary Diagnostic Output:",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        
                        if (currentQuestion.isNotBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Q: $currentQuestion",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.Gray
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        
                        if (isLoading) {
                            Box(modifier = Modifier.fillMaxWidth().height(80.dp), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator()
                            }
                        } else {
                            Text(
                                text = advice,
                                fontSize = 13.sp,
                                lineHeight = 18.sp,
                                modifier = Modifier.testTag("ai_advice_text")
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- 6. Saved Formulations & Logs Screen ---
@Composable
fun SavedFormulationsScreen(
    viewModel: PoultryViewModel,
    onNavigate: (String) -> Unit,
    isSwahili: Boolean
) {
    val list by viewModel.savedFormulations.collectAsStateWithLifecycle()
    val listTargets by viewModel.nutrientTargets.collectAsStateWithLifecycle()
    val logs by viewModel.manufacturingLogs.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var activeTab by remember { mutableStateOf("saved") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        // Tab switcher
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (activeTab == "saved") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                    .clickable { activeTab = "saved" }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isSwahili) "Fomula Zilizohifadhiwa" else "Saved Formulations",
                    color = if (activeTab == "saved") Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (activeTab == "logs") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                    .clickable { activeTab = "logs" }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isSwahili) "Lijiti ya Viwanda" else "Manufacturing Log",
                    color = if (activeTab == "logs") Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }

        // Action Navigation Tabs/Buttons Below the Switcher
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    viewModel.resetFormulationSession()
                    onNavigate("req_calc")
                },
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .testTag("saved_generate_new_formula_btn"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                )
            ) {
                Icon(
                    imageVector = Icons.Default.Science,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isSwahili) "Mchanganyiko Mpya" else "Generate new Formula",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1
                )
            }

            Button(
                onClick = { onNavigate("home") },
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .testTag("saved_go_home_btn"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            ) {
                Icon(
                    imageVector = Icons.Default.Home,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isSwahili) "Nenda Nyumbani" else "Go Home",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1
                )
            }
        }

        Box(modifier = Modifier.weight(1f)) {
            if (activeTab == "saved") {
            if (list.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(if (isSwahili) "Hakuna fomula zilizohifadhiwa bado." else "No saved recipes found. Optimize and save a formulation first.")
                }
            } else {
                val groupedFormulations = remember(list) {
                    val sdfEn = SimpleDateFormat("MMMM dd, yyyy", Locale.US)
                    val sdfSw = SimpleDateFormat("dd MMMM, yyyy", Locale.forLanguageTag("sw"))
                    list.groupBy { formula ->
                        val dateObj = Date(formula.timestamp)
                        if (isSwahili) sdfSw.format(dateObj) else sdfEn.format(dateObj)
                    }
                }

                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    groupedFormulations.forEach { (dateHeader, formulasInGroup) ->
                        item(key = "header_$dateHeader") {
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 8.dp, bottom = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DateRange,
                                        contentDescription = "File Group Date",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (isSwahili) "📁 Faili la Tarehe: $dateHeader" else "📁 Saved File: $dateHeader",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }

                        items(formulasInGroup, key = { it.id }) { formula ->
                            val isOptimized = formula.title.contains("[Budget Optimized]") || formula.title.lowercase().contains("budget") || formula.title.lowercase().contains("bajeti")
                        val cleanTitle = formula.title
                            .replace(" [Budget Optimized]", "")
                            .replace(" [Standard Log]", "")

                        Card(
                            border = BorderStroke(
                                width = if (isOptimized) 2.dp else 1.5.dp,
                                color = if (isOptimized) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary
                            ),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isOptimized) MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.12f) else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.08f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = cleanTitle,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 16.sp,
                                            color = if (isOptimized) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        
                                        // Badge highlighting the formulation type
                                        Surface(
                                            color = if (isOptimized) MaterialTheme.colorScheme.tertiary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.padding(top = 2.dp)
                                        ) {
                                            Text(
                                                text = if (isOptimized) {
                                                    if (isSwahili) "• FOMULA ILIYOBORESHWA KWA BAJETI" else "• BUDGET OPTIMIZED FORMULA"
                                                } else {
                                                    if (isSwahili) "• FOMULA YA KAWAIDA YA LISHE" else "• STANDARD LEAST-COST FORMULA"
                                                },
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isOptimized) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Row {
                                        IconButton(onClick = {
                                            val shares = viewModel.jsonToShareMap(formula.ingredientSharesJson)
                                            val sharePairList = shares.entries.map { Pair(it.key, it.value.first) }
                                            shareFormulaImage(
                                                context = context,
                                                title = cleanTitle,
                                                birdType = formula.birdType,
                                                stageName = formula.targetStage,
                                                batchWeight = formula.batchWeightKg,
                                                totalCost = formula.totalCost,
                                                ingredients = sharePairList,
                                                unitPrice = formula.costPerKg,
                                                isSwahili = isSwahili
                                            )
                                        }) {
                                            Icon(
                                                imageVector = Icons.Default.Share,
                                                contentDescription = "Share",
                                                tint = if (isOptimized) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary
                                            )
                                        }
                                        IconButton(onClick = { viewModel.deleteFormulation(formula.id) }) {
                                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red)
                                        }
                                    }
                                }

                                Text("${formula.birdType} • ${formula.targetStage} • ${formula.batchWeightKg} Kg", fontSize = 12.sp, color = Color.Gray)
                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Cost/Kg: ${String.format("%.2f", formula.costPerKg)}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Text("Total Cost: ${String.format("%.2f", formula.totalCost)}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }

                                Spacer(modifier = Modifier.height(12.dp))
                                Text(if (isSwahili) "Viungo vilivyotumika:" else "Ingredient fractions used:", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.Gray)
                                
                                val shares = viewModel.jsonToShareMap(formula.ingredientSharesJson)
                                shares.forEach { (tag, info) ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(tag, fontSize = 12.sp)
                                        Text("${String.format("%.1f", info.first)}% (${String.format("%.1f", info.second)} Kg)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                }

                                // Deficiency check and inefficiency advice
                                val achieved = remember(formula.achievedNutrientsJson) { viewModel.jsonToDoubleMap(formula.achievedNutrientsJson) }
                                val matchingTarget = listTargets.find {
                                    it.birdType.lowercase().trim() == formula.birdType.lowercase().trim() &&
                                    (it.stageName.lowercase().trim() == formula.targetStage.lowercase().trim() ||
                                     formula.targetStage.lowercase().contains(it.stageName.split(" ").first().lowercase()))
                                }

                                if (matchingTarget != null && achieved.isNotEmpty()) {
                                    val deficiencies = mutableListOf<String>()
                                    
                                    val achievedCP = achieved["Crude Protein"] ?: 0.0
                                    val targetCP = matchingTarget.crudeProtein
                                    if (achievedCP > 0.0 && achievedCP < targetCP - 0.05) {
                                        val diff = targetCP - achievedCP
                                        val pct = (diff / targetCP) * 100
                                        deficiencies.add(
                                            if (isSwahili) "• Protini (CP) ipo chini ya kiwango kwa ${String.format("%.1f", pct)}%: Kuku watadumaa ukuaji wao na kushindwa kuongezeka uzito ipasavyo."
                                            else "• Crude Protein is low by ${String.format("%.1f", pct)}%: Flock growth remains stunted and thin frame development."
                                        )
                                    }
                                    
                                    val achievedME = achieved["Metabolizable Energy"] ?: 0.0
                                    val targetME = matchingTarget.energy
                                    if (achievedME > 0.0 && achievedME < targetME - 5.0) {
                                        val diff = targetME - achievedME
                                        val pct = (diff / targetME) * 100
                                        deficiencies.add(
                                            if (isSwahili) "• Nishati (ME) ipo chini kwa ${String.format("%.1f", pct)}%: Inaleta njaa zaidi na kuku kula sana bila kuweka nyama mwilini."
                                             else "• Metabolizable Energy is low by ${String.format("%.1f", pct)}%: Causes birds to overeat, wasting feed unnecessarily."
                                        )
                                    }

                                    val achievedCa = achieved["Calcium"] ?: achieved["Calcium (Bone/Shell)"] ?: 0.0
                                    val targetCa = matchingTarget.calcium
                                    if (achievedCa > 0.0 && achievedCa < targetCa - 0.02) {
                                        val diff = targetCa - achievedCa
                                        val pct = (diff / targetCa) * 100
                                        deficiencies.add(
                                            if (isSwahili) "• Madini ya Calcium yapo chini kwa ${String.format("%.1f", pct)}%: Hatari kubwa ya mifupa kulegea (rickets) na maganda ya mayai kuvunjika upesi."
                                            else "• Calcium is low by ${String.format("%.1f", pct)}%: High risk of weak load-bearing bones (rickets) and fragile shell layers."
                                        )
                                    }

                                    val achievedPh = achieved["Phosphorus"] ?: 0.0
                                    val targetPh = matchingTarget.phosphorus
                                    if (achievedPh > 0.0 && achievedPh < targetPh - 0.01) {
                                        val diff = targetPh - achievedPh
                                        val pct = (diff / targetPh) * 100
                                        deficiencies.add(
                                             if (isSwahili) "• Madini ya Phosphorus yapo chini kwa ${String.format("%.1f", pct)}%: Huathiri umeng'enyaji wa nishati mwilini (ATP) na uimara wa mifupa."
                                             else "• Phosphorus is deficient by ${String.format("%.1f", pct)}%: Impacts bone mineralization development and appetite."
                                        )
                                    }

                                    if (deficiencies.isNotEmpty()) {
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Card(
                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f)),
                                            shape = RoundedCornerShape(12.dp),
                                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.35f)),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp)) {
                                                Text(
                                                    text = if (isSwahili) "⚠️ Tahadhari ya Upungufu / Inefficiency Alert:" else "⚠️ Deficiency & Inefficiency Alert:",
                                                    fontWeight = FontWeight.Bold,
                                                      fontSize = 11.sp,
                                                      color = MaterialTheme.colorScheme.error
                                                )
                                                Spacer(modifier = Modifier.height(4.dp))
                                                deficiencies.forEach { warning ->
                                                    Text(
                                                        text = warning,
                                                        fontSize = 10.sp,
                                                        lineHeight = 14.sp,
                                                        color = MaterialTheme.colorScheme.onErrorContainer
                                                    )
                                                }
                                            }
                                        }
                                    } else {
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Card(
                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)),
                                            shape = RoundedCornerShape(12.dp),
                                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
                                            modifier = Modifier.fillMaxWidth()
                                         ) {
                                            Row(
                                                modifier = Modifier.padding(10.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.CheckCircle,
                                                    contentDescription = "Perfect Standard Met",
                                                    tint = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = if (isSwahili) "Mchanganyiko upo sawasawa bila mapungufu!" else "Excellent balance! No critical nutrient deficiencies detected.",
                                                    fontSize = 10.sp,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    } else {
            if (logs.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(if (isSwahili) "Hakuna logi za uzalishaji zilizopatikana." else "Manufacturing logs are empty. Saves auto-record a log.")
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(logs) { log ->
                        val sdf = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())
                        val logDate = sdf.format(Date(log.timestamp))
                        
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(2f)) {
                                    Text(log.formulationTitle, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("Date: $logDate", fontSize = 11.sp, color = Color.Gray)
                                    Text("Deducted stock for: ${log.batchWeightKg} Kg", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                                }
                                Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f)) {
                                    Text("- ${String.format("%.0f", log.totalCost)}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.Red)
                                    Text("${String.format("%.1f", log.batchWeightKg)} Kg", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
        }
    }
}

// --- 7. Inventory Stock Ledger ---
@Composable
fun InventoryScreen(viewModel: PoultryViewModel, isSwahili: Boolean) {
    val stockList by viewModel.inventory.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var selectedEntry by remember { mutableStateOf<FeedInventory?>(null) }
    var adjustAmountText by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = if (isSwahili) "Stoo ya Chakula na Viungo" else "Raw & Formulated Feed Stock Ledger",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (isSwahili) "Sura hii hutenganisha hifadhi yako dhidi ya upotevu mwingi." else "Track stock levels. Formulations automatically deduct raw stock.",
                fontSize = 12.sp,
                color = Color.Gray
            )
        }

        if (stockList.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) {
                    Text(if (isSwahili) "Hakuna data za stoo." else "Inventory Ledger is empty.")
                }
            }
        } else {
            items(stockList) { item ->
                Card(
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.clickable {
                        selectedEntry = item
                        adjustAmountText = "10"
                    }
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(formatIngredientName(item.name, isSwahili), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(
                                text = "Category: ${item.type}",
                                fontSize = 11.sp,
                                color = if (item.type.contains("Ingredient")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "${String.format("%.1f", item.stockKg)} Kg",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp,
                                color = if (item.stockKg < 20.0) Color.Red else MaterialTheme.colorScheme.primary
                            )
                            if (item.stockKg < 20.0) {
                                Text(if (isSwahili) "Chini sana!" else "Low Stock!", fontSize = 10.sp, color = Color.Red, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }

    // Adjust Stock Dialog
    selectedEntry?.let { entry ->
        val focusRequester = remember { FocusRequester() }
        val keyboardController = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current
        LaunchedEffect(Unit) {
            kotlinx.coroutines.delay(150)
            focusRequester.requestFocus()
        }
        Dialog(onDismissRequest = { selectedEntry = null }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = if (isSwahili) "Marekebisho ya Akiba: ${formatIngredientName(entry.name, isSwahili)}" else "Adjust Stock: ${formatIngredientName(entry.name, isSwahili)}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Current Stock: ${entry.stockKg} Kg", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = adjustAmountText,
                        onValueChange = { adjustAmountText = it },
                        label = { Text(if (isSwahili) "Kiasi cha kurekebisha (tumia hasi kupunguza)" else "Amount to adjust (use negative to deduct)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = {
                                val amt = adjustAmountText.toDoubleOrNull()
                                if (amt != null) {
                                    viewModel.adjustInventoryAmount(entry, amt)
                                    selectedEntry = null
                                    Toast.makeText(context.applicationContext, if (isSwahili) "Mstari wa stoo umesasishwa!" else "Stock updated!", Toast.LENGTH_SHORT).show()
                                }
                            }
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .focusRequester(focusRequester)
                            .testTag("stock_adjust_field")
                    )

                    Spacer(modifier = Modifier.height(20.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { selectedEntry = null }) {
                            Text("Cancel")
                        }
                        Button(
                            onClick = {
                                val amt = adjustAmountText.toDoubleOrNull()
                                if (amt != null) {
                                    viewModel.adjustInventoryAmount(entry, amt)
                                    selectedEntry = null
                                    Toast.makeText(context.applicationContext, "Stock updated!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.testTag("stock_adjust_save_btn")
                        ) {
                            Text("Save")
                        }
                    }
                }
            }
        }
    }
}

// --- 8. Profitability Calculator ---
@Composable
fun ProfitabilityScreen(viewModel: PoultryViewModel, isSwahili: Boolean) {
    val flockSize by viewModel.birdCount.collectAsStateWithLifecycle()
    val solverRes by viewModel.solverResult.collectAsStateWithLifecycle()

    val eggPrice by viewModel.eggPricePerTray.collectAsStateWithLifecycle()
    val meatPrice by viewModel.chickenSellingPrice.collectAsStateWithLifecycle()
    val chickPrice by viewModel.dayOldChickCost.collectAsStateWithLifecycle()
    val otherOverhead by viewModel.adminOverheadCost.collectAsStateWithLifecycle()

    val type by viewModel.selectedBirdType.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isSwahili) "Kikokotoo cha Faida (Profitability Projection)" else "Project Poultry Net Profit & ROI",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isSwahili) "Kadiria faida kwa kulinganisha gharama ya malisho." else "Calculates yield profitability vs formulated input costs.",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = chickPrice.toString(),
                        onValueChange = { viewModel.dayOldChickCost.value = it.toDoubleOrNull() ?: 0.0 },
                        label = { Text(if (isSwahili) "Gharama ya Kifaranga kipya" else "Day-Old Chick Purchase Price") },
                        modifier = Modifier.fillMaxWidth().testTag("chick_price_field")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    if (type == "Layer") {
                        OutlinedTextField(
                            value = eggPrice.toString(),
                            onValueChange = { viewModel.eggPricePerTray.value = it.toDoubleOrNull() ?: 0.0 },
                            label = { Text(if (isSwahili) "Bei ya Tray ya Mayai" else "Expected Egg Price per Tray (Est.)") },
                            modifier = Modifier.fillMaxWidth().testTag("egg_tray_price_field")
                        )
                    } else {
                        OutlinedTextField(
                            value = meatPrice.toString(),
                            onValueChange = { viewModel.chickenSellingPrice.value = it.toDoubleOrNull() ?: 0.0 },
                            label = { Text(if (isSwahili) "Bei ya kuku mmoja (Soko)" else "Expected Chicken Selling Price") },
                            modifier = Modifier.fillMaxWidth().testTag("meat_chicken_price_field")
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = otherOverhead.toString(),
                        onValueChange = { viewModel.adminOverheadCost.value = it.toDoubleOrNull() ?: 0.0 },
                        label = { Text(if (isSwahili) "Uvutaji/Dawa kwa kila kuku" else "Other Overhead/Medication per bird") },
                        modifier = Modifier.fillMaxWidth().testTag("other_overhead_field")
                    )
                }
            }
        }

        // Projections Card
        item {
            val costPerKg = solverRes?.costPerKg ?: 40.0
            
            // Core calculations
            val totalPoultryPurchaseCost = flockSize * chickPrice
            val totalOverheadCost = flockSize * otherOverhead
            
            // Cumulative feed consumed over growing lifespan
            val totalFeedDays = if (type == "Broiler") 30 else 140
            val stats = viewModel.getStandardNutritionInfo(type, if (type == "Broiler") 4 else 12)
            val lifetimeFeedPerBirdKg = (stats.dailyFeedInTakeGrams / 1000.0) * totalFeedDays
            val cumulativeFlockFeedUsedKg = flockSize * lifetimeFeedPerBirdKg
            val totalEstimatedFeedCost = cumulativeFlockFeedUsedKg * costPerKg

            val totalWorkingCapital = totalPoultryPurchaseCost + totalOverheadCost + totalEstimatedFeedCost

            // Revenues
            val expectedRevenue = if (type == "Layer") {
                // assume layers lay approx 80% eggs for 30 days
                val totalTrays = (flockSize * 0.8 * 30) / 30.0 // approx trays per month
                totalTrays * eggPrice * 6 // assume 6 months laying season for ROI
            } else {
                // broiler meat sale
                flockSize * 0.95 * meatPrice // 5% mortality estimated
            }

            val netProfit = expectedRevenue - totalWorkingCapital
            val roiPercent = if (totalWorkingCapital > 0) (netProfit / totalWorkingCapital) * 100.0 else 0.0

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isSwahili) "Kadi ya Mapato na ROI" else "Financial Yield Projections",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    RequirementCalculatedItem(if (isSwahili) "Gharama Kuu ya Malisho" else "Est. Cumulative Feed Cost:", String.format("%.0f", totalEstimatedFeedCost))
                    RequirementCalculatedItem(if (isSwahili) "Mtaji Jumla unaohitajika:" else "Total Capital Needed:", String.format("%.0f", totalWorkingCapital))
                    RequirementCalculatedItem(if (isSwahili) "Mapato ya soko makadirio" else "Projected Gross Revenues:", String.format("%.0f", expectedRevenue))
                    
                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(10.dp))

                    RequirementCalculatedItem(if (isSwahili) "Unyasi wa Mtandao (Net Profit):" else "Estimated Net Return:", String.format("%.0f", netProfit))
                    RequirementCalculatedItem(if (isSwahili) "Kurudisha Mtaji (ROI %):" else "Return on Investment (ROI):", String.format("%.1f %%", roiPercent))
                }
            }
        }
    }
}

// --- 9. Settings & Config Screen ---
@Composable
fun SettingsScreen(viewModel: PoultryViewModel, isSwahili: Boolean) {
    val limits by viewModel.inclusionLimits.collectAsStateWithLifecycle()
    val rawIngredients by viewModel.ingredients.collectAsStateWithLifecycle()
    val targets by viewModel.nutrientTargets.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var selectedLimitEntry by remember { mutableStateOf<InclusionLimit?>(null) }
    var minLimitPct by remember { mutableStateOf("") }
    var maxLimitPct by remember { mutableStateOf("") }
    var limitFixedState by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()
    val updateUrl by RemoteUpdateManager.updateUrl.collectAsStateWithLifecycle()
    val updateInfo by RemoteUpdateManager.updateInfo.collectAsStateWithLifecycle()
    val isCheckingUpdate by RemoteUpdateManager.isCheckingUpdate.collectAsStateWithLifecycle()
    val downloadProgress by RemoteUpdateManager.downloadProgress.collectAsStateWithLifecycle()
    val statusMessage by RemoteUpdateManager.statusMessage.collectAsStateWithLifecycle()
    val showUpdateDialog by RemoteUpdateManager.showUpdateDialog.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Theme / Appearance Card
        item {
            val appAppearance by viewModel.appAppearance.collectAsStateWithLifecycle()
            
            Card(
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Palette,
                            contentDescription = "Theme",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isSwahili) "Muonekano wa Skrini" else "App Appearance Theme",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 14.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isSwahili) 
                            "Uamuzi wa rangi ya programu; mfumo unaweza kukumbuka chaguo lako daima." 
                            else "Choose light, dark, or follow your device settings. Your choice is saved automatically.",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        val modes = listOf(
                            Triple("light", if (isSwahili) "Mwanga" else "Light Mode", Icons.Default.LightMode),
                            Triple("dark", if (isSwahili) "Giza" else "Dark Mode", Icons.Default.DarkMode),
                            Triple("system", if (isSwahili) "Mfumo" else "Device Status", Icons.Default.Settings)
                        )
                        
                        modes.forEach { (modeKey, modeTitle, modeIcon) ->
                            val isSelected = appAppearance == modeKey
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                                    .border(
                                        width = 1.dp,
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                    .clickable { viewModel.setAppearance(modeKey) }
                                    .padding(vertical = 12.dp, horizontal = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = modeIcon,
                                        contentDescription = modeTitle,
                                        tint = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = modeTitle,
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // App Home Screen Shortcut / Icon Card
        item {
            Card(
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.08f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Home,
                            contentDescription = "Home Screen Shortcut",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isSwahili) "Weka Kwenye Skrini Kuu" else "Add Icon to Home Screen",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 14.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (isSwahili) 
                            "Njia rahisi ya kufungua programu: Unaweza kuitengeneza kama njia ya mkato kwenye skrini yako kuu ya simu papo hapo kwa kubonyeza kitufe chini, au kuivuta kutoka kwenye orodha ya programu zote."
                            else "Quick launcher access: You can place an icon shortcut on your phone's home screen right away by clicking the button below, or drag it from your App Drawer manually.",
                        fontSize = 11.sp,
                        color = Color.DarkGray,
                        lineHeight = 15.sp
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            if (ShortcutManagerCompat.isRequestPinShortcutSupported(context)) {
                                val intent = Intent(context, com.example.MainActivity::class.java).apply {
                                    action = Intent.ACTION_MAIN
                                    addCategory(Intent.CATEGORY_LAUNCHER)
                                }
                                val shortcut = ShortcutInfoCompat.Builder(context, "smart_poultry_pinned_shortcut")
                                    .setShortLabel("FARMIX")
                                    .setLongLabel(if (isSwahili) "Fomula ya Chakula ya FARMIX" else "FARMIX Poultry Feed Formulator")
                                    .setIcon(IconCompat.createWithResource(context, com.example.R.drawable.ic_launcher_foreground))
                                    .setIntent(intent)
                                    .build()
                                val success = ShortcutManagerCompat.requestPinShortcut(context, shortcut, null)
                                if (success) {
                                    Toast.makeText(
                                        context.applicationContext,
                                        if (isSwahili) "Ombi la kuweka njia ya mkato limeanzishwa kikamilifu!" else "Pinning shortcut request initiated!",
                                        Toast.LENGTH_LONG
                                    ).show()
                                } else {
                                    Toast.makeText(
                                        context.applicationContext,
                                        if (isSwahili) "Njia ya mkato haijaauniwa au imefutwa." else "Pinning shortcut was cancelled.",
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            } else {
                                Toast.makeText(
                                    context.applicationContext,
                                    if (isSwahili) "Kifurushi hiki cha simu hakiauni uwekaji wa njia ya mkato moja kwa moja." else "Your Android launcher does not support direct home screen pinning.",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(42.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Pin Icon", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (isSwahili) "Weka Programu Kwenye Skrini Kuu" else "Create Home Screen Icon")
                    }
                }
            }
        }

        // Remote Wireless App Update Card
        item {
            Card(
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.05f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CloudDownload,
                            contentDescription = "Wireless Remote Update",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isSwahili) "Sasisho la Programu (Wireless Updates)" else "Wireless Remote App Updates",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 14.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isSwahili) 
                            "Sasisha programu yako remotely bila unganisho la USB, kwa upakiaji wa mawingu." 
                            else "Keep your app up to date over-the-air wirelessly without requiring any USB connection.",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = updateUrl,
                        onValueChange = { RemoteUpdateManager.updateUrl.value = it },
                        label = { Text(if (isSwahili) "Kiungo cha seva ya sasisho (Update Source URL)" else "Manifest Update endpoint URL") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().testTag("app_update_url_input"),
                        leadingIcon = { Icon(Icons.Default.Link, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    if (isCheckingUpdate) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth().padding(8.dp)
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isSwahili) "Inatafuta sasisho la toleo jipya..." else "Checking web repository versions...",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    } else {
                        Button(
                            onClick = {
                                RemoteUpdateManager.isCheckingUpdate.value = true
                                scope.launch {
                                    try {
                                        val info = RemoteUpdateManager.checkUpdates(context, updateUrl)
                                        RemoteUpdateManager.updateInfo.value = info
                                        if (info.isUpdateAvailable) {
                                            RemoteUpdateManager.showUpdateDialog.value = true
                                        } else {
                                            val msg = if (isSwahili) "Programu yako ipo kwenye toleo jipya zaidi!" else "Your app is already up to date!"
                                            Toast.makeText(context.applicationContext, msg, Toast.LENGTH_LONG).show()
                                        }
                                    } catch (e: Exception) {
                                        Toast.makeText(context.applicationContext, e.localizedMessage ?: "Connection error", Toast.LENGTH_SHORT).show()
                                    } finally {
                                        RemoteUpdateManager.isCheckingUpdate.value = false
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(42.dp).testTag("check_remote_update_btn"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Refresh", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isSwahili) "Angalia Sasisho la Leo" else "Check For Remote Updates")
                        }
                    }

                    // Display download in-progress beautifully
                    downloadProgress?.let { progress ->
                        Spacer(modifier = Modifier.height(14.dp))
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = statusMessage,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                                Text(
                                    text = "${(progress * 100).toInt()}%",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = { progress },
                                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                                color = MaterialTheme.colorScheme.primary,
                                trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                            )
                        }
                    }
                }
            }
        }

        // Inclusion limits Card
        item {
            Card(
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isSwahili) "Mipango ya Vizuuzi ya Viungo" else "Edit Ingredient Inclusion Limits",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isSwahili) "Gusa ili uhariri mipaka thabiti ya madini kama Salt na Fish meal." else "Configure rules. Respect safety of salt and premix concentrations.",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    limits.forEach { limit ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedLimitEntry = limit
                                    minLimitPct = limit.minPercent.toString()
                                    maxLimitPct = limit.maxPercent.toString()
                                    limitFixedState = limit.isFixed
                                }
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(limit.ingredientName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(
                                    text = if (limit.isFixed) "Fixed Level Value" else "Range Target Margin",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                            Text(
                                text = if (limit.isFixed) "${limit.minPercent}%" else "${limit.minPercent}% - ${limit.maxPercent}%",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }

        // Custom Add Ingredient Form
        item {
            CustomIngredientFormCard(viewModel, isSwahili)
        }
    }

    // Limit Editor Dialog
    selectedLimitEntry?.let { entry ->
        val focusRequester = remember { FocusRequester() }
        val keyboardController = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current
        LaunchedEffect(Unit) {
            kotlinx.coroutines.delay(150)
            focusRequester.requestFocus()
        }
        Dialog(onDismissRequest = { selectedLimitEntry = null }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Edit Rules: ${entry.ingredientName}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = minLimitPct,
                            onValueChange = { minLimitPct = it },
                            label = { Text("Min %") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Number,
                                imeAction = ImeAction.Done
                            ),
                            keyboardActions = KeyboardActions(
                                onDone = {
                                    val minD = minLimitPct.toDoubleOrNull()
                                    val maxD = maxLimitPct.toDoubleOrNull()
                                    if (minD != null && maxD != null) {
                                        viewModel.updateInclusionLimit(entry.ingredientName, minD, maxD, limitFixedState)
                                        selectedLimitEntry = null
                                        Toast.makeText(context.applicationContext, "Limit Rules updated!", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .focusRequester(focusRequester)
                                .testTag("limit_min_field")
                        )
                        OutlinedTextField(
                            value = maxLimitPct,
                            onValueChange = { maxLimitPct = it },
                            label = { Text("Max %") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Number,
                                imeAction = ImeAction.Done
                            ),
                            keyboardActions = KeyboardActions(
                                onDone = {
                                    val minD = minLimitPct.toDoubleOrNull()
                                    val maxD = maxLimitPct.toDoubleOrNull()
                                    if (minD != null && maxD != null) {
                                        viewModel.updateInclusionLimit(entry.ingredientName, minD, maxD, limitFixedState)
                                        selectedLimitEntry = null
                                        Toast.makeText(context.applicationContext, "Limit Rules updated!", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            ),
                            modifier = Modifier.weight(1f).testTag("limit_max_field")
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = limitFixedState, onCheckedChange = { limitFixedState = it })
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Fixed Inclusion Percent Level", fontSize = 12.sp)
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                    Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                        TextButton(onClick = { selectedLimitEntry = null }) {
                            Text("Cancel")
                        }
                        Button(
                            onClick = {
                                val minD = minLimitPct.toDoubleOrNull()
                                val maxD = maxLimitPct.toDoubleOrNull()
                                if (minD != null && maxD != null) {
                                    viewModel.updateInclusionLimit(entry.ingredientName, minD, maxD, limitFixedState)
                                    selectedLimitEntry = null
                                    Toast.makeText(context.applicationContext, "Limit Rules updated!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.testTag("limit_save_btn")
                        ) {
                            Text("Save")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CustomIngredientFormCard(viewModel: PoultryViewModel, isSwahili: Boolean) {
    val context = LocalContext.current
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Energy") }
    
    var cp by remember { mutableStateOf("10.0") }
    var me by remember { mutableStateOf("3000") }
    var ca by remember { mutableStateOf("0.5") }
    var p by remember { mutableStateOf("0.4") }
    var lys by remember { mutableStateOf("0.1") }
    var met by remember { mutableStateOf("0.05") }
    var cf by remember { mutableStateOf("2.0") }
    var cost by remember { mutableStateOf("45") }

    Card(
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = if (isSwahili) "Ongeza Kiungo Kipya (Custom)" else "Add Custom Ingredient Feed Profile",
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Ingredient Name") },
                modifier = Modifier.fillMaxWidth().testTag("custom_ing_name")
            )

            Spacer(modifier = Modifier.height(10.dp))
            Text("Category:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                listOf("Energy", "Protein", "Mineral", "Additive").forEach { cat ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (category == cat) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { category = cat }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(cat, color = if (category == cat) Color.White else Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = cp, onValueChange = { cp = it }, label = { Text("CP %") }, modifier = Modifier.weight(1f))
                OutlinedTextField(value = me, onValueChange = { me = it }, label = { Text("ME kcal/g") }, modifier = Modifier.weight(1f))
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = ca, onValueChange = { ca = it }, label = { Text("Ca %") }, modifier = Modifier.weight(1f))
                OutlinedTextField(value = p, onValueChange = { p = it }, label = { Text("P %") }, modifier = Modifier.weight(1f))
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = lys, onValueChange = { lys = it }, label = { Text("Lysine %") }, modifier = Modifier.weight(1f))
                OutlinedTextField(value = met, onValueChange = { met = it }, label = { Text("Meth %") }, modifier = Modifier.weight(1f))
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = cf, onValueChange = { cf = it }, label = { Text("Fiber %") }, modifier = Modifier.weight(1f))
                OutlinedTextField(
                    value = cost,
                    onValueChange = { cost = it },
                    label = { Text(if (isSwahili) "Bei/Kg" else "Price/Kg") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            if (name.isNotBlank()) {
                                viewModel.addCustomIngredient(
                                    name = name,
                                    category = category,
                                    cp = cp.toDoubleOrNull() ?: 0.0,
                                    me = me.toDoubleOrNull() ?: 0.0,
                                    ca = ca.toDoubleOrNull() ?: 0.0,
                                    p = p.toDoubleOrNull() ?: 0.0,
                                    lys = lys.toDoubleOrNull() ?: 0.0,
                                    met = met.toDoubleOrNull() ?: 0.0,
                                    cf = cf.toDoubleOrNull() ?: 0.0,
                                    price = cost.toDoubleOrNull() ?: 0.0
                                )
                                name = "" // reset
                                Toast.makeText(context.applicationContext, if (isSwahili) "Kiungo kimefanywa upya kikamilifu!" else "Added custom ingredient successfully!", Toast.LENGTH_SHORT).show()
                            }
                        }
                    ),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        viewModel.addCustomIngredient(
                            name = name,
                            category = category,
                            cp = cp.toDoubleOrNull() ?: 0.0,
                            me = me.toDoubleOrNull() ?: 0.0,
                            ca = ca.toDoubleOrNull() ?: 0.0,
                            p = p.toDoubleOrNull() ?: 0.0,
                            lys = lys.toDoubleOrNull() ?: 0.0,
                            met = met.toDoubleOrNull() ?: 0.0,
                            cf = cf.toDoubleOrNull() ?: 0.0,
                            price = cost.toDoubleOrNull() ?: 0.0
                        )
                        name = "" // reset
                        Toast.makeText(context.applicationContext, "Added custom ingredient successfully!", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.fillMaxWidth().testTag("add_custom_ing_btn"),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(if (isSwahili) "Ongeza Kiungo Kipya" else "Add Custom Profile")
            }
        }
    }
}

@Composable
fun MaterialPriceScreen(
    viewModel: PoultryViewModel,
    isSwahili: Boolean,
    onSaveComplete: () -> Unit = {}
) {
    val rawIngredients by viewModel.ingredients.collectAsStateWithLifecycle()
    val allStores by viewModel.allStores.collectAsStateWithLifecycle()
    val activeStoreId by viewModel.selectedStoreId.collectAsStateWithLifecycle()
    val activeStorePrices by viewModel.activeStorePrices.collectAsStateWithLifecycle()

    // Local state to track which store is currently being viewed/edited for prices.
    // Starts as null so the user is directed to the saved stores list first.
    var selectedStoreIdForPrices by remember { mutableStateOf<Int?>(null) }
    val activeStore = allStores.find { it.id == selectedStoreIdForPrices }

    // Categorize materials by class
    val energyList = rawIngredients.filter { ing ->
        val nameLower = ing.name.lowercase()
        ing.category.lowercase() == "energy" || 
        nameLower.contains("maize") || nameLower.contains("rice") || 
        nameLower.contains("wheat") || nameLower.contains("bran") || 
        nameLower.contains("pollard") || nameLower.contains("millet")
    }
    
    val proteinList = rawIngredients.filter { ing ->
        val nameLower = ing.name.lowercase()
        ing.category.lowercase() == "protein" || 
        nameLower.contains("soybean") || nameLower.contains("sunflower") || 
        nameLower.contains("fish") || nameLower.contains("cotton") || 
        nameLower.contains("omena") || nameLower.contains("blood")
    }

    val mineralList = rawIngredients.filter { ing ->
        val nameLower = ing.name.lowercase()
        ing.category.lowercase() == "mineral" || 
        nameLower.contains("limestone") || nameLower.contains("dcp") || 
        nameLower.contains("salt") || nameLower.contains("calcium") || 
        nameLower.contains("shell") || nameLower.contains("bone")
    }

    val otherList = rawIngredients.filter { ing ->
        ing !in energyList && ing !in proteinList && ing !in mineralList
    }

    var showCreateStoreDialog by remember { mutableStateOf(false) }
    var newStoreName by remember { mutableStateOf("") }
    var storeDropdownInCreateDialogExpanded by remember { mutableStateOf(false) }
    var showDropdownOptionInDialog by remember { mutableStateOf(true) }

    // Dialog states for renaming/deleting stores and adding/deleting ingredients
    var showRenameStoreDialog by remember { mutableStateOf<Store?>(null) }
    var renameStoreName by remember { mutableStateOf("") }
    var showDeleteStoreDialog by remember { mutableStateOf<Store?>(null) }
    var showAddIngredientDialog by remember { mutableStateOf(false) }
    var showDeleteIngredientDialog by remember { mutableStateOf<Ingredient?>(null) }
    var editingIngredientForPrice by remember { mutableStateOf<Ingredient?>(null) }

    // local mutable map to track prices currently typed in text inputs
    val enteredPrices = remember { mutableStateMapOf<String, String>() }
    val context = LocalContext.current

    // Trigger showing the create store dialog if no stores exist yet
    LaunchedEffect(Unit) {
        val stores = viewModel.getAllStoresAsync()
        if (stores.isEmpty()) {
            newStoreName = ""
            showDropdownOptionInDialog = false
            showCreateStoreDialog = true
        }
    }

    // Load prices from rawIngredients when ingredients or active store changes
    LaunchedEffect(rawIngredients, selectedStoreIdForPrices) {
        enteredPrices.clear()
        rawIngredients.forEach { ing ->
            if (ing.pricePerKg > 0.0) {
                enteredPrices[ing.name] = String.format(Locale.US, "%.0f", ing.pricePerKg)
            } else {
                enteredPrices[ing.name] = ""
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (selectedStoreIdForPrices == null) {
            // Screen 1: Saved Stores list & Option to Add Store
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isSwahili) "Maduka Yaliyohifadhiwa" else "Saved Stores",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )

                IconButton(
                    onClick = {
                        newStoreName = ""
                        showDropdownOptionInDialog = false
                        showCreateStoreDialog = true
                    },
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.primaryContainer, CircleShape)
                        .size(40.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Store",
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Text(
                text = if (isSwahili) 
                    "Chagua duka ili uone au uandike bei za viungo vyake vya chakula cha kuku." 
                    else "Select a store to view or enter its ingredient prices.",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.Gray
            )

            Spacer(modifier = Modifier.height(8.dp))

            if (allStores.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Store,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = if (isSwahili) "Hakuna duka lililohifadhiwa bado!" else "No saved stores yet!",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isSwahili) "Bofya kitufe cha '+' hapo juu ili kuunda la kwanza." else "Click the '+' button above to create your first store.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(allStores) { store ->
                        var menuExpanded by remember { mutableStateOf(false) }
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedStoreIdForPrices = store.id
                                    viewModel.selectStore(store.id)
                                },
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    modifier = Modifier.weight(1f),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Store,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(28.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = store.name,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Box {
                                        IconButton(onClick = { menuExpanded = true }) {
                                            Icon(
                                                imageVector = Icons.Default.MoreVert,
                                                contentDescription = "Store Options",
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }

                                        DropdownMenu(
                                            expanded = menuExpanded,
                                            onDismissRequest = { menuExpanded = false }
                                        ) {
                                            DropdownMenuItem(
                                                leadingIcon = {
                                                    Icon(
                                                        imageVector = Icons.AutoMirrored.Filled.List,
                                                        contentDescription = null,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                },
                                                text = { Text(if (isSwahili) "Hariri Duka (Vifaa na Bei)" else "Edit Store (Materials & Prices)") },
                                                onClick = {
                                                    menuExpanded = false
                                                    selectedStoreIdForPrices = store.id
                                                    viewModel.selectStore(store.id)
                                                }
                                            )
                                            DropdownMenuItem(
                                                leadingIcon = {
                                                    Icon(
                                                        imageVector = Icons.Default.Edit,
                                                        contentDescription = null,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                },
                                                text = { Text(if (isSwahili) "Badili Jina la Duka" else "Rename Store") },
                                                onClick = {
                                                    menuExpanded = false
                                                    renameStoreName = store.name
                                                    showRenameStoreDialog = store
                                                }
                                            )
                                            DropdownMenuItem(
                                                leadingIcon = {
                                                    Icon(
                                                        imageVector = Icons.Default.Delete,
                                                        contentDescription = null,
                                                        tint = MaterialTheme.colorScheme.error,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                },
                                                text = { 
                                                    Text(
                                                        text = if (isSwahili) "Futa Duka" else "Delete Store",
                                                        color = MaterialTheme.colorScheme.error
                                                    ) 
                                                },
                                                onClick = {
                                                    menuExpanded = false
                                                    showDeleteStoreDialog = store
                                                }
                                            )
                                        }
                                    }

                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                        contentDescription = "View Store Prices",
                                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Screen 2: Materials List for the selected store
            // Header with Back button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { selectedStoreIdForPrices = null },
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                        .size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back to Stores",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isSwahili) "Bei za Duka" else "Store Price List",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = activeStore?.name ?: "",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                IconButton(
                    onClick = { showAddIngredientDialog = true },
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.secondaryContainer, CircleShape)
                        .size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Custom Material",
                        tint = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Description card
            Card(
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Info",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isSwahili)
                            "Weka bei kwa kilo ya viungo kwenye duka hili na weka tiki kuchagua viungo vilivyopo."
                            else "Enter prices per kg for this store, and check the box to select items found available.",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
            }

            // LazyColumn showing categorised materials
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (rawIngredients.isEmpty()) {
                    item {
                        Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                            Text(if (isSwahili) "Hakuna viungo vilivyopatikana." else "No active ingredients found.")
                        }
                    }
                } else {
                    // Category 1: Energy Sources
                    if (energyList.isNotEmpty()) {
                        item {
                            CategoryHeaderRow(
                                title = if (isSwahili) "Vyanzo vya Nishati (Energy)" else "Energy Sources",
                                icon = Icons.Default.Bolt,
                                color = Color(0xFFFFB300)
                            )
                        }
                        items(energyList) { ing ->
                            val isSaved = activeStorePrices.any { it.ingredientName.lowercase().trim() == ing.name.lowercase().trim() }
                            val priceText = enteredPrices[ing.name] ?: ""
                            MaterialPriceRow(
                                ing = ing,
                                priceText = priceText,
                                isSwahili = isSwahili,
                                isExplicitlySaved = isSaved,
                                onClick = { editingIngredientForPrice = ing },
                                onDeleteClick = { showDeleteIngredientDialog = it }
                            )
                        }
                    }

                    // Category 2: Protein Sources
                    if (proteinList.isNotEmpty()) {
                        item {
                            CategoryHeaderRow(
                                title = if (isSwahili) "Vyanzo vya Protini (Protein)" else "Protein Sources",
                                icon = Icons.Default.Eco,
                                color = Color(0xFFEF9A9A)
                            )
                        }
                        items(proteinList) { ing ->
                            val isSaved = activeStorePrices.any { it.ingredientName.lowercase().trim() == ing.name.lowercase().trim() }
                            val priceText = enteredPrices[ing.name] ?: ""
                            MaterialPriceRow(
                                ing = ing,
                                priceText = priceText,
                                isSwahili = isSwahili,
                                isExplicitlySaved = isSaved,
                                onClick = { editingIngredientForPrice = ing },
                                onDeleteClick = { showDeleteIngredientDialog = it }
                            )
                        }
                    }

                    // Category 3: Minerals & Salts
                    if (mineralList.isNotEmpty()) {
                        item {
                            CategoryHeaderRow(
                                title = if (isSwahili) "Madini na Chumvi (Minerals)" else "Minerals & Salts",
                                icon = Icons.Default.Layers,
                                color = Color(0xFF81D4FA)
                            )
                        }
                        items(mineralList) { ing ->
                            val isSaved = activeStorePrices.any { it.ingredientName.lowercase().trim() == ing.name.lowercase().trim() }
                            val priceText = enteredPrices[ing.name] ?: ""
                            MaterialPriceRow(
                                ing = ing,
                                priceText = priceText,
                                isSwahili = isSwahili,
                                isExplicitlySaved = isSaved,
                                onClick = { editingIngredientForPrice = ing },
                                onDeleteClick = { showDeleteIngredientDialog = it }
                            )
                        }
                    }

                    // Category 4: Others/Additives
                    if (otherList.isNotEmpty()) {
                        item {
                            CategoryHeaderRow(
                                title = if (isSwahili) "Virutubisho vya Nyongeza (Additives)" else "Inclusion Additives & Premixes",
                                icon = Icons.Default.AddCircle,
                                color = Color(0xFFA5D6A7)
                            )
                        }
                        items(otherList) { ing ->
                            val isSaved = activeStorePrices.any { it.ingredientName.lowercase().trim() == ing.name.lowercase().trim() }
                            val priceText = enteredPrices[ing.name] ?: ""
                            MaterialPriceRow(
                                ing = ing,
                                priceText = priceText,
                                isSwahili = isSwahili,
                                isExplicitlySaved = isSaved,
                                onClick = { editingIngredientForPrice = ing },
                                onDeleteClick = { showDeleteIngredientDialog = it }
                            )
                        }
                    }
                    
                    // Extra padding at the bottom for scroll
                    item {
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            }

            // Save prices & exit button (NO icon, clean design)
            Button(
                onClick = {
                    val storeId = selectedStoreIdForPrices ?: return@Button
                    enteredPrices.forEach { (name, text) ->
                        val priceVal = text.toDoubleOrNull() ?: 0.0
                        viewModel.updateStorePrice(storeId, name, priceVal)
                    }
                    Toast.makeText(
                        context.applicationContext,
                        if (isSwahili) "Bei zote zimehifadhiwa kwa duka '${activeStore?.name}'!" else "All prices saved for store '${activeStore?.name}'!",
                        Toast.LENGTH_SHORT
                    ).show()
                    onSaveComplete()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("save_all_prices_button"),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = if (isSwahili) "Hifadhi Bei na Toka" else "Save Prices & Exit",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Color.White
                )
            }
        }
    }

    // Pop-up price entry Dialog for selected material
    if (editingIngredientForPrice != null) {
        val ing = editingIngredientForPrice!!
        val currentTypedPrice = enteredPrices[ing.name] ?: ""
        var priceInput by remember(ing.name) { mutableStateOf(currentTypedPrice) }
        val focusRequester = remember(ing.name) { FocusRequester() }
        val keyboardController = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current
        LaunchedEffect(ing.name) {
            kotlinx.coroutines.delay(150)
            focusRequester.requestFocus()
        }

        AlertDialog(
            onDismissRequest = { editingIngredientForPrice = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isSwahili) "Weka Bei: ${formatIngredientName(ing.name, isSwahili)}" else "Enter Price: ${formatIngredientName(ing.name, isSwahili)}",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = if (isSwahili) 
                            "Weka bei ya sasa kwa kila kilo (TSh/Kg) ya kiungo hiki kwenye duka hili."
                            else "Enter the current price per kilogram (TSh/Kg) for this ingredient at this store.",
                        fontSize = 12.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    
                    OutlinedTextField(
                        value = priceInput,
                        onValueChange = { priceInput = it },
                        label = { Text(if (isSwahili) "Bei (TSh/Kg)" else "Price (TSh/Kg)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = {
                                val storeId = selectedStoreIdForPrices
                                val priceVal = priceInput.toDoubleOrNull() ?: 0.0
                                enteredPrices[ing.name] = priceInput
                                
                                if (storeId != null) {
                                    viewModel.updateStorePrice(storeId, ing.name, priceVal)
                                }
                                
                                Toast.makeText(
                                    context.applicationContext,
                                    if (isSwahili) "Bei imehifadhiwa kwa ${formatIngredientName(ing.name, isSwahili)}!" else "Price saved for ${formatIngredientName(ing.name, isSwahili)}!",
                                    Toast.LENGTH_SHORT
                                ).show()
                                editingIngredientForPrice = null
                            }
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .focusRequester(focusRequester)
                            .testTag("dialog_price_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val storeId = selectedStoreIdForPrices
                        val priceVal = priceInput.toDoubleOrNull() ?: 0.0
                        enteredPrices[ing.name] = priceInput
                        
                        if (storeId != null) {
                            viewModel.updateStorePrice(storeId, ing.name, priceVal)
                        }
                        
                        Toast.makeText(
                            context.applicationContext,
                            if (isSwahili) "Bei imehifadhiwa kwa ${formatIngredientName(ing.name, isSwahili)}!" else "Price saved for ${formatIngredientName(ing.name, isSwahili)}!",
                            Toast.LENGTH_SHORT
                        ).show()
                        editingIngredientForPrice = null
                    }
                ) {
                    Text(if (isSwahili) "Hifadhi" else "Save")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { editingIngredientForPrice = null }
                ) {
                    Text(if (isSwahili) "Ghairi" else "Cancel")
                }
            }
        )
    }

    // Create New Store Dialog Pop-up
    if (showCreateStoreDialog) {
        val focusRequester = remember { FocusRequester() }
        val keyboardController = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current
        LaunchedEffect(Unit) {
            kotlinx.coroutines.delay(150)
            focusRequester.requestFocus()
        }
        AlertDialog(
            onDismissRequest = { 
                showCreateStoreDialog = false
            },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Store,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isSwahili) "Orodha ya Bei" else "Store Price List",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    IconButton(
                        onClick = { showCreateStoreDialog = false }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Cancel",
                            tint = Color.Gray
                        )
                    }
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = if (showDropdownOptionInDialog) {
                            if (isSwahili) 
                                "Weka au chagua jina la duka (k.m. 'zakhem 1') ili uunde/uone orodha yake ya bei."
                                else "Enter or select a store name (e.g. 'zakhem 1') to create or manage its price list."
                        } else {
                            if (isSwahili) 
                                "Weka jina la duka la muuzaji (k.m. 'zakhem 1') ili uunde orodha yake ya bei."
                                else "Enter the store/seller name (e.g. 'zakhem 1') to manage its independent price list."
                        },
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = newStoreName,
                            onValueChange = { newStoreName = it },
                            label = { Text(if (isSwahili) "Jina la Duka" else "Store Name") },
                            placeholder = {
                                Text(
                                    if (showDropdownOptionInDialog) {
                                        if (isSwahili) "Ingiza au chagua duka..." else "e.g. zakhem 1"
                                    } else {
                                        if (isSwahili) "Ingiza jina la duka..." else "e.g. zakhem 1"
                                    }
                                )
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            trailingIcon = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (newStoreName.isNotEmpty()) {
                                        IconButton(onClick = { newStoreName = "" }) {
                                            Icon(
                                                imageVector = Icons.Default.Close,
                                                contentDescription = "Clear/Cancel",
                                                tint = Color.Gray,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                    if (showDropdownOptionInDialog) {
                                        IconButton(onClick = { storeDropdownInCreateDialogExpanded = true }) {
                                            Icon(
                                                imageVector = Icons.Default.ArrowDropDown,
                                                contentDescription = "Select saved stores",
                                                tint = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .focusRequester(focusRequester)
                                .testTag("new_store_name_input")
                        )

                        if (showDropdownOptionInDialog) {
                            DropdownMenu(
                                expanded = storeDropdownInCreateDialogExpanded,
                                onDismissRequest = { storeDropdownInCreateDialogExpanded = false },
                                modifier = Modifier.fillMaxWidth(0.9f)
                            ) {
                                DropdownMenuItem(
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Default.Add,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    },
                                    text = { 
                                        Text(
                                            text = if (isSwahili) "Unda orodha mpya ya bei za duka" else "Create new store price list",
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        ) 
                                    },
                                    onClick = {
                                        newStoreName = ""
                                        storeDropdownInCreateDialogExpanded = false
                                    }
                                )

                                if (allStores.isNotEmpty()) {
                                    HorizontalDivider(
                                        modifier = Modifier.padding(vertical = 4.dp),
                                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
                                    )
                                    Text(
                                        text = if (isSwahili) "Jaza jina kutoka maduka yaliyohifadhiwa:" else "Fill Name from Saved Stores:",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.Gray,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                    )
                                    allStores.forEach { store ->
                                        DropdownMenuItem(
                                            leadingIcon = {
                                                Icon(
                                                    imageVector = Icons.Default.Store,
                                                    contentDescription = null,
                                                    tint = Color.Gray
                                                )
                                            },
                                            text = { Text(store.name) },
                                            onClick = {
                                                newStoreName = store.name
                                                storeDropdownInCreateDialogExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newStoreName.isNotBlank()) {
                            viewModel.createAndSelectStore(newStoreName.trim()) { newId ->
                                Toast.makeText(
                                    context.applicationContext,
                                    if (isSwahili) "Duka la '${newStoreName.trim()}' limeundwa!" else "Store '${newStoreName.trim()}' created successfully!",
                                    Toast.LENGTH_SHORT
                                ).show()
                                showCreateStoreDialog = false
                                newStoreName = ""
                                selectedStoreIdForPrices = newId
                            }
                        } else {
                            Toast.makeText(
                                context.applicationContext,
                                if (isSwahili) "Tafadhali weka jina!" else "Please enter a valid store name!",
                                Toast.LENGTH_SHORT
                                ).show()
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text(if (isSwahili) "Hifadhi & Chagua" else "Save & Select")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateStoreDialog = false }) {
                    Text(if (isSwahili) "Ghairi" else "Cancel")
                }
            },
            shape = RoundedCornerShape(24.dp)
        )
    }

    // Rename Store Dialog
    if (showRenameStoreDialog != null) {
        val storeToRename = showRenameStoreDialog!!
        val focusRequester = remember { FocusRequester() }
        val keyboardController = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current
        LaunchedEffect(Unit) {
            kotlinx.coroutines.delay(150)
            focusRequester.requestFocus()
        }
        AlertDialog(
            onDismissRequest = { showRenameStoreDialog = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isSwahili) "Badili Jina la Duka" else "Rename Store",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = if (isSwahili) 
                            "Ingiza jina jipya la duka la muuzaji hapa chini:"
                            else "Enter the new name for this store/seller below:",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = renameStoreName,
                        onValueChange = { renameStoreName = it },
                        label = { Text(if (isSwahili) "Jina Jipya la Duka" else "New Store Name") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .focusRequester(focusRequester)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val nameClean = renameStoreName.trim()
                        if (nameClean.isNotBlank()) {
                            viewModel.renameStore(storeToRename, nameClean)
                            Toast.makeText(
                                context.applicationContext,
                                if (isSwahili) "Jina limebadilishwa kuwa '${nameClean}'!" else "Store renamed to '${nameClean}'!",
                                Toast.LENGTH_SHORT
                            ).show()
                            showRenameStoreDialog = null
                        } else {
                            Toast.makeText(
                                context.applicationContext,
                                if (isSwahili) "Tafadhali weka jina!" else "Please enter a valid store name!",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(if (isSwahili) "Hifadhi" else "Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRenameStoreDialog = null }) {
                    Text(if (isSwahili) "Ghairi" else "Cancel")
                }
            },
            shape = RoundedCornerShape(24.dp)
        )
    }

    // Delete Store Confirmation Dialog
    if (showDeleteStoreDialog != null) {
        val storeToDelete = showDeleteStoreDialog!!
        AlertDialog(
            onDismissRequest = { showDeleteStoreDialog = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isSwahili) "Futa Duka" else "Delete Store",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            },
            text = {
                Text(
                    text = if (isSwahili) 
                        "Je, una uhakika unataka kufuta duka la '${storeToDelete.name}'? Bei zote zilizohifadhiwa kwa duka hili zitafutwa kabisa."
                        else "Are you sure you want to delete the store '${storeToDelete.name}'? All prices saved for this store will be permanently deleted.",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteStore(storeToDelete)
                        Toast.makeText(
                            context.applicationContext,
                            if (isSwahili) "Duka limefutwa!" else "Store deleted successfully!",
                            Toast.LENGTH_SHORT
                        ).show()
                        showDeleteStoreDialog = null
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text(if (isSwahili) "Futa" else "Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteStoreDialog = null }) {
                    Text(if (isSwahili) "Ghairi" else "Cancel")
                }
            },
            shape = RoundedCornerShape(24.dp)
        )
    }

    // Add Custom Material Dialog
    if (showAddIngredientDialog) {
        var newIngName by remember { mutableStateOf("") }
        var newIngCategory by remember { mutableStateOf("Energy") }
        var newIngPriceText by remember { mutableStateOf("") }
        var categoryDropdownExpanded by remember { mutableStateOf(false) }

        val categories = listOf("Energy", "Protein", "Mineral", "Additive")
        val categoryLabelsEn = listOf("Energy Source", "Protein Source", "Mineral / Salt", "Additive / Premix")
        val categoryLabelsSw = listOf("Chanzo cha Nishati", "Chanzo cha Protini", "Madini / Chumvi", "Nyongeza / Premix")

                val focusRequester = remember { FocusRequester() }
        val keyboardController = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current
        LaunchedEffect(Unit) {
            kotlinx.coroutines.delay(150)
            focusRequester.requestFocus()
        }

        AlertDialog(
            onDismissRequest = { showAddIngredientDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AddCircle,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isSwahili) "Ongeza Kifaa Kipya" else "Add New Material",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = if (isSwahili) 
                            "Weka jina na bei kwa kila kilo ya kifaa kipya ili uanze kukitumia kwenye fomula zako."
                            else "Enter the name, category, and price for this material to start using it in your formulas.",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )

                    OutlinedTextField(
                        value = newIngName,
                        onValueChange = { newIngName = it },
                        label = { Text(if (isSwahili) "Jina la Kifaa" else "Material Name") },
                        placeholder = { Text(if (isSwahili) "k.m. Mashudu ya Alizeti" else "e.g. Sunflower Meal") },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .focusRequester(focusRequester)
                    )

                    // Category dropdown
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = if (isSwahili) {
                                categoryLabelsSw[categories.indexOf(newIngCategory).coerceIn(0, 3)]
                            } else {
                                categoryLabelsEn[categories.indexOf(newIngCategory).coerceIn(0, 3)]
                            },
                            onValueChange = {},
                            readOnly = true,
                            label = { Text(if (isSwahili) "Kundi (Aina)" else "Category (Type)") },
                            trailingIcon = {
                                IconButton(onClick = { categoryDropdownExpanded = true }) {
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = "Select Category")
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { categoryDropdownExpanded = true }
                        )

                        DropdownMenu(
                            expanded = categoryDropdownExpanded,
                            onDismissRequest = { categoryDropdownExpanded = false }
                        ) {
                            categories.forEachIndexed { index, cat ->
                                DropdownMenuItem(
                                    text = { 
                                        Text(if (isSwahili) categoryLabelsSw[index] else categoryLabelsEn[index]) 
                                    },
                                    onClick = {
                                        newIngCategory = cat
                                        categoryDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = newIngPriceText,
                        onValueChange = { newIngPriceText = it },
                        label = { Text(if (isSwahili) "Bei kwa Kilo (TSh)" else "Price per Kg (TSh)") },
                        placeholder = { Text("e.g. 800") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val nameClean = newIngName.trim()
                        val priceVal = newIngPriceText.toDoubleOrNull() ?: 0.0
                        if (nameClean.isBlank()) {
                            Toast.makeText(
                                context.applicationContext,
                                if (isSwahili) "Tafadhali ingiza jina la kifaa!" else "Please enter a material name!",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@Button
                        }
                        if (priceVal <= 0.0) {
                            Toast.makeText(
                                context.applicationContext,
                                if (isSwahili) "Tafadhali weka bei sahihi ya duka!" else "Please enter a valid price!",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@Button
                        }

                        // Add to master ingredients
                        viewModel.addCustomIngredient(
                            name = nameClean,
                            category = newIngCategory,
                            cp = 0.0,
                            me = 0.0,
                            ca = 0.0,
                            p = 0.0,
                            lys = 0.0,
                            met = 0.0,
                            cf = 0.0,
                            price = priceVal
                        )

                        // Also save for the current store
                        val storeId = selectedStoreIdForPrices
                        if (storeId != null) {
                            viewModel.updateStorePrice(storeId, nameClean, priceVal)
                            enteredPrices[nameClean] = String.format(Locale.US, "%.0f", priceVal)
                        }

                        Toast.makeText(
                            context.applicationContext,
                            if (isSwahili) "Kifaa '${nameClean}' kimeongezwa!" else "Material '${nameClean}' added successfully!",
                            Toast.LENGTH_SHORT
                        ).show()
                        showAddIngredientDialog = false
                    },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(if (isSwahili) "Hifadhi" else "Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddIngredientDialog = false }) {
                    Text(if (isSwahili) "Ghairi" else "Cancel")
                }
            },
            shape = RoundedCornerShape(24.dp)
        )
    }

    // Delete Material Confirmation Dialog
    if (showDeleteIngredientDialog != null) {
        val ingToDelete = showDeleteIngredientDialog!!
        AlertDialog(
            onDismissRequest = { showDeleteIngredientDialog = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isSwahili) "Futa Kifaa" else "Delete Material",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            },
            text = {
                Text(
                    text = if (isSwahili) 
                        "Je, una uhakika unataka kufuta kabisa kifaa '${formatIngredientName(ingToDelete.name, isSwahili)}'? Kitatolewa kwenye orodha zote za maduka na fomula."
                        else "Are you sure you want to permanently delete '${formatIngredientName(ingToDelete.name, isSwahili)}'? This will remove it from all store lists and formulation options.",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteIngredient(ingToDelete)
                        Toast.makeText(
                            context.applicationContext,
                            if (isSwahili) "Kifaa kimefutwa!" else "Material deleted successfully!",
                            Toast.LENGTH_SHORT
                        ).show()
                        showDeleteIngredientDialog = null
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text(if (isSwahili) "Futa" else "Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteIngredientDialog = null }) {
                    Text(if (isSwahili) "Ghairi" else "Cancel")
                }
            },
            shape = RoundedCornerShape(24.dp)
        )
    }
}

@Composable
fun CategoryHeaderRow(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 16.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = title,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.primary,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun MaterialPriceRow(
    ing: Ingredient,
    priceText: String,
    isSwahili: Boolean,
    isExplicitlySaved: Boolean,
    onClick: () -> Unit,
    onDeleteClick: ((Ingredient) -> Unit)? = null
) {
    val hasPrice = isExplicitlySaved && ing.pricePerKg > 0.0

    val borderStroke = if (hasPrice) {
        BorderStroke(2.dp, MaterialTheme.colorScheme.primary)
    } else {
        BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
    }

    val cardBg = if (hasPrice) {
        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.08f)
    } else {
        MaterialTheme.colorScheme.surface
    }

    val nameFontWeight = if (hasPrice) FontWeight.ExtraBold else FontWeight.Medium
    val nameColor = if (hasPrice) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .clickable { onClick() }
            .testTag("price_row_${ing.name.replace(" ", "_")}"),
        border = borderStroke,
        colors = CardDefaults.cardColors(containerColor = cardBg)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left side: Ingredient Name
            Row(
                modifier = Modifier.weight(1.5f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = formatIngredientName(ing.name, isSwahili),
                    fontWeight = nameFontWeight,
                    fontSize = 15.sp,
                    color = nameColor
                )
                if (ing.isCustom && onDeleteClick != null) {
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(
                        onClick = { onDeleteClick(ing) },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete Custom Ingredient",
                            tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // Right side: Price Display or Click to Edit Indicator
            Row(
                modifier = Modifier.weight(1.3f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.End
            ) {
                if (hasPrice) {
                    Column(
                        horizontalAlignment = Alignment.End,
                        modifier = Modifier.padding(end = 6.dp)
                    ) {
                        Text(
                            text = if (isSwahili) "Bei Iliyowekwa" else "Entered Price",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "TSh ${priceText}/Kg",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Price Saved",
                        tint = Color(0xFF4CAF50), // Nice Material Green
                        modifier = Modifier.size(24.dp)
                    )
                } else {
                    Text(
                        text = if (isSwahili) "Weka Bei" else "Tap to Set Price",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                        style = TextStyle(fontStyle = androidx.compose.ui.text.font.FontStyle.Italic),
                        modifier = Modifier.padding(end = 6.dp)
                    )
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Enter Price",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

data class BudgetRecipeRow(
    val ingredientName: String,
    val percentage: Double,
    val weightKg: Double,
    val costTsh: Double
)

fun parseBudgetRecipe(
    text: String,
    allIngredients: List<Ingredient>,
    batchWeightKg: Double
): List<BudgetRecipeRow> {
    val list = mutableListOf<BudgetRecipeRow>()
    if (text.isBlank()) return list

    // Strategy A: Between ---START_RECIPE--- and ---END_RECIPE---
    if (text.contains("---START_RECIPE---")) {
        try {
            val block = text.substringAfter("---START_RECIPE---").substringBefore("---END_RECIPE---")
            val lines = block.split("\n")
            for (line in lines) {
                if (line.isBlank() || !line.contains(":")) continue
                val namePart = line.substringBefore(":").trim()
                val valPart = line.substringAfter(":").trim()
                
                // Match exact or contains name
                val ing = allIngredients.find {
                    it.name.lowercase().contains(namePart.lowercase()) ||
                    namePart.lowercase().contains(it.name.lowercase())
                } ?: allIngredients.find {
                    val base = it.name.substringBefore("(").trim().lowercase()
                    base.isNotEmpty() && (namePart.lowercase().contains(base) || base.contains(namePart.lowercase()))
                }
                
                // Parse percentage
                val pctRegex = """(\d+(?:\.\d+)?)\s*%""".toRegex()
                val pctMatch = pctRegex.find(valPart)
                val pct = pctMatch?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0

                // Parse weight
                val kgRegex = """(\d+(?:\.\d+)?)\s*(?:kg|Kg|KG)""".toRegex()
                val kgMatch = kgRegex.find(valPart)
                var wt = kgMatch?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0
                if (wt == 0.0 && pct > 0.0) {
                    wt = (pct / 100.0) * batchWeightKg
                }
                
                val finalName = ing?.name ?: namePart
                val price = ing?.pricePerKg ?: 0.0
                val cost = wt * price
                
                if (pct > 0.0 || wt > 0.0) {
                    list.add(BudgetRecipeRow(finalName, pct, wt, cost))
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Strategy B Fallback: scan whole text if list is empty
    if (list.isEmpty()) {
        try {
            val lines = text.split("\n")
            for (line in lines) {
                if (line.isBlank()) continue
                val lowerLine = line.lowercase()
                
                val ing = allIngredients.find {
                    val nameLower = it.name.lowercase()
                    lowerLine.contains(nameLower)
                } ?: allIngredients.find {
                    val base = it.name.substringBefore("(").trim().lowercase()
                    base.isNotBlank() && lowerLine.contains(base)
                }
                
                if (ing != null) {
                    val pctRegex = """(\d+(?:\.\d+)?)\s*%""".toRegex()
                    val pctMatch = pctRegex.find(line)
                    val pct = pctMatch?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0

                    val kgRegex = """(\d+(?:\.\d+)?)\s*(?:kg|Kg|KG)""".toRegex()
                    val kgMatch = kgRegex.find(line)
                    var wt = kgMatch?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0
                    if (wt == 0.0 && pct > 0.0) {
                        wt = (pct / 100.0) * batchWeightKg
                    }

                    if (pct > 0.0 || wt > 0.0) {
                        val cost = wt * ing.pricePerKg
                        list.add(BudgetRecipeRow(ing.name, pct, wt, cost))
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    return list.distinctBy { it.ingredientName }
}

fun calculateNutrientsForBudgetRecipe(
    rows: List<BudgetRecipeRow>,
    allIngredients: List<Ingredient>
): com.example.formulator.AchievedNutrients {
    var totalCp = 0.0
    var totalMe = 0.0
    var totalCa = 0.0
    var totalPh = 0.0
    var totalLy = 0.0
    var totalMe_th = 0.0
    var totalFib = 0.0

    var totalPct = 0.0
    for (row in rows) {
        totalPct += row.percentage
    }

    val factor = if (totalPct > 0.0) 100.0 / totalPct else 1.0

    for (row in rows) {
        val ing = allIngredients.find {
            it.name.lowercase().contains(row.ingredientName.lowercase()) ||
            row.ingredientName.lowercase().contains(it.name.lowercase())
        }
        if (ing != null) {
            val p = row.percentage * (if (totalPct > 90.0 && totalPct < 110.0) 1.0 else factor) / 100.0
            totalCp += p * ing.crudeProtein
            totalMe += p * ing.energy
            totalCa += p * ing.calcium
            totalPh += p * ing.phosphorus
            totalLy += p * ing.lysine
            totalMe_th += p * ing.methionine
            totalFib += p * ing.crudeFiber
        }
    }
    return com.example.formulator.AchievedNutrients(
        crudeProtein = totalCp,
        energy = totalMe,
        calcium = totalCa,
        phosphorus = totalPh,
        lysine = totalLy,
        methionine = totalMe_th,
        crudeFiber = totalFib
    )
}

fun generateFormulaBitmap(
    context: android.content.Context,
    title: String,
    birdType: String,
    stageName: String,
    batchWeight: Double,
    totalCost: Double,
    ingredients: List<Pair<String, Double>>,
    unitPrice: Double,
    isSwahili: Boolean = false
): android.graphics.Bitmap {
    val scale = 2.0f // HD scaling
    val width = (1000 * scale).toInt()
    val height = ((700 + (ingredients.size * 50)) * scale).toInt()
    val bitmap = android.graphics.Bitmap.createBitmap(width, height, android.graphics.Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bitmap)

    // Base paint defaults
    val bgPaint = android.graphics.Paint().apply {
        color = android.graphics.Color.WHITE
        style = android.graphics.Paint.Style.FILL
    }
    canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

    // Deluxe Outer Border
    val borderPaint = android.graphics.Paint().apply {
        color = android.graphics.Color.parseColor("#1B5E20") // Forest Green theme
        style = android.graphics.Paint.Style.STROKE
        strokeWidth = 14f * scale
    }
    canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), borderPaint)

    // Header Graphic Banner
    val bannerPaint = android.graphics.Paint().apply {
        color = android.graphics.Color.parseColor("#1B5E20")
        style = android.graphics.Paint.Style.FILL
    }
    canvas.drawRect(8f * scale, 8f * scale, (width - 8f * scale), 140f * scale, bannerPaint)

    // Main App Title
    val paint = android.graphics.Paint().apply {
        color = android.graphics.Color.WHITE
        textSize = 36f * scale
        isAntiAlias = true
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
    }
    canvas.drawText("POULTRY FEED RECIPE", 50f * scale, 65f * scale, paint)

    paint.textSize = 21f * scale
    paint.typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.ITALIC)
    canvas.drawText("FARMIX AgriTech Diet Planner • High Resolution", 50f * scale, 105f * scale, paint)

    // Content text paints
    val textPaint = android.graphics.Paint().apply {
        color = android.graphics.Color.BLACK
        textSize = 23f * scale
        isAntiAlias = true
    }
    val boldPaint = android.graphics.Paint().apply {
        color = android.graphics.Color.BLACK
        textSize = 23f * scale
        isAntiAlias = true
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
    }
    
    var y = 200f * scale
    canvas.drawText("Recipe Title:", 60f * scale, y, boldPaint)
    canvas.drawText(title, 260f * scale, y, textPaint)
    
    y += 45f * scale
    canvas.drawText("Bird Breed:", 60f * scale, y, boldPaint)
    canvas.drawText(birdType, 260f * scale, y, textPaint)
    
    y += 45f * scale
    canvas.drawText("Growth Stage:", 60f * scale, y, boldPaint)
    canvas.drawText(stageName, 260f * scale, y, textPaint)

    y += 45f * scale
    canvas.drawText("Batch Weight:", 60f * scale, y, boldPaint)
    canvas.drawText("${String.format(java.util.Locale.US, "%.1f", batchWeight)} Kg", 260f * scale, y, textPaint)

    y += 45f * scale
    canvas.drawText("Estimated Cost:", 60f * scale, y, boldPaint)
    canvas.drawText("${String.format(java.util.Locale.US, "%,.1f", totalCost)} TSh (${String.format(java.util.Locale.US, "%.1f", unitPrice)}/Kg)", 260f * scale, y, textPaint)

    y += 65f * scale
    canvas.drawRect(50f * scale, y - 35f * scale, (width - 50f * scale), y + 20f * scale, android.graphics.Paint().apply {
        color = android.graphics.Color.parseColor("#E8F5E9") // Soft Green accent header row
        style = android.graphics.Paint.Style.FILL
    })
    
    val headerPaint = android.graphics.Paint().apply {
        color = android.graphics.Color.parseColor("#1B5E20")
        textSize = 23f * scale
        isAntiAlias = true
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
    }
    canvas.drawText("INGREDIENTS (VIUNGO)", 65f * scale, y, headerPaint)
    canvas.drawText("SHARE (%)", 560f * scale, y, headerPaint)
    canvas.drawText("SIZE (KG)", 800f * scale, y, headerPaint)

    canvas.drawLine(50f * scale, y + 20f * scale, (width - 50f * scale), y + 20f * scale, android.graphics.Paint().apply { color = android.graphics.Color.parseColor("#1B5E20"); strokeWidth = 3f * scale })

    y += 55f * scale
    ingredients.forEach { (name, sharePercent) ->
        val weight = (sharePercent / 100.0) * batchWeight
        canvas.drawText(formatIngredientName(name, isSwahili), 65f * scale, y, textPaint)
        canvas.drawText("${String.format(java.util.Locale.US, "%.2f", sharePercent)} %", 560f * scale, y, textPaint)
        canvas.drawText("${String.format(java.util.Locale.US, "%.2f", weight)} Kg", 800f * scale, y, textPaint)
        canvas.drawLine(50f * scale, y + 20f * scale, (width - 50f * scale), y + 20f * scale, android.graphics.Paint().apply { color = android.graphics.Color.parseColor("#E0E0E0"); strokeWidth = 1.5f * scale })
        y += 50f * scale
    }

    y += 50f * scale
    val footerPaint = android.graphics.Paint().apply {
        color = android.graphics.Color.GRAY
        textSize = 18f * scale
        isAntiAlias = true
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.ITALIC)
    }
    canvas.drawText("Generated by Smart Feed Formulator AI. Verified with standards.", 60f * scale, y, footerPaint)

    return bitmap
}

fun shareFormulaImage(
    context: android.content.Context,
    title: String,
    birdType: String,
    stageName: String,
    batchWeight: Double,
    totalCost: Double,
    ingredients: List<Pair<String, Double>>,
    unitPrice: Double,
    isSwahili: Boolean = false
) {
    try {
        val bitmap = generateFormulaBitmap(context, title, birdType, stageName, batchWeight, totalCost, ingredients, unitPrice, isSwahili)
        val cachePath = java.io.File(context.cacheDir, "images")
        cachePath.mkdirs()
        val file = java.io.File(cachePath, "formula_recipe.jpg")
        val stream = java.io.FileOutputStream(file)
        bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 100, stream)
        stream.close()

        val contentUri = androidx.core.content.FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        if (contentUri != null) {
            val shareIntent = android.content.Intent().apply {
                action = android.content.Intent.ACTION_SEND
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                setDataAndType(contentUri, "image/jpeg")
                putExtra(android.content.Intent.EXTRA_STREAM, contentUri)
                putExtra(android.content.Intent.EXTRA_TEXT, "Here is my poultry feed formulation: $title")
                type = "image/jpeg"
            }
            context.startActivity(android.content.Intent.createChooser(shareIntent, "Share Formula via"))
        }
    } catch (e: Exception) {
        e.printStackTrace()
        android.widget.Toast.makeText(context.applicationContext, "Error sharing recipe image: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
    }
}

object BudgetFormulatorSolver {
    
    private fun isMicroIngredient(name: String): Boolean {
        val lower = name.lowercase()
        return lower.contains("premix") || lower.contains("salt") || lower.contains("chumvi") ||
               lower.contains("enzyme") || lower.contains("toxin") || lower.contains("binder") ||
               lower.contains("lysine") || lower.contains("methionine")
    }

    private fun getEffectiveMinPercent(name: String, limit: InclusionLimit?): Double {
        if (isMicroIngredient(name)) {
            return limit?.minPercent ?: 0.0
        }
        val defaultMin = 4.0 // Ensure macro ingredients have at least 4% contribution
        return if (limit != null) {
            if (limit.minPercent > 0.0) limit.minPercent else defaultMin
        } else {
            defaultMin
        }
    }

    data class SolverResult(
        val success: Boolean,
        val ingredientPercentages: Map<String, Double>,
        val ingredientWeightsKg: Map<String, Double>,
        val achievedNutrients: AchievedNutrients,
        val totalCost: Double,
        val costPerKg: Double,
        val isNutritionalCompliant: Boolean,
        val minRequiredBudget: Double = 0.0,
        val suggestedChanges: String = ""
    )

    private class LPSolver(
        val numVars: Int,
        val c: DoubleArray,
        val A_eq: List<DoubleArray>,
        val b_eq: DoubleArray,
        val A_le: List<DoubleArray>,
        val b_le: DoubleArray,
        val A_ge: List<DoubleArray>,
        val b_ge: DoubleArray
    ) {
        companion object {
            private const val EPS = 1e-10
        }

        fun solve(): DoubleArray? {
            val m_eq = A_eq.size
            val m_le = A_le.size
            val m_ge = A_ge.size
            val m = m_eq + m_le + m_ge

            if (m == 0) {
                return DoubleArray(numVars)
            }

            val numArt = m_eq + m_ge
            val numCols = numVars + m_le + m_ge + numArt + 1
            val numRows = m + 2

            val tableau = Array(numRows) { DoubleArray(numCols) }
            val basis = IntArray(m)

            val slackStart = numVars
            val surplusStart = numVars + m_le
            val artStart = numVars + m_le + m_ge

            // Equality constraints
            for (i in 0 until m_eq) {
                val row = i
                for (j in 0 until numVars) {
                    tableau[row][j] = A_eq[i][j]
                }
                tableau[row][artStart + i] = 1.0
                tableau[row][numCols - 1] = b_eq[i]
                basis[row] = artStart + i
            }

            // LE constraints
            for (i in 0 until m_le) {
                val row = m_eq + i
                for (j in 0 until numVars) {
                    tableau[row][j] = A_le[i][j]
                }
                tableau[row][slackStart + i] = 1.0
                tableau[row][numCols - 1] = b_le[i]
                basis[row] = slackStart + i
            }

            // GE constraints
            for (i in 0 until m_ge) {
                val row = m_eq + m_le + i
                for (j in 0 until numVars) {
                    tableau[row][j] = A_ge[i][j]
                }
                tableau[row][surplusStart + i] = -1.0
                tableau[row][artStart + m_eq + i] = 1.0
                tableau[row][numCols - 1] = b_ge[i]
                basis[row] = artStart + m_eq + i
            }

            // Phase 2 Objective
            for (j in 0 until numVars) {
                tableau[m + 1][j] = -c[j]
            }

            // Phase 1 Objective: Canonical summation of artificials
            for (row in 0 until m_eq) {
                for (col in 0 until numCols) {
                    tableau[m][col] -= tableau[row][col]
                }
            }
            for (row in m_eq + m_le until m) {
                for (col in 0 until numCols) {
                    tableau[m][col] -= tableau[row][col]
                }
            }

            fun pivot(pivotRow: Int, pivotCol: Int) {
                val pivotVal = tableau[pivotRow][pivotCol]
                for (j in 0 until numCols) {
                    tableau[pivotRow][j] /= pivotVal
                }
                for (i in 0 until numRows) {
                    if (i != pivotRow) {
                        val factor = tableau[i][pivotCol]
                        if (Math.abs(factor) > 1e-12) {
                            for (j in 0 until numCols) {
                                tableau[i][j] -= factor * tableau[pivotRow][j]
                            }
                        }
                    }
                }
                basis[pivotRow] = pivotCol
            }

            // Phase 1 Optimization
            var phase1Optimal = false
            var iterations = 0
            val maxIter = 5000
            while (!phase1Optimal && iterations < maxIter) {
                iterations++
                var pivotCol = -1
                var minVal = -EPS
                for (j in 0 until artStart) {
                    if (tableau[m][j] < minVal) {
                        minVal = tableau[m][j]
                        pivotCol = j
                    }
                }
                if (pivotCol == -1) {
                    phase1Optimal = true
                    break
                }

                var pivotRow = -1
                var minRatio = Double.MAX_VALUE
                for (i in 0 until m) {
                    if (tableau[i][pivotCol] > EPS) {
                        val ratio = tableau[i][numCols - 1] / tableau[i][pivotCol]
                        if (ratio < minRatio) {
                            minRatio = ratio
                            pivotRow = i
                        }
                    }
                }
                if (pivotRow == -1) {
                    phase1Optimal = true
                    break
                }

                pivot(pivotRow, pivotCol)
            }

            val phaseWVal = -tableau[m][numCols - 1]
            if (phaseWVal > 1e-5) {
                return null
            }

            // Phase 2 Optimization
            var phase2Optimal = false
            iterations = 0
            while (!phase2Optimal && iterations < maxIter) {
                iterations++
                var pivotCol = -1
                var minVal = -EPS
                for (j in 0 until artStart) {
                    if (tableau[m + 1][j] < minVal) {
                        minVal = tableau[m + 1][j]
                        pivotCol = j
                    }
                }
                if (pivotCol == -1) {
                    phase2Optimal = true
                    break
                }

                var pivotRow = -1
                var minRatio = Double.MAX_VALUE
                for (i in 0 until m) {
                    if (tableau[i][pivotCol] > EPS) {
                        val ratio = tableau[i][numCols - 1] / tableau[i][pivotCol]
                        if (ratio < minRatio) {
                            minRatio = ratio
                            pivotRow = i
                        }
                    }
                }
                if (pivotRow == -1) {
                    phase2Optimal = true
                    break
                }

                pivot(pivotRow, pivotCol)
            }

            val res = DoubleArray(numVars)
            for (j in 0 until numVars) {
                var foundRow = -1
                for (i in 0 until m) {
                    if (basis[i] == j) {
                        foundRow = i
                        break
                    }
                }
                if (foundRow != -1) {
                    res[j] = Math.max(0.0, tableau[foundRow][numCols - 1])
                } else {
                    res[j] = 0.0
                }
            }
            return res
        }
    }

    fun solve(
        ingredients: List<Ingredient>,
        target: NutrientTarget,
        inclusionLimits: List<InclusionLimit>,
        batchWeightKg: Double,
        budget: Double,
        isSwahili: Boolean
    ): SolverResult {
        val selectedIngredients = ingredients.filter { it.isSelected }
        if (selectedIngredients.isEmpty()) {
            return SolverResult(
                success = false,
                ingredientPercentages = emptyMap(),
                ingredientWeightsKg = emptyMap(),
                achievedNutrients = AchievedNutrients(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                totalCost = 0.0,
                costPerKg = 0.0,
                isNutritionalCompliant = false,
                suggestedChanges = if (isSwahili) "Hakuna viungo vilivyochaguliwa katika Mipangilio!" else "No ingredients selected! Please check some available ingredients in Settings."
            )
        }

        // Try using the highly-optimized Coordinate Descent base solver first
        val baseResult = com.example.formulator.PoultryFeedSolver.solve(
            ingredients = ingredients,
            target = target,
            inclusionLimits = inclusionLimits,
            batchWeightKg = batchWeightKg
        )

        // If the standard formulation succeeded and its total cost is within the pocket budget, it is trivially feasible!
        if (baseResult.success && budget >= baseResult.totalCost - 0.50) {
            val achieved = AchievedNutrients(
                crudeProtein = baseResult.achievedNutrients.crudeProtein,
                energy = baseResult.achievedNutrients.energy,
                calcium = baseResult.achievedNutrients.calcium,
                phosphorus = baseResult.achievedNutrients.phosphorus,
                lysine = baseResult.achievedNutrients.lysine,
                methionine = baseResult.achievedNutrients.methionine,
                crudeFiber = baseResult.achievedNutrients.crudeFiber
            )
            return SolverResult(
                success = true,
                ingredientPercentages = baseResult.ingredientPercentages,
                ingredientWeightsKg = baseResult.ingredientWeightsKg,
                achievedNutrients = achieved,
                totalCost = baseResult.totalCost,
                costPerKg = baseResult.costPerKg,
                isNutritionalCompliant = (baseResult.errorMessage == null),
                minRequiredBudget = baseResult.totalCost,
                suggestedChanges = baseResult.errorMessage ?: ""
            )
        }

        val n = selectedIngredients.size
        val limitsMap = inclusionLimits.associateBy { it.ingredientName }

        val l = DoubleArray(n)
        val u = DoubleArray(n)
        var sumL = 0.0

        for (i in 0 until n) {
            val ing = selectedIngredients[i]
            val limit = limitsMap[ing.name]
            val (minPct, maxPct) = if (limit != null && limit.isFixed) {
                Pair(limit.minPercent, limit.minPercent)
            } else {
                val minEff = getEffectiveMinPercent(ing.name, limit)
                val maxEff = limit?.maxPercent ?: 100.0
                Pair(minEff, maxEff)
            }

            l[i] = (minPct / 100.0) * batchWeightKg
            u[i] = (maxPct / 100.0) * batchWeightKg
            if (u[i] < l[i]) u[i] = l[i]
            sumL += l[i]
        }

        if (sumL > batchWeightKg + 1e-4) {
            return SolverResult(
                success = false,
                ingredientPercentages = emptyMap(),
                ingredientWeightsKg = emptyMap(),
                achievedNutrients = AchievedNutrients(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                totalCost = 0.0,
                costPerKg = 0.0,
                isNutritionalCompliant = false,
                suggestedChanges = if (isSwahili) "Vikomo vilivyowekwa vinazidi uzito wa kundi!" else "Fixed/minimum inclusion limits total more than the batch weight. Please adjust limit values."
            )
        }

        val A_eq = mutableListOf<DoubleArray>()
        val b_eq = mutableListOf<Double>()

        val A_le = mutableListOf<DoubleArray>()
        val b_le = mutableListOf<Double>()

        val A_ge = mutableListOf<DoubleArray>()
        val b_ge = mutableListOf<Double>()

        // 1. Sum weight constraint
        val sum_eq = DoubleArray(n) { 1.0 }
        A_eq.add(sum_eq)
        b_eq.add(batchWeightKg - sumL)

        // 2. Upper bounds
        for (i in 0 until n) {
            val u_bound = DoubleArray(n)
            u_bound[i] = 1.0
            A_le.add(u_bound)
            b_le.add(u[i] - l[i])
        }

        // Helper functions
        fun addNutrientGeConstraint(nutrientSelector: (Ingredient) -> Double, targetVal: Double) {
            val coeff = DoubleArray(n)
            var sumL_nutrient = 0.0
            val scale = if (targetVal > 0.0) targetVal else 1.0
            for (i in 0 until n) {
                val ing = selectedIngredients[i]
                coeff[i] = nutrientSelector(ing) / scale
                sumL_nutrient += l[i] * coeff[i]
            }
            A_ge.add(coeff)
            b_ge.add(batchWeightKg - sumL_nutrient)
        }

        fun addNutrientLeConstraint(nutrientSelector: (Ingredient) -> Double, targetVal: Double) {
            val coeff = DoubleArray(n)
            var sumL_nutrient = 0.0
            val scale = if (targetVal > 0.0) targetVal else 1.0
            for (i in 0 until n) {
                val ing = selectedIngredients[i]
                coeff[i] = nutrientSelector(ing) / scale
                sumL_nutrient += l[i] * coeff[i]
            }
            A_le.add(coeff)
            b_le.add(batchWeightKg - sumL_nutrient)
        }

        // 3. Nutrient Constraints
        addNutrientGeConstraint({ it.crudeProtein }, target.crudeProtein)
        addNutrientGeConstraint({ it.energy }, target.energy)
        addNutrientGeConstraint({ it.calcium }, target.calcium)
        addNutrientGeConstraint({ it.phosphorus }, target.phosphorus)
        addNutrientGeConstraint({ it.lysine }, target.lysine)
        addNutrientGeConstraint({ it.methionine }, target.methionine)
        addNutrientLeConstraint({ it.crudeFiber }, target.crudeFiber)

        // Solving logic helper
        fun preprocessAndSolve(c: DoubleArray): DoubleArray? {
            val clean_A_eq = mutableListOf<DoubleArray>()
            val clean_b_eq = mutableListOf<Double>()
            val clean_A_le = mutableListOf<DoubleArray>()
            val clean_b_le = mutableListOf<Double>()
            val clean_A_ge = mutableListOf<DoubleArray>()
            val clean_b_ge = mutableListOf<Double>()

            for (i in A_eq.indices) {
                val a = A_eq[i].clone()
                var b = b_eq[i]
                if (b < 0.0) {
                    for (j in a.indices) a[j] *= -1.0
                    b *= -1.0
                }
                clean_A_eq.add(a)
                clean_b_eq.add(b)
            }

            for (i in A_le.indices) {
                val a = A_le[i].clone()
                var b = b_le[i]
                if (b < 0.0) {
                    for (j in a.indices) a[j] *= -1.0
                    b *= -1.0
                    clean_A_ge.add(a)
                    clean_b_ge.add(b)
                } else {
                    clean_A_le.add(a)
                    clean_b_le.add(b)
                }
            }

            for (i in A_ge.indices) {
                val a = A_ge[i].clone()
                var b = b_ge[i]
                if (b < 0.0) {
                    for (j in a.indices) a[j] *= -1.0
                    b *= -1.0
                    clean_A_le.add(a)
                    clean_b_le.add(b)
                } else {
                    clean_A_ge.add(a)
                    clean_b_ge.add(b)
                }
            }

            val solver = LPSolver(
                numVars = n,
                c = c,
                A_eq = clean_A_eq,
                b_eq = clean_b_eq.toDoubleArray(),
                A_le = clean_A_le,
                b_le = clean_b_le.toDoubleArray(),
                A_ge = clean_A_ge,
                b_ge = clean_b_ge.toDoubleArray()
            )
            return solver.solve()
        }

        // Mode 1: Cost Minimization to find absolute cost feasibility
        val c_cost = DoubleArray(n) { selectedIngredients[it].pricePerKg }
        val solved_shifted_mode1 = preprocessAndSolve(c_cost)

        if (solved_shifted_mode1 == null) {
            val suggested = findSuggestedChanges(selectedIngredients, ingredients, target, isSwahili)
            return SolverResult(
                success = false,
                ingredientPercentages = emptyMap(),
                ingredientWeightsKg = emptyMap(),
                achievedNutrients = AchievedNutrients(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                totalCost = 0.0,
                costPerKg = 0.0,
                isNutritionalCompliant = false,
                minRequiredBudget = 0.0,
                suggestedChanges = suggested
            )
        }

        var minCost = 0.0
        for (i in 0 until n) {
            val w = solved_shifted_mode1[i] + l[i]
            minCost += w * selectedIngredients[i].pricePerKg
        }

        // Check if user budget can afford the minimum feasible cost
        if (budget < minCost - 0.05) {
            val suggested = findSuggestedChanges(selectedIngredients, ingredients, target, isSwahili)
            return SolverResult(
                success = false,
                ingredientPercentages = emptyMap(),
                ingredientWeightsKg = emptyMap(),
                achievedNutrients = AchievedNutrients(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                totalCost = 0.0,
                costPerKg = 0.0,
                isNutritionalCompliant = false,
                minRequiredBudget = minCost,
                suggestedChanges = suggested
            )
        }

        // Mode 2: Multi-objective quality preference optimizing within specified budget limit
        val priceScale = selectedIngredients.map { it.pricePerKg }.average().coerceAtLeast(1.0)
        val budgetCoeff = DoubleArray(n) { selectedIngredients[it].pricePerKg / priceScale }
        var sumL_cost = 0.0
        for (i in 0 until n) {
            sumL_cost += l[i] * selectedIngredients[i].pricePerKg
        }
        val budgetRHS = (budget - sumL_cost) / priceScale
        A_le.add(budgetCoeff)
        b_le.add(budgetRHS)

        val c_premium = DoubleArray(n) { idx ->
            val ing = selectedIngredients[idx]
            val lower = ing.name.lowercase()
            var q = 0.0
            if (lower.contains("maize") || lower.contains("mahindi") || lower.contains("soy") || lower.contains("soya") || lower.contains("fish") || lower.contains("samaki")) {
                q += 45.0
            } else if (lower.contains("limestone") || lower.contains("dcp") || lower.contains("premix") || lower.contains("bone")) {
                q += 15.0
            } else if (lower.contains("husk") || lower.contains("makapi") || lower.contains("bran") || lower.contains("pumba")) {
                q -= 35.0
            }
            -q + (ing.pricePerKg / 500.0)
        }

        val solved_shifted_mode2 = preprocessAndSolve(c_premium)
        var useMode2 = false
        if (solved_shifted_mode2 != null) {
            var mode2Cost = 0.0
            for (i in 0 until n) {
                val ing = selectedIngredients[i]
                val w = solved_shifted_mode2[i] + l[i]
                mode2Cost += w * ing.pricePerKg
            }
            if (mode2Cost <= budget + 0.1) {
                useMode2 = true
            }
        }
        val final_shifted = if (useMode2) solved_shifted_mode2!! else solved_shifted_mode1

        var finalCP = 0.0
        var finalME = 0.0
        var finalCa = 0.0
        var finalP = 0.0
        var finalLys = 0.0
        var finalMet = 0.0
        var finalCF = 0.0
        var finalCost = 0.0

        val percentages = mutableMapOf<String, Double>()
        val weights = mutableMapOf<String, Double>()

        for (i in 0 until n) {
            val ing = selectedIngredients[i]
            val w = final_shifted[i] + l[i]
            val pct = (w / batchWeightKg) * 100.0
            percentages[ing.name] = pct
            weights[ing.name] = w

            finalCP += w * ing.crudeProtein
            finalME += w * ing.energy
            finalCa += w * ing.calcium
            finalP += w * ing.phosphorus
            finalLys += w * ing.lysine
            finalMet += w * ing.methionine
            finalCF += w * ing.crudeFiber
            finalCost += w * ing.pricePerKg
        }

        val achieved = AchievedNutrients(
            crudeProtein = finalCP / batchWeightKg,
            energy = finalME / batchWeightKg,
            calcium = finalCa / batchWeightKg,
            phosphorus = finalP / batchWeightKg,
            lysine = finalLys / batchWeightKg,
            methionine = finalMet / batchWeightKg,
            crudeFiber = finalCF / batchWeightKg
        )

        val budgetComparisonResult = if (budget >= finalCost - 1e-4) "Success/Sufficient" else "Failed/Insufficient"
        android.util.Log.d("FeedFormulator", "--- Budget Constraint Debugging ---")
        android.util.Log.d("FeedFormulator", "Formula Cost: TSh $finalCost")
        android.util.Log.d("FeedFormulator", "User Budget: TSh $budget")
        android.util.Log.d("FeedFormulator", "Budget Comparison Result: $budgetComparisonResult")
        android.util.Log.d("FeedFormulator", "-----------------------------------")

        if (finalCost > budget + 0.1) {
            return SolverResult(
                success = false,
                ingredientPercentages = emptyMap(),
                ingredientWeightsKg = emptyMap(),
                achievedNutrients = AchievedNutrients(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                totalCost = 0.0,
                costPerKg = 0.0,
                isNutritionalCompliant = false,
                minRequiredBudget = minCost,
                suggestedChanges = if (isSwahili) "Mchanganyiko umezidi bajeti iliyowekwa." else "Formulation total cost exceeds specified budget. Please try again."
            )
        }

        val isCompliant = achieved.crudeProtein >= target.crudeProtein - 0.45 &&
                          achieved.energy >= target.energy - 45.0 &&
                          achieved.calcium >= target.calcium - 0.09 &&
                          achieved.phosphorus >= target.phosphorus - 0.05

        return SolverResult(
            success = true,
            ingredientPercentages = percentages,
            ingredientWeightsKg = weights,
            achievedNutrients = achieved,
            totalCost = finalCost,
            costPerKg = finalCost / batchWeightKg,
            isNutritionalCompliant = isCompliant,
            minRequiredBudget = minCost
        )
    }

    private fun findSuggestedChanges(
        selected: List<Ingredient>,
        all: List<Ingredient>,
        target: NutrientTarget,
        isSwahili: Boolean
    ): String {
        val unselected = all.filter { !it.isSelected }
        val recommendations = mutableListOf<String>()

        val selectedMaxCP = selected.maxOfOrNull { it.crudeProtein } ?: 0.0
        if (selectedMaxCP < target.crudeProtein) {
            val highProteinUnselected = unselected.filter { it.crudeProtein >= 30.0 }.sortedBy { it.pricePerKg }
            if (highProteinUnselected.isNotEmpty()) {
                val names = highProteinUnselected.take(2).joinToString(", ") { it.name }
                recommendations.add(
                    if (isSwahili) "Fikiria kuwezesha viungo vya protini ya juu: $names katika Mipangilio"
                    else "Consider enabling high-protein ingredients: $names in Settings"
                )
            }
        }

        val unselectedEnergyCheap = unselected.filter { it.energy >= 2500.0 && it.pricePerKg < 50.0 }.sortedBy { it.pricePerKg }
        if (unselectedEnergyCheap.isNotEmpty()) {
            val names = unselectedEnergyCheap.take(2).joinToString(", ") { it.name }
            recommendations.add(
                if (isSwahili) "Fikiria kuwezesha nishati ya bei nafuu: $names katika Mipangilio"
                else "Consider enabling cheap, energy-rich raw materials: $names in Settings"
            )
        }

        if (recommendations.isEmpty()) {
            recommendations.add(
                if (isSwahili) "Thibitisha kikomo cha matumizi au wezesha viungo bora kama Soya au Samaki katika Mipangilio."
                else "Verify inclusion limits or enable premium ingredients like Fish Meal or Soybean Meal in Settings."
            )
        }
        return recommendations.joinToString("\n• ", prefix = "• ")
    }
}


@Composable
fun FixedBudgetScreen(
    viewModel: PoultryViewModel,
    onNavigate: (String) -> Unit,
    isSwahili: Boolean
) {
    val rawIngredientsList by viewModel.ingredients.collectAsStateWithLifecycle()
    val currentTargetVal by viewModel.currentTarget.collectAsStateWithLifecycle()
    val isCustomizing by viewModel.isCustomizingRecipe.collectAsStateWithLifecycle()
    val customizedRecipe by viewModel.customizedRecipeText.collectAsStateWithLifecycle()
    val batchWeightVal by viewModel.batchWeight.collectAsStateWithLifecycle()
    val activeInclusionLimits by viewModel.inclusionLimits.collectAsStateWithLifecycle()
    val formulationResult by viewModel.solverResult.collectAsStateWithLifecycle()
    val birdType by viewModel.selectedBirdType.collectAsStateWithLifecycle()
    val ageWeeks by viewModel.selectedAgeWeeks.collectAsStateWithLifecycle()
    val flockSize by viewModel.birdCount.collectAsStateWithLifecycle()

    val context = LocalContext.current
    val focusManager = androidx.compose.ui.platform.LocalFocusManager.current
    val keyboardController = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current
    val budgetInputFlow by viewModel.budgetInput.collectAsStateWithLifecycle()
    var budgetInput by remember(budgetInputFlow) { mutableStateOf(budgetInputFlow) }
    LaunchedEffect(budgetInput) {
        viewModel.budgetInput.value = budgetInput
    }

    val bagWeightInputFlow by viewModel.bagWeightInput.collectAsStateWithLifecycle()
    var bagWeightInput by remember(bagWeightInputFlow) { mutableStateOf(bagWeightInputFlow) }
    LaunchedEffect(bagWeightInput) {
        viewModel.bagWeightInput.value = bagWeightInput
    }

    val hasOptimizedFlow by viewModel.hasOptimizedBudget.collectAsStateWithLifecycle()
    var hasOptimized by remember(hasOptimizedFlow) { mutableStateOf(hasOptimizedFlow) }
    LaunchedEffect(hasOptimized) {
        viewModel.hasOptimizedBudget.value = hasOptimized
    }

    val budgetResultFlow by viewModel.budgetResult.collectAsStateWithLifecycle()
    var budgetResult by remember(budgetResultFlow) { mutableStateOf(budgetResultFlow) }
    LaunchedEffect(budgetResult) {
        viewModel.budgetResult.value = budgetResult
    }

    var saveDialogOpened by remember { mutableStateOf(false) }
    var saveTitle by remember { mutableStateOf("") }

    var showResultsPopup by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()
    var isCalculatingBudget by remember { mutableStateOf(false) }
    var calculationProgress by remember { mutableStateOf(0.0f) }
    var optimizedBatchWeight by remember {
        val normalCost = formulationResult?.takeIf { it.success }?.costPerKg ?: 0.0
        val amt = budgetInput.toDoubleOrNull() ?: 0.0
        val targetWeight = if (normalCost > 0.0 && amt > 0.0) amt / normalCost else batchWeightVal
        mutableStateOf(targetWeight)
    }

    val parsedRows = remember(customizedRecipe, optimizedBatchWeight) {
        parseBudgetRecipe(customizedRecipe, rawIngredientsList, optimizedBatchWeight)
    }
    
    val totalBudgetCost = remember(parsedRows) { parsedRows.sumOf { it.costTsh } }
    val averageUnitCost = remember(parsedRows, optimizedBatchWeight) { 
        if (optimizedBatchWeight > 0.0) totalBudgetCost / optimizedBatchWeight else 0.0 
    }

    val cleanAdviceText = remember(customizedRecipe) {
        customizedRecipe.substringAfter("---END_RECIPE---").trim()
            .ifBlank { customizedRecipe.replace("---START_RECIPE---", "").replace("---END_RECIPE---", "") }
    }

    // A new optimization process must run every time the budget or ingredients change.
    LaunchedEffect(budgetInput, batchWeightVal, rawIngredientsList, activeInclusionLimits, hasOptimized) {
        if (hasOptimized) {
            val amt = budgetInput.toDoubleOrNull() ?: 0.0
            if (amt > 0.0 && currentTargetVal != null) {
                // Determine target weight based on standard formulation cost per kg
                val normalCost = formulationResult?.takeIf { it.success }?.costPerKg ?: 0.0
                val targetWeight = if (normalCost > 0.0) amt / normalCost else batchWeightVal
                optimizedBatchWeight = targetWeight

                val optResult = BudgetFormulatorSolver.solve(
                    ingredients = rawIngredientsList,
                    target = currentTargetVal!!,
                    inclusionLimits = activeInclusionLimits,
                    batchWeightKg = targetWeight,
                    budget = amt,
                    isSwahili = isSwahili
                )
                budgetResult = optResult
                if (optResult.success) {
                    val sb = java.lang.StringBuilder()
                    sb.append("---START_RECIPE---\n")
                    optResult.ingredientPercentages.forEach { (name, pct) ->
                        val wt = optResult.ingredientWeightsKg[name] ?: 0.0
                        sb.append("$name: ${String.format(java.util.Locale.US, "%.2f", pct)}% | ${String.format(java.util.Locale.US, "%.2f", wt)} Kg\n")
                    }
                    sb.append("---END_RECIPE---\n")
                    sb.append(if (isSwahili) "Marekebisho yamekamilika kwa bajeti maalum kikamilifu." else "Recalculation optimized successfully for your target budget.")
                    viewModel.customizedRecipeText.value = sb.toString()
                } else {
                    viewModel.customizedRecipeText.value = ""
                }
            } else {
                viewModel.customizedRecipeText.value = ""
            }
        }
    }

    // Results Dialog pop-up
    if (showResultsPopup && budgetResult != null) {
        val result = budgetResult!!
        AlertDialog(
            onDismissRequest = { showResultsPopup = false },
            title = {
                Text(
                    text = if (result.success) {
                        if (isSwahili) "Fomula ya Bajeti Imekamilika!" else "Budget Formulation Complete!"
                    } else {
                        if (isSwahili) "Marekebisho Yamefeli!" else "Formulation Infeasible!"
                    },
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = if (result.success) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (!result.success) {
                        Text(
                            text = if (isSwahili) 
                                "Bajeti ni ndogo mno kuzalisha lishe yenye uwiano wa kutosha wa virutubisho kwa kutumia viungo vilivyochaguliwa."
                                else "Budget is insufficient to produce a nutritionally balanced feed using the selected ingredients.",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (isSwahili) "Bajeti ya Chini Inayohitajika:" else "Minimum budget required:",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                        Text(
                            text = "${String.format("%,.0f", result.minRequiredBudget)} TSh",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (isSwahili) "Mabadiliko ya Viungo Yanayopendekezwa:" else "Suggested ingredient changes:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Text(
                            text = result.suggestedChanges,
                            fontSize = 11.sp,
                            lineHeight = 15.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Text(
                            text = if (isSwahili) "Mchanganyiko wa Viungo na Gharama:" else "Ingredients & Costs:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(if (isSwahili) "Kiambato" else "Ingredient Name", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1.5f))
                                    Text(if (isSwahili) "Uzito (Kg)" else "Quantity (kg)", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1.0f), textAlign = TextAlign.End)
                                    Text(if (isSwahili) "Bei" else "Cost Contribution", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1.2f), textAlign = TextAlign.End)
                                }
                                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                                result.ingredientPercentages.forEach { (name, pct) ->
                                    val qty = result.ingredientWeightsKg[name] ?: 0.0
                                    val ing = rawIngredientsList.find { it.name == name }
                                    val price = ing?.pricePerKg ?: 0.0
                                    val cost = qty * price
                                    if (pct > 0.0) {
                                        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Column(modifier = Modifier.weight(1.5f)) {
                                                Text(formatIngredientName(name, isSwahili), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                val bagWt = bagWeightInput.toDoubleOrNull() ?: 50.0
                                                val bags = if (bagWt > 0) qty / bagWt else 0.0
                                                Text(
                                                    text = if (isSwahili) {
                                                        String.format(java.util.Locale.US, "%.2f batches/mifuko (%s Kg)", bags, bagWeightInput)
                                                    } else {
                                                        String.format(java.util.Locale.US, "%.2f batches/bags (%s Kg)", bags, bagWeightInput)
                                                    },
                                                    fontSize = 9.sp,
                                                    color = MaterialTheme.colorScheme.secondary
                                                )
                                            }
                                            Text("${String.format(java.util.Locale.US, "%.2f", qty)} kg", fontSize = 11.sp, modifier = Modifier.weight(1.0f), textAlign = TextAlign.End)
                                            Text("${String.format(java.util.Locale.US, "%,.0f", cost)} TSh", fontSize = 11.sp, modifier = Modifier.weight(1.2f), textAlign = TextAlign.End)
                                        }
                                    }
                                }

                                var totalW = 0.0
                                var totalC = 0.0
                                result.ingredientPercentages.forEach { (name, pct) ->
                                    val qty = result.ingredientWeightsKg[name] ?: 0.0
                                    val ing = rawIngredientsList.find { it.name == name }
                                    val price = ing?.pricePerKg ?: 0.0
                                    if (pct > 0.0) {
                                        totalW += qty
                                        totalC += qty * price
                                    }
                                }

                                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(if (isSwahili) "JUMLA" else "TOTAL", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1.5f), color = MaterialTheme.colorScheme.primary)
                                    Text("${String.format(java.util.Locale.US, "%.2f", totalW)} kg", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1.0f), textAlign = TextAlign.End, color = MaterialTheme.colorScheme.primary)
                                    Text("${String.format(java.util.Locale.US, "%,.0f", totalC)} TSh", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1.2f), textAlign = TextAlign.End, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(if (isSwahili) "Muhtasari wa Marekebisho:" else "Summary details:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.secondary)

                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(if (isSwahili) "Jumla ya Uzito wa Chakula:" else "Total Feed Weight:", fontSize = 11.sp)
                                Text("${String.format(java.util.Locale.US, "%.1f", batchWeightVal)} Kg", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(if (isSwahili) "Idadi ya Batches/Mifuko (" + bagWeightInput + " Kg):" else "Total Batches/Bags Needed (" + bagWeightInput + " Kg):", fontSize = 11.sp)
                                val bagWt = bagWeightInput.toDoubleOrNull() ?: 50.0
                                val totalBags = if (bagWt > 0) batchWeightVal / bagWt else 0.0
                                Text(if (isSwahili) "${String.format(java.util.Locale.US, "%.2f", totalBags)} Batches/Mifuko" else "${String.format(java.util.Locale.US, "%.2f", totalBags)} Batches/Bags", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(if (isSwahili) "Jumla Kuu ya Gharama:" else "Total Cost:", fontSize = 11.sp)
                                Text("${String.format(java.util.Locale.US, "%,.0f", result.totalCost)} TSh", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(if (isSwahili) "Bajeti ya Mtumiaji:" else "User Budget:", fontSize = 11.sp)
                                Text("${String.format(java.util.Locale.US, "%,.0f", budgetInput.toDoubleOrNull() ?: 0.0)} TSh", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(if (isSwahili) "Bajeti Iliyobaki:" else "Remaining Budget:", fontSize = 11.sp)
                                val remaining = (budgetInput.toDoubleOrNull() ?: 0.0) - result.totalCost
                                Text("${String.format(java.util.Locale.US, "%,.0f", remaining)} TSh", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(if (isSwahili) "Gharama kwa kila Kilo:" else "Cost per kg:", fontSize = 11.sp)
                                Text("${String.format(java.util.Locale.US, "%,.1f", result.costPerKg)} TSh/Kg", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                            val originalCostPerKg = formulationResult?.takeIf { it.success }?.costPerKg ?: 0.0
                            if (originalCostPerKg > 0.0) {
                                val bAmt = budgetInput.toDoubleOrNull() ?: 0.0
                                val bgWt = bagWeightInput.toDoubleOrNull() ?: 50.0
                                if (bAmt > 0.0 && bgWt > 0.0) {
                                    val costOfOneBagOfNormal = originalCostPerKg * bgWt
                                    val bagsAtNormalRate = bAmt / costOfOneBagOfNormal
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(
                                            text = if (isSwahili) "Batches/Mifuko Kutoka Fomula ya Kawaida:" else "Expected Batches/Bags From Budget at Normal Rate:",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            text = if (isSwahili) {
                                                "${String.format(java.util.Locale.US, "%.2f Batches/Mifuko", bagsAtNormalRate)} (${bgWt}Kg)"
                                            } else {
                                                "${String.format(java.util.Locale.US, "%.2f Batches/Bags", bagsAtNormalRate)} (${bgWt}Kg)"
                                            },
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(if (isSwahili) "Protini Iliyofikiwa (Lengo):" else "Protein Achieved (Target):", fontSize = 11.sp)
                                Text("${String.format(java.util.Locale.US, "%.2f", result.achievedNutrients.crudeProtein)}% (${String.format(java.util.Locale.US, "%.1f", currentTargetVal?.crudeProtein ?: 0.0)}%)", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = if (result.achievedNutrients.crudeProtein >= (currentTargetVal?.crudeProtein ?: 0.0) - 0.45) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(if (isSwahili) "Nishati Iliyofikiwa (Lengo):" else "Energy Achieved (Target):", fontSize = 11.sp)
                                Text("${String.format(java.util.Locale.US, "%.0f", result.achievedNutrients.energy)} (${String.format(java.util.Locale.US, "%.0f", currentTargetVal?.energy ?: 0.0)}) kcal", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = if (result.achievedNutrients.energy >= (currentTargetVal?.energy ?: 0.0) - 45.0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(if (isSwahili) "Calcium Iliyofikiwa (Lengo):" else "Calcium Achieved (Target):", fontSize = 11.sp)
                                Text("${String.format(java.util.Locale.US, "%.2f", result.achievedNutrients.calcium)}% (${String.format(java.util.Locale.US, "%.2f", currentTargetVal?.calcium ?: 0.0)}%)", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = if (result.achievedNutrients.calcium >= (currentTargetVal?.calcium ?: 0.0) - 0.09) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(if (isSwahili) "Phosphorus Iliyofikiwa (Lengo):" else "Phosphorus Achieved (Target):", fontSize = 11.sp)
                                Text("${String.format(java.util.Locale.US, "%.2f", result.achievedNutrients.phosphorus)}% (${String.format(java.util.Locale.US, "%.2f", currentTargetVal?.phosphorus ?: 0.0)}%)", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = if (result.achievedNutrients.phosphorus >= (currentTargetVal?.phosphorus ?: 0.0) - 0.05) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(if (isSwahili) "Kufanikiwa kwa Lishe (Compliance):" else "Nutritional Compliance:", fontSize = 11.sp)
                                val complianceText = if (result.isNutritionalCompliant) {
                                    if (isSwahili) "Ndiyo (Imekamilika kikamilifu)" else "Yes (Fully Compliant)"
                                } else {
                                    if (isSwahili) "Hapana (Marekebisho madogo yanahitajika)" else "No (Some targets missed)"
                                }
                                Text(
                                    text = complianceText,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = if (result.isNutritionalCompliant) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (result.success) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = {
                                    showResultsPopup = false
                                    saveDialogOpened = true
                                },
                                modifier = Modifier.weight(1f).testTag("popup_save_btn"),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(if (isSwahili) "Hifadhi" else "Save")
                            }

                            Row(
                                modifier = Modifier.weight(1.3f),
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Button(
                                    onClick = {
                                        val limitAmt = budgetInput.toDoubleOrNull() ?: 0.0
                                        val rows = result.ingredientPercentages.map { (name, pct) ->
                                            val qty = result.ingredientWeightsKg[name] ?: 0.0
                                            val ing = rawIngredientsList.find { it.name == name }
                                            val price = ing?.pricePerKg ?: 0.0
                                            val cost = qty * price
                                            BudgetRecipeRow(name, pct, qty, cost)
                                        }
                                        showResultsPopup = false
                                        PdfGenerator.generateAndShareBudgetReport(
                                            context = context,
                                            birdType = currentTargetVal?.birdType ?: "Poultry",
                                            stageName = currentTargetVal?.stageName ?: "Diet",
                                            ageWeeks = viewModel.selectedAgeWeeks.value,
                                            batchWeight = batchWeightVal,
                                            budgetLimit = limitAmt,
                                            totalCost = result.totalCost,
                                            averageUnitCost = result.costPerKg,
                                            ingredients = rows,
                                            adviceText = if (isSwahili) "Marekebisho yamekamilika kwa bajeti maalum kikamilifu." else "Recalculation optimized successfully for your target budget.",
                                            isSwahili = isSwahili
                                        )
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                    modifier = Modifier.weight(1f).testTag("popup_pdf_btn"),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(if (isSwahili) "PDF" else "PDF")
                                }

                                androidx.compose.material3.FilledIconButton(
                                    onClick = {
                                        val shareIngredients = result.ingredientPercentages.map { Pair(it.key, it.value) }
                                        showResultsPopup = false
                                        shareFormulaImage(
                                            context = context,
                                            title = if (isSwahili) "Fomula ya Bajeti ya TSh ${budgetInput}" else "Fixed Budget Formula @ TSh ${budgetInput}",
                                            birdType = currentTargetVal?.birdType ?: "Poultry Feed",
                                            stageName = currentTargetVal?.stageName ?: "Diet",
                                            batchWeight = batchWeightVal,
                                            totalCost = result.totalCost,
                                            ingredients = shareIngredients,
                                            unitPrice = result.costPerKg,
                                            isSwahili = isSwahili
                                        )
                                    },
                                    modifier = Modifier.size(36.dp).testTag("popup_share_btn"),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = androidx.compose.material3.IconButtonDefaults.filledIconButtonColors(
                                        containerColor = MaterialTheme.colorScheme.tertiary
                                    )
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Share,
                                        contentDescription = "Share",
                                        tint = MaterialTheme.colorScheme.onTertiary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }

                        OutlinedButton(
                            onClick = { showResultsPopup = false },
                            modifier = Modifier.fillMaxWidth().testTag("popup_close_btn"),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(if (isSwahili) "Funga" else "Close")
                        }
                    } else {
                        Button(
                            onClick = { showResultsPopup = false },
                            modifier = Modifier.fillMaxWidth().testTag("popup_close_btn"),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(if (isSwahili) "Funga" else "Close")
                        }
                    }
                }
            }
        )
    }

    if (saveDialogOpened) {
        val focusRequester = remember { FocusRequester() }
        val keyboardController = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current
        LaunchedEffect(Unit) {
            kotlinx.coroutines.delay(150)
            focusRequester.requestFocus()
        }
        androidx.compose.ui.window.Dialog(onDismissRequest = { saveDialogOpened = false }) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier.padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = if (isSwahili) "Hifadhi Fomula" else "Save Recipe",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = if (isSwahili) "Ingiza jina la fomula:" else "Enter a recipe title:",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                    OutlinedTextField(
                        value = saveTitle,
                        onValueChange = { saveTitle = it },
                        label = { Text(if (isSwahili) "Jina kama 'Fomula ya Bajeti'" else "Title e.g. Budget Mix") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .focusRequester(focusRequester)
                            .testTag("save_budget_title_input"),
                        shape = RoundedCornerShape(12.dp)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { saveDialogOpened = false }) {
                            Text(if (isSwahili) "Ghairi" else "Cancel")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val title = saveTitle.ifBlank {
                                    if (isSwahili) "Fomula ya Bajeti TSh ${budgetInput}" 
                                    else "Budget Formula TSh ${budgetInput}"
                                }
                                val ingredientPercentages = parsedRows.associate { it.ingredientName to it.percentage }
                                val achievedNutrients = calculateNutrientsForBudgetRecipe(parsedRows, rawIngredientsList).let {
                                    mapOf(
                                        "Crude Protein" to it.crudeProtein,
                                        "Metabolizable Energy" to it.energy,
                                        "Calcium" to it.calcium,
                                        "Phosphorus" to it.phosphorus,
                                        "Lysine" to it.lysine,
                                        "Methionine" to it.methionine,
                                        "Crude Fiber" to it.crudeFiber
                                    )
                                }
                                viewModel.saveCustomFormulation(
                                    title = title,
                                    costPerKg = averageUnitCost,
                                    totalCost = totalBudgetCost,
                                    ingredientPercentages = ingredientPercentages,
                                    achievedNutrients = achievedNutrients
                                )
                                saveDialogOpened = false
                                android.widget.Toast.makeText(context.applicationContext, if (isSwahili) "Fomula ya Bajeti imehifadhiwa!" else "Budget Formula Saved Successfully!", android.widget.Toast.LENGTH_SHORT).show()
                                onNavigate("saved") // direct to saved logs screen!
                            },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(if (isSwahili) "Hifadhi" else "Save")
                        }
                    }
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AttachMoney,
                                contentDescription = "Budget",
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isSwahili) "Weka Bajeti yako Maalum" else "Enter Fixed Budget",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (isSwahili)
                                "Ikiwa mchanganyiko wako ni ghali mno, weka kiwango cha juu cha pesa unachotaka kutumia hapa chini. Fomula itarekebishwa upya ili ilingane na bajeti yako."
                                else "If your standard feed mixture is too expensive, enter your maximum budget cash limit below. The formula will be recalculated in real-time to fit your wallet.",
                            fontSize = 11.sp,
                            color = Color.Gray,
                            lineHeight = 15.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = budgetInput,
                                onValueChange = { budgetInput = it },
                                label = { Text(if (isSwahili) "Bajeti" else "Budget") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Number,
                                    imeAction = ImeAction.Done
                                ),
                                keyboardActions = KeyboardActions(
                                    onDone = {
                                        focusManager.clearFocus()
                                        keyboardController?.hide()
                                    }
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("fixed_budget_entry"),

                                trailingIcon = {
                                    Text("TSh", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(end = 8.dp))
                                }
                            )

                            OutlinedTextField(
                                value = bagWeightInput,
                                onValueChange = { if (it.all { char -> char.isDigit() }) bagWeightInput = it },
                                label = { Text(if (isSwahili) "Uzito wa Batch / Mfuko" else "Batch / Bag Weight") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Number,
                                    imeAction = ImeAction.Done
                                ),
                                keyboardActions = KeyboardActions(
                                    onDone = {
                                        focusManager.clearFocus()
                                        keyboardController?.hide()
                                    }
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("bag_weight_entry"),
                                trailingIcon = {
                                    Text("Kg", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(end = 8.dp))
                                }
                            )
                        }

                        // Quick Budget suggestion preset chips
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isSwahili) "Chagua Bajeti:" else "Quick Presets:",
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                                modifier = Modifier.padding(end = 4.dp)
                            )
                            val presetsList = listOf("15000", "50000", "100000", "250000", "500000")
                            presetsList.forEach { prs ->
                                val numericVal = prs.toIntOrNull() ?: 0
                                val label = "TSh " + String.format(java.util.Locale.US, "%,d", numericVal)
                                FilterChip(
                                    selected = budgetInput == prs,
                                    onClick = {
                                        budgetInput = prs
                                        focusManager.clearFocus()
                                        keyboardController?.hide()
                                    },
                                    label = { Text(label, fontSize = 9.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                                        selectedLabelColor = MaterialTheme.colorScheme.onSecondaryContainer,
                                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f),
                                        labelColor = MaterialTheme.colorScheme.onSurfaceVariant
                                    ),
                                    border = BorderStroke(
                                        width = 1.dp,
                                        color = if (budgetInput == prs) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                                    ),
                                    modifier = Modifier.height(28.dp)
                                )
                            }
                        }

                        // Live calculation of batches/bags from normal formulation rate and user budget
                        val normalCostPerKg = formulationResult?.takeIf { it.success }?.costPerKg ?: 0.0
                        if (normalCostPerKg > 0.0) {
                            val bAmt = budgetInput.toDoubleOrNull() ?: 0.0
                            val bgWt = bagWeightInput.toDoubleOrNull() ?: 50.0
                            if (bAmt > 0.0 && bgWt > 0.0) {
                                val costOfOneBag = normalCostPerKg * bgWt
                                val bagsCount = bAmt / costOfOneBag
                                
                                Spacer(modifier = Modifier.height(12.dp))
                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.12f)
                                    ),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(
                                            text = if (isSwahili) "Makadirio ya Mifuko/Batches za Fomula ya Kawaida:" else "Expected Batches/Bags at Normal Formula Rate:",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary,
                                            fontSize = 12.sp
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = if (isSwahili) "Gharama ya Kila Kilo:" else "Cost per Kg:",
                                                fontSize = 11.sp,
                                                color = Color.Gray
                                            )
                                            Text(
                                                text = "${String.format(java.util.Locale.US, "%,.1f", normalCostPerKg)} TSh/Kg",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                        }
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = if (isSwahili) "Gharama ya Batch/Mfuko Mmoja (${bgWt} Kg):" else "Cost for One Batch/Bag (${bgWt} Kg):",
                                                fontSize = 11.sp,
                                                color = Color.Gray
                                            )
                                            Text(
                                                text = "${String.format(java.util.Locale.US, "%,.0f", costOfOneBag)} TSh",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                        }
                                        HorizontalDivider(
                                            modifier = Modifier.padding(vertical = 6.dp),
                                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                                        )
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = if (isSwahili) "Batches/Mifuko Utakayopata kwa Bajeti:" else "Batches/Bags Gained from Your Budget:",
                                                style = MaterialTheme.typography.bodySmall,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                fontSize = 11.sp
                                            )
                                            Text(
                                                text = if (isSwahili) {
                                                    "${String.format(java.util.Locale.US, "%.2f", bagsCount)} Batches/Mifuko"
                                                } else {
                                                    "${String.format(java.util.Locale.US, "%.2f", bagsCount)} Batches/Bags"
                                                },
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = MaterialTheme.colorScheme.primary,
                                                fontSize = 14.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                focusManager.clearFocus()
                                keyboardController?.hide()
                                val amt = budgetInput.toDoubleOrNull() ?: 0.0
                                if (amt > 0.0 && currentTargetVal != null) {
                                    isCalculatingBudget = true
                                    calculationProgress = 0.0f
                                    hasOptimized = true
                                    
                                    scope.launch {
                                        // Dynamic calculation delay based on data & value complexity, capped at 20s max
                                        val base = 3.0
                                        val extraTimeBudget = (amt / 15000.0).coerceIn(0.0, 10.0)
                                        val extraTimeIngs = (rawIngredientsList.count { it.isSelected } * 0.4).coerceIn(0.0, 7.0)
                                        val totalCalcSeconds = (base + extraTimeBudget + extraTimeIngs).coerceIn(3.0, 20.0)
                                        
                                        val totalMs = (totalCalcSeconds * 1000).toLong()
                                        val updateSteps = 30
                                        val stepMs = totalMs / updateSteps
                                        
                                        for (step in 1..updateSteps) {
                                            kotlinx.coroutines.delay(stepMs)
                                            calculationProgress = step.toFloat() / updateSteps
                                        }
                                        
                                        val normalCost = formulationResult?.takeIf { it.success }?.costPerKg ?: 0.0
                                        val targetWeight = if (normalCost > 0.0) amt / normalCost else batchWeightVal
                                        optimizedBatchWeight = targetWeight
                                        
                                        val optResult = BudgetFormulatorSolver.solve(
                                            ingredients = rawIngredientsList,
                                            target = currentTargetVal!!,
                                            inclusionLimits = activeInclusionLimits,
                                            batchWeightKg = targetWeight,
                                            budget = amt,
                                            isSwahili = isSwahili
                                        )
                                        budgetResult = optResult
                                        showResultsPopup = false // No alert dialog popup, we load inline!
                                        
                                        if (optResult.success) {
                                            val sb = java.lang.StringBuilder()
                                            sb.append("---START_RECIPE---\n")
                                            optResult.ingredientPercentages.forEach { (name, pct) ->
                                                val wt = optResult.ingredientWeightsKg[name] ?: 0.0
                                                sb.append("$name: ${String.format(java.util.Locale.US, "%.2f", pct)}% | ${String.format(java.util.Locale.US, "%.2f", wt)} Kg\n")
                                            }
                                            sb.append("---END_RECIPE---\n")
                                            sb.append(if (isSwahili) "Marekebisho yamekamilika kwa bajeti maalum kikamilifu." else "Recalculation optimized successfully for your target budget.")
                                            viewModel.customizedRecipeText.value = sb.toString()
                                        } else {
                                            viewModel.customizedRecipeText.value = ""
                                        }
                                        
                                        isCalculatingBudget = false
                                    }
                                } else {
                                    android.widget.Toast.makeText(context.applicationContext, if (isSwahili) "Ingiza bajeti sahihi au chagua kundi la ndege kwanza." else "Please enter a valid budget and select a bird target first.", android.widget.Toast.LENGTH_SHORT).show()
                                }
                            },
                            enabled = !isCalculatingBudget && budgetInput.isNotBlank(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("calculate_budget_formula_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            if (isCalculatingBudget) {
                                CircularProgressIndicator(
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(if (isSwahili) "INABORESHA BAJETI..." else "OPTIMIZING BUDGET...")
                            } else {
                                Icon(Icons.Default.Calculate, contentDescription = "Recalculate")
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(if (isSwahili) "REKEBISHA ILI ILINGANE NA BAJETI" else "RECALCULATE AND OPTIMIZE BUDGET")
                            }
                        }

                        if (isCalculatingBudget) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f)),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    val amt = budgetInput.toDoubleOrNull() ?: 0.0
                                    val base = 3.0
                                    val extraTimeBudget = (amt / 15000.0).coerceIn(0.0, 10.0)
                                    val extraTimeIngs = (rawIngredientsList.count { it.isSelected } * 0.4).coerceIn(0.0, 7.0)
                                    val totalSecs = (base + extraTimeBudget + extraTimeIngs).coerceIn(3.0, 20.0)
                                    val remaining = (1.0f - calculationProgress) * totalSecs

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        CircularProgressIndicator(
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(24.dp),
                                            strokeWidth = 2.5.dp
                                        )
                                        Text(
                                            text = if (isSwahili) "Inakokotoa fomula ya lishe..." else "Calculating nutrient budget formula...",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    Text(
                                        text = if (isSwahili) {
                                            "Inarekebisha viungo ili viingiane na bajeti ya TSh ${String.format("%,.0f", amt)}... (~${String.format(java.util.Locale.US, "%.1f", remaining)}s imebaki)"
                                        } else {
                                            "Adjusting materials to match TSh ${String.format("%,.0f", amt)} pocket budget... (~${String.format(java.util.Locale.US, "%.1f", remaining)}s remaining)"
                                        },
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        textAlign = TextAlign.Center
                                    )
                                    LinearProgressIndicator(
                                        progress = { calculationProgress },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(6.dp)
                                            .clip(RoundedCornerShape(3.dp)),
                                        color = MaterialTheme.colorScheme.primary,
                                        trackColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                AnimatedVisibility(
                    visible = hasOptimized && !isCalculatingBudget && budgetResult != null,
                    enter = expandVertically() + fadeIn(),
                    exit = shrinkVertically() + fadeOut()
                ) {
                    val result = budgetResult!!
                    if (result.success) {
                        Surface(
                            shape = RoundedCornerShape(24.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.tertiary),
                            tonalElevation = 2.dp,
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.tertiary)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (isSwahili) "Fomula Mpya ya Bajeti Iliyorekebishwa:" else "Budget-Tailored Recipe Result:",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = MaterialTheme.colorScheme.tertiary
                                    )
                                }
                                Spacer(modifier = Modifier.height(12.dp))

                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = if (isSwahili) "Kiambato" else "Material",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.weight(1.5f)
                                            )
                                            Text(
                                                text = if (isSwahili) "Mchanganyiko (%)" else "Percent (%)",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.weight(1.0f),
                                                textAlign = TextAlign.End
                                            )
                                            Text(
                                                text = if (isSwahili) "Uzito (Kg)" else "Weight (Kg)",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.weight(1.0f),
                                                textAlign = TextAlign.End
                                            )
                                            Text(
                                                text = if (isSwahili) "Bei (TSh)" else "Cost (TSh)",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.weight(1.1f),
                                                textAlign = TextAlign.End
                                            )
                                        }
                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                                        Spacer(modifier = Modifier.height(4.dp))
                                        
                                        parsedRows.forEach { row ->
                                            Row(
                                                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1.5f)) {
                                                    Text(
                                                        text = formatIngredientName(row.ingredientName, isSwahili),
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.SemiBold,
                                                        color = MaterialTheme.colorScheme.onSurface
                                                    )
                                                    val bagWeightDouble = bagWeightInput.toDoubleOrNull() ?: 50.0
                                                    val bagsForThis = if (bagWeightDouble > 0) row.weightKg / bagWeightDouble else 0.0
                                                    Text(
                                                        text = if (isSwahili) {
                                                            String.format(java.util.Locale.US, "%.1f batches/mifuko (%s Kg)", bagsForThis, bagWeightInput)
                                                        } else {
                                                            String.format(java.util.Locale.US, "%.1f batches/bags (%s Kg)", bagsForThis, bagWeightInput)
                                                        },
                                                        fontSize = 9.sp,
                                                        fontWeight = FontWeight.Medium,
                                                        color = MaterialTheme.colorScheme.secondary
                                                    )
                                                }
                                                Text(
                                                    text = "${String.format(java.util.Locale.US, "%.1f", row.percentage)}%",
                                                    fontSize = 11.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    modifier = Modifier.weight(1.0f),
                                                    textAlign = TextAlign.End
                                                )
                                                Text(
                                                    text = "${String.format(java.util.Locale.US, "%.2f", row.weightKg)} Kg",
                                                    fontSize = 11.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    modifier = Modifier.weight(1.0f),
                                                    textAlign = TextAlign.End
                                                )
                                                Text(
                                                    text = "${String.format(java.util.Locale.US, "%,.0f", row.costTsh)} TSh",
                                                    fontSize = 11.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    modifier = Modifier.weight(1.1f),
                                                    textAlign = TextAlign.End
                                                )
                                            }
                                        }

                                        val totalPct = parsedRows.sumOf { it.percentage }
                                        val totalWt = parsedRows.sumOf { it.weightKg }
                                        val totalCost = parsedRows.sumOf { it.costTsh }

                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = if (isSwahili) "JUMLA" else "TOTAL",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.weight(1.5f)
                                            )
                                            Text(
                                                text = "${String.format(java.util.Locale.US, "%.1f", totalPct)}%",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.weight(1.0f),
                                                textAlign = TextAlign.End
                                            )
                                            Text(
                                                text = "${String.format(java.util.Locale.US, "%.2f", totalWt)} Kg",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.weight(1.0f),
                                                textAlign = TextAlign.End
                                            )
                                            Text(
                                                text = "${String.format(java.util.Locale.US, "%,.0f", totalCost)} TSh",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.weight(1.1f),
                                                textAlign = TextAlign.End
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                // Dynamic cost per Kg
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (isSwahili) "Gharama Mpya kwa Kilo:" else "New Cost/Kg:",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = Color.Gray
                                    )
                                    Text(
                                        text = "${String.format("%,.1f", averageUnitCost)} TSh/Kg",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Beautiful targeted summary metrics card (Highly accurate!)
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(
                                                text = if (isSwahili) "Bajeti Kamili" else "Total Budget", 
                                                fontSize = 10.sp, 
                                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                                fontWeight = FontWeight.Medium
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "${String.format("%,.0f", budgetInput.toDoubleOrNull() ?: 0.0)} TSh",
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 14.sp,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                        
                                        Box(modifier = Modifier.width(1.dp).height(36.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)))
                                        
                                        Column(modifier = Modifier.weight(1.1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(
                                                text = if (isSwahili) "Uzito wa Kundi" else "Batch Quantity", 
                                                fontSize = 10.sp, 
                                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                                fontWeight = FontWeight.Medium
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "${String.format(java.util.Locale.US, "%.1f", optimizedBatchWeight)} Kg",
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 14.sp,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                        
                                        Box(modifier = Modifier.width(1.dp).height(36.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)))
                                        
                                        Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                            val bagWeightDouble = bagWeightInput.toDoubleOrNull() ?: 50.0
                                            val totalBagsNeeded = if (bagWeightDouble > 0) optimizedBatchWeight / bagWeightDouble else 0.0
                                            Text(
                                                text = if (isSwahili) "Mifuko ya Kundi" else "Number of Bags", 
                                                fontSize = 10.sp, 
                                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                                fontWeight = FontWeight.Medium
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = if (isSwahili) {
                                                    "${String.format(java.util.Locale.US, "%.1f", totalBagsNeeded)} Mifuko"
                                                } else {
                                                    "${String.format(java.util.Locale.US, "%.1f", totalBagsNeeded)} Bags"
                                                },
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 13.sp,
                                                color = MaterialTheme.colorScheme.secondary
                                            )
                                        }
                                    }
                                }

                                // Flock feed duration and intake summary guide
                                val stats = viewModel.getStandardNutritionInfo(birdType, ageWeeks)
                                FlockFeedingDurationCard(
                                    birdType = currentTargetVal?.birdType ?: birdType,
                                    stageName = currentTargetVal?.stageName ?: "Diet Stage",
                                    ageWeeks = ageWeeks,
                                    flockSize = flockSize,
                                    batchWeight = optimizedBatchWeight,
                                    dailyIntakeGrams = stats.dailyFeedInTakeGrams,
                                    isSwahili = isSwahili
                                )

                                if (cleanAdviceText.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = if (isSwahili) "💡 Ushauri wa AI & Mapendekezo:" else "💡 AI Advice & Recommendations:",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = cleanAdviceText,
                                        fontSize = 11.sp,
                                        lineHeight = 15.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Spacer(modifier = Modifier.height(16.dp))
                                
                                // Exactly 2 Action blocks: Save, and (PDF Report + Share)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Button(
                                        onClick = { saveDialogOpened = true },
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(44.dp)
                                            .testTag("save_budget_formula_cta"),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Icon(Icons.Default.Save, contentDescription = "Save", modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (isSwahili) "Hifadhi" else "Save",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            maxLines = 1
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.weight(1.3f),
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Button(
                                            onClick = {
                                                val limitAmt = budgetInput.toDoubleOrNull() ?: 0.0
                                                PdfGenerator.generateAndShareBudgetReport(
                                                    context = context,
                                                    birdType = currentTargetVal?.birdType ?: "Poultry",
                                                    stageName = currentTargetVal?.stageName ?: "Diet",
                                                    ageWeeks = viewModel.selectedAgeWeeks.value,
                                                    batchWeight = optimizedBatchWeight,
                                                    budgetLimit = limitAmt,
                                                    totalCost = totalBudgetCost,
                                                    averageUnitCost = averageUnitCost,
                                                    ingredients = parsedRows,
                                                    adviceText = cleanAdviceText,
                                                    isSwahili = isSwahili
                                                )
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(44.dp)
                                                .testTag("share_budget_pdf_report_btn"),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Icon(Icons.Default.Description, contentDescription = "PDF Report", modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = if (isSwahili) "Ripoti PDF" else "PDF Report",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                maxLines = 1
                                            )
                                        }

                                        androidx.compose.material3.FilledIconButton(
                                            onClick = {
                                                val shareIngredients = parsedRows.map { Pair(it.ingredientName, it.percentage) }
                                                shareFormulaImage(
                                                    context = context,
                                                    title = if (isSwahili) "Fomula ya Bajeti ya TSh ${budgetInput}" else "Fixed Budget Formula @ TSh ${budgetInput}",
                                                    birdType = currentTargetVal?.birdType ?: "Poultry Feed",
                                                    stageName = currentTargetVal?.stageName ?: "Diet",
                                                    batchWeight = optimizedBatchWeight,
                                                    totalCost = totalBudgetCost,
                                                    ingredients = shareIngredients,
                                                    unitPrice = averageUnitCost,
                                                    isSwahili = isSwahili
                                                )
                                            },
                                            modifier = Modifier
                                                .size(44.dp)
                                                .testTag("share_budget_image_btn"),
                                            shape = RoundedCornerShape(12.dp),
                                            colors = androidx.compose.material3.IconButtonDefaults.filledIconButtonColors(
                                                containerColor = MaterialTheme.colorScheme.tertiary
                                            )
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Share,
                                                contentDescription = "Share",
                                                tint = MaterialTheme.colorScheme.onTertiary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        // High quality infeasible warning box displayed inline directly on-page (never hidden in alert pop-up)
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                            shape = RoundedCornerShape(24.dp),
                            border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.error),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f))
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = "Infeasible",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(40.dp)
                                )
                                Text(
                                    text = if (isSwahili) "Fomula ya Bajeti Haiwezekani" else "Budget Optimization Infeasible",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = MaterialTheme.colorScheme.error
                                )
                                Text(
                                    text = if (isSwahili) "Bajeti uliyoweka ni ndogo sana kumudu mahitaji ya chini ya viungo hivi." else "The entered budget is too low to meet the minimum inclusion limits for these selected ingredients.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    textAlign = TextAlign.Center
                                )
                                if (result.minRequiredBudget > 0.0) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = if (isSwahili) {
                                            "Bajeti ya Chini Inayohitajika: TSh ${String.format("%,.0f", result.minRequiredBudget)}"
                                        } else {
                                            "Minimum Required Budget: TSh ${String.format("%,.0f", result.minRequiredBudget)}"
                                        },
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 14.sp,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }
                                if (result.suggestedChanges.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Text(
                                                text = if (isSwahili) "💡 Mapendekezo ya kurekebisha:" else "💡 Recommended adjustments:",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = result.suggestedChanges,
                                                fontSize = 11.sp,
                                                lineHeight = 15.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun IngredientsManagerScreen(
    viewModel: PoultryViewModel,
    onNavigate: (String) -> Unit,
    isSwahili: Boolean
) {
    val ingredients by viewModel.ingredients.collectAsStateWithLifecycle()
    val isDark = MaterialTheme.colorScheme.background.red < 0.2f

    var searchQuery by remember { mutableStateOf("") }
    var selectedCategoryFilter by remember { mutableStateOf("All") }
    
    // Dialog control states
    var showEditDialog by remember { mutableStateOf(false) }
    var selectedIngredientForEdit by remember { mutableStateOf<Ingredient?>(null) }
    var showDeleteConfirmDialog by remember { mutableStateOf<Ingredient?>(null) }

    // Grouping & filtering list
    val filteredIngredients = remember(ingredients, searchQuery, selectedCategoryFilter) {
        ingredients.filter { ing ->
            val nameMatches = ing.name.contains(searchQuery, ignoreCase = true)
            val categoryMatches = when (selectedCategoryFilter) {
                "All" -> true
                "Custom Only" -> ing.isCustom
                else -> ing.category.equals(selectedCategoryFilter, ignoreCase = true)
            }
            nameMatches && categoryMatches
        }
    }

    Scaffold(
        topBar = {
            Surface(
                tonalElevation = 4.dp,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, if (isDark) Color(0xFF2C352E) else Color(0xFFE3DAC9))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(bottom = 8.dp)
                ) {
                    // Title action bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { onNavigate("home") },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("ingredients_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = if (isSwahili) "Rudi" else "Back",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isSwahili) "Stoo ya Viungo" else "Feed Ingredient Warehousing",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = if (isSwahili) "Dhibiti viungo na virutubisho vyako" else "Manage local ingredient nutritional content",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Top count badge
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text(
                                text = "${ingredients.size}",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    // Search panel - Styled like dynamic agriculture dashboard filter
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                            .testTag("ingredients_search_input"),
                        placeholder = { Text(if (isSwahili) "Tafuta kiungo..." else "Search storehouse ingredients...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Close, contentDescription = "Clear")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = if (isDark) Color(0xFF2C352E) else Color(0xFFE3DAC9)
                        )
                    )

                    // Organic category pill filter row
                    val categories = listOf("All", "Energy", "Protein", "Mineral", "Additive", "Custom Only")
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        categories.forEach { filter ->
                            val isSelected = selectedCategoryFilter == filter
                            val label = when (filter) {
                                "All" -> if (isSwahili) "Vyote" else "All"
                                "Energy" -> if (isSwahili) "Nishati" else "Energy"
                                "Protein" -> if (isSwahili) "Protini" else "Protein"
                                "Mineral" -> if (isSwahili) "Madini" else "Minerals"
                                "Additive" -> if (isSwahili) "Nyongeza" else "Additives"
                                "Custom Only" -> if (isSwahili) "Yangu Tu" else "My Custom"
                                else -> filter
                            }
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedCategoryFilter = filter },
                                label = { Text(label, style = MaterialTheme.typography.labelMedium) },
                                shape = RoundedCornerShape(20.dp),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }
            }
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    selectedIngredientForEdit = null
                    showEditDialog = true
                },
                modifier = Modifier
                    .padding(16.dp)
                    .testTag("add_ingredient_fab"),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = if (isSwahili) "Ongeza Kiungo" else "Add Ingredient"
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isSwahili) "Ongeza Kiungo" else "New Profile",
                    fontWeight = FontWeight.Bold
                )
            }
        },
        modifier = Modifier.fillMaxSize()
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(if (isDark) Color(0xFF0F1411) else Color(0xFFFAF6EE))
        ) {
            if (filteredIngredients.isEmpty()) {
                // Beautiful empty state with friendly agricultural illustration hints
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Eco,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(48.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = if (isSwahili) "Hakuna viungo vilivyopatikana" else "No ingredients found",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isSwahili)
                            "Jaribu kurekebisha vichujio vyako au bofya kitufe cha 'Ongeza Kiungo' hapo chini ili kuingiza nyenzo mpyas."
                            else "Try adjusting your filters, or click the 'New Profile' button below to add your custom raw materials.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        lineHeight = 18.sp
                    )
                }
            } else {
                // Adaptive Agricultural Grid component representing CSS grid-like structured flexbox design
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 280.dp),
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(filteredIngredients, key = { it.id }) { ing ->
                        IngredientWarehouseCard(
                            ingredient = ing,
                            isSwahili = isSwahili,
                            isDark = isDark,
                            onToggleSelected = {
                                viewModel.toggleIngredientSelection(ing)
                            },
                            onEdit = {
                                selectedIngredientForEdit = ing
                                showEditDialog = true
                            },
                            onDelete = {
                                showDeleteConfirmDialog = ing
                            }
                        )
                    }
                }
            }
        }
    }

    // Modal Edit/Add Ingredient Dialog using double column structured grid input
    if (showEditDialog) {
        IngredientInputDialog(
            ingredient = selectedIngredientForEdit,
            isSwahili = isSwahili,
            isDark = isDark,
            onDismiss = { showEditDialog = false },
            onSave = { savedIng ->
                viewModel.saveIngredient(savedIng)
                showEditDialog = false
            }
        )
    }

    // Delete Confirmation Dialog
    showDeleteConfirmDialog?.let { ing ->
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Confirm Delete",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isSwahili) "Futa Kiungo Kipya?" else "Confirm Profile Deletion",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            text = {
                Text(
                    text = if (isSwahili) 
                        "Je, uko tayari kabisa kufuta kabisa kiungo hiki '${ing.name}' kutoka kwenye stoo yako? Hatua hii haiwezi kutenguliwa."
                        else "Are you sure you want to permanently delete '${ing.name}' from your warehouses? This cannot be undone.",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteIngredient(ing)
                        showDeleteConfirmDialog = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(if (isSwahili) "Futa" else "Delete", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showDeleteConfirmDialog = null },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(if (isSwahili) "Ghairi" else "Cancel")
                }
            },
            shape = RoundedCornerShape(16.dp)
        )
    }
}

@Composable
fun IngredientWarehouseCard(
    ingredient: Ingredient,
    isSwahili: Boolean,
    isDark: Boolean,
    onToggleSelected: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val categoryBg = when (ingredient.category.lowercase()) {
        "energy" -> if (isDark) Color(0xFF423214) else Color(0xFFFFF8E1)
        "protein" -> if (isDark) Color(0xFF3E1F1F) else Color(0xFFFFEBEE)
        "mineral" -> if (isDark) Color(0xFF142D3D) else Color(0xFFE1F5FE)
        else -> if (isDark) Color(0xFF1F3A23) else Color(0xFFE8F5E9)
    }

    val categoryColor = when (ingredient.category.lowercase()) {
        "energy" -> Color(0xFFFFB300)
        "protein" -> Color(0xFFEF9A9A)
        "mineral" -> Color(0xFF81D4FA)
        else -> Color(0xFFA5D6A7)
    }

    val categoryLabel = when (ingredient.category.lowercase()) {
        "energy" -> if (isSwahili) "NISHATI" else "ENERGY"
        "protein" -> if (isSwahili) "PROTINI" else "PROTEIN"
        "mineral" -> if (isSwahili) "MADINI" else "MINERALS"
        else -> if (isSwahili) "NYONGEZA" else "ADDITIVES"
    }

    Card(
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.5.dp, if (ingredient.isSelected) MaterialTheme.colorScheme.primary else (if (isDark) Color(0xFF2C352E) else Color(0xFFE3DAC9))),
        colors = CardDefaults.cardColors(
            containerColor = if (isDark) Color(0xFF181F1A) else Color(0xFFFFFFFF)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("ingredient_card_${ingredient.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Category tag and Available Switch
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Category Chip Badge
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = categoryBg,
                    modifier = Modifier.padding(bottom = 8.dp)
                ) {
                    Text(
                        text = categoryLabel,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (isDark) categoryColor else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                // Available On-Farm Indicator Switch
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = if (isSwahili) "Msturi" else "Available",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (ingredient.isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Switch(
                        checked = ingredient.isSelected,
                        onCheckedChange = { onToggleSelected() },
                        modifier = Modifier
                            .graphicsLayer(scaleX = 0.8f, scaleY = 0.8f)
                            .testTag("ingredient_switch_${ingredient.id}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Ingredient Name representation
            Text(
                text = formatIngredientName(ingredient.name, isSwahili),
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium,
                color = if (isDark) Color(0xFFE2EBE5) else Color(0xFF253728)
            )

            if (ingredient.isCustom) {
                Text(
                    text = if (isSwahili) "• Kiungo Chako Umekiongeza" else "• Custom Added Profile",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.tertiary,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Nutritional Grid: Internal 2-column, 3-row grid mimicking balanced table metrics
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isDark) Color(0xFF222C24) else Color(0xFFFBF9F4)
                ),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, if (isDark) Color(0xFF2C352E) else Color(0xFFF1EAE1)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Row 1
                    Row(modifier = Modifier.fillMaxWidth()) {
                        NutrientCell(
                            label = if (isSwahili) "Protini (CP)" else "Crude Protein",
                            value = "${ingredient.crudeProtein}%",
                            modifier = Modifier.weight(1f)
                        )
                        NutrientCell(
                            label = if (isSwahili) "Nishati (ME)" else "Energy Level",
                            value = "${ingredient.energy.toInt()} kcal",
                            modifier = Modifier.weight(1f)
                        )
                    }
                    HorizontalDivider(color = if (isDark) Color(0xFF2C352E) else Color(0xFFE3DAC9), thickness = 0.5.dp)
                    // Row 2
                    Row(modifier = Modifier.fillMaxWidth()) {
                        NutrientCell(
                            label = if (isSwahili) "Chokaa (Ca)" else "Calcium",
                            value = "${ingredient.calcium}%",
                            modifier = Modifier.weight(1f)
                        )
                        NutrientCell(
                            label = "Phosphorus (P)",
                            value = "${ingredient.phosphorus}%",
                            modifier = Modifier.weight(1f)
                        )
                    }
                    HorizontalDivider(color = if (isDark) Color(0xFF2C352E) else Color(0xFFE3DAC9), thickness = 0.5.dp)
                    // Row 3
                    Row(modifier = Modifier.fillMaxWidth()) {
                        NutrientCell(
                            label = "Lysine",
                            value = "${ingredient.lysine}%",
                            modifier = Modifier.weight(1f)
                        )
                        NutrientCell(
                            label = "Methionine",
                            value = "${ingredient.methionine}%",
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Bottom Section: Pricing & Actions Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Cost level
                Column {
                    Text(
                        text = if (isSwahili) "Bei kwa Kilo:" else "Cost per Kg:",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = if (ingredient.pricePerKg > 0.0) {
                            if (isSwahili) "KSh ${ingredient.pricePerKg.toInt()}" else "${ingredient.pricePerKg.toInt()} KES"
                        } else {
                            if (isSwahili) "Haina bei" else "N/A"
                        },
                        fontWeight = FontWeight.ExtraBold,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                // Interactive Edit/Delete Icon Target Buttons (strictly supporting minimum 48dp target constraints)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { onEdit() },
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("edit_ingredient_btn_${ingredient.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit Profile",
                            tint = MaterialTheme.colorScheme.secondary
                        )
                    }

                    if (ingredient.isCustom) {
                        IconButton(
                            onClick = { onDelete() },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("delete_ingredient_btn_${ingredient.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete Profile",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NutrientCell(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier) {
        Text(text = label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
fun IngredientInputDialog(
    ingredient: Ingredient?,
    isSwahili: Boolean,
    isDark: Boolean,
    onDismiss: () -> Unit,
    onSave: (Ingredient) -> Unit
) {
    var name by remember(ingredient) { mutableStateOf(ingredient?.name ?: "") }
    var category by remember(ingredient) { mutableStateOf(ingredient?.category ?: "Energy") }
    
    var cp by remember(ingredient) { mutableStateOf(ingredient?.crudeProtein?.toString() ?: "") }
    var me by remember(ingredient) { mutableStateOf(ingredient?.energy?.toInt()?.toString() ?: "") }
    var ca by remember(ingredient) { mutableStateOf(ingredient?.calcium?.toString() ?: "") }
    var p by remember(ingredient) { mutableStateOf(ingredient?.phosphorus?.toString() ?: "") }
    var lys by remember(ingredient) { mutableStateOf(ingredient?.lysine?.toString() ?: "") }
    var met by remember(ingredient) { mutableStateOf(ingredient?.methionine?.toString() ?: "") }
    var cf by remember(ingredient) { mutableStateOf(ingredient?.crudeFiber?.toString() ?: "") }
    var cost by remember(ingredient) { mutableStateOf(ingredient?.pricePerKg?.takeIf { it > 0.0 }?.toInt()?.toString() ?: "") }

    var hasError by remember(ingredient) { mutableStateOf(false) }

    val focusRequester = remember(ingredient) { FocusRequester() }
    val keyboardController = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current
    LaunchedEffect(ingredient) {
        kotlinx.coroutines.delay(150)
        focusRequester.requestFocus()
    }

    Dialog(onDismissRequest = { onDismiss() }) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = if (isDark) Color(0xFF181F1A) else Color(0xFFFFFFFF),
            border = BorderStroke(1.5.dp, if (isDark) Color(0xFF2C352E) else Color(0xFFE3DAC9)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header of agriculture themed dialog form
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (ingredient == null) {
                            if (isSwahili) "Kiwanda Kipya cha Kilimo" else "Agricultural Feed Profile"
                        } else {
                            if (isSwahili) "Hariri Thamani za Pishi" else "Modify Feed Specie"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    IconButton(onClick = { onDismiss() }) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                HorizontalDivider(color = if (isDark) Color(0xFF2C352E) else Color(0xFFE3DAC9))

                // Name input row
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        hasError = false
                    },
                    isError = hasError,
                    label = { Text(if (isSwahili) "Jina la Kiungo (mf. Maize Bran)" else "Ingredient Name (e.g. Maize Bran)") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(focusRequester)
                        .testTag("dialog_ingredient_name")
                )

                // Category selector buttons
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = if (isSwahili) "Chagua Kundi la Kulisha:" else "Material Dietary Classification:",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val categoriesList = listOf("Energy", "Protein", "Mineral", "Additive")
                        categoriesList.forEach { cat ->
                            val isSelected = category.lowercase() == cat.lowercase()
                            val label = when (cat) {
                                "Energy" -> if (isSwahili) "Nishati" else "Energy"
                                "Protein" -> if (isSwahili) "Protini" else "Protein"
                                "Mineral" -> if (isSwahili) "Madini" else "Mineral"
                                "Additive" -> if (isSwahili) "Nyongeza" else "Additive"
                                else -> cat
                            }
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) MaterialTheme.colorScheme.primary else (if (isDark) Color(0xFF222C24) else Color(0xFFF1EAE1)))
                                    .clickable { category = cat }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                
                Text(
                    text = if (isSwahili) "Kiwandani Thamani msaada:" else "Micro-Nutritional Parameters Grid (CSS grid style layout):",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                // Agriculture CSS Grid Form Fields (Aligned inside horizontal pairs representing structured layout cells)
                // CPU Row: CP and Energy
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = cp,
                        onValueChange = { cp = it },
                        label = { Text("Crude Prot (CP %)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dialog_ingredient_cp")
                    )
                    OutlinedTextField(
                        value = me,
                        onValueChange = { me = it },
                        label = { Text("Energy (ME kcal)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dialog_ingredient_me")
                    )
                }

                // Minerals Row: Calcium and Phosphorus
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = ca,
                        onValueChange = { ca = it },
                        label = { Text("Calcium (Ca %)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dialog_ingredient_ca")
                    )
                    OutlinedTextField(
                        value = p,
                        onValueChange = { p = it },
                        label = { Text("Phosphorus (P %)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dialog_ingredient_p")
                    )
                }

                // Amino Acids Row: Lysine and Methionine
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = lys,
                        onValueChange = { lys = it },
                        label = { Text("Lysine (%)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dialog_ingredient_lys")
                    )
                    OutlinedTextField(
                        value = met,
                        onValueChange = { met = it },
                        label = { Text("Methionine (%)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dialog_ingredient_met")
                    )
                }

                // Row 4: Crude Fiber and Price per Kg
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = cf,
                        onValueChange = { cf = it },
                        label = { Text("Crude Fiber (%)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dialog_ingredient_cf")
                    )
                    OutlinedTextField(
                        value = cost,
                        onValueChange = { cost = it },
                        label = { Text(if (isSwahili) "Bei/Kg" else "Price/Kg (KES)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dialog_ingredient_price")
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Action Buttons inside input layout
                Button(
                    onClick = {
                        if (name.isBlank()) {
                            hasError = true
                        } else {
                            val targetId = ingredient?.id ?: 0
                            val finalIng = Ingredient(
                                id = targetId,
                                name = name.trim(),
                                category = category,
                                crudeProtein = cp.toDoubleOrNull() ?: 0.0,
                                energy = me.toDoubleOrNull() ?: 0.0,
                                calcium = ca.toDoubleOrNull() ?: 0.0,
                                phosphorus = p.toDoubleOrNull() ?: 0.0,
                                lysine = lys.toDoubleOrNull() ?: 0.0,
                                methionine = met.toDoubleOrNull() ?: 0.0,
                                crudeFiber = cf.toDoubleOrNull() ?: 0.0,
                                pricePerKg = cost.toDoubleOrNull() ?: 0.0,
                                isCustom = ingredient?.isCustom ?: true,
                                isSelected = ingredient?.isSelected ?: true
                            )
                            onSave(finalIng)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("dialog_save_ingredient_btn")
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isSwahili) "Hifadhi Viungo Vifaranga" else "Save Farm Profile",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}


